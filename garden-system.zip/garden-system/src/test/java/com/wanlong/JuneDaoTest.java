package com.wanlong;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.wanlong.dao.ClerkDao;
import com.wanlong.dao.FacilityDao;
import com.wanlong.dao.SuppliesDao;
import com.wanlong.pojos.Clerk;
import com.wanlong.pojos.Facility;
import com.wanlong.service.ClerkService;
import com.wanlong.util.PageRequest;
import com.wanlong.util.PageResult;

@RunWith(SpringRunner.class)
@SpringBootTest
@MapperScan("com.wanlong.dao")
public class JuneDaoTest {
	@Autowired
	FacilityDao facilityDao;
	@Autowired
	SuppliesDao suppliesDao;
	@Autowired
	ClerkDao clerkDao;
	@Autowired
	ClerkService clerkService;

	@Test
	public void test1() {
		List<Facility> list1 = facilityDao.find();
		System.out.println(list1);
	}
	@Test
	public void test2() {
		List<Clerk> list=clerkDao.findPageByLike("总经理");
		System.out.println(list);
	}
}
