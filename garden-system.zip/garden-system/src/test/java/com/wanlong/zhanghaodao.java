package com.wanlong;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.wanlong.dao.BillMapper;
import com.wanlong.dao.BillitemsMapper;
import com.wanlong.dao.ComplainDao;
import com.wanlong.dao.HousenumberMapper;
import com.wanlong.dao.MessageMapper;
import com.wanlong.pojos.Bill;
import com.wanlong.pojos.BillExample;
import com.wanlong.pojos.Billitems;
import com.wanlong.pojos.BillitemsExample;
import com.wanlong.pojos.Complain;
import com.wanlong.pojos.ComplainExample;
import com.wanlong.pojos.Housenumber;
import com.wanlong.pojos.HousenumberExample;
import com.wanlong.pojos.Message;
import com.wanlong.pojos.MessageExample;
import com.wanlong.pojos.Owner;
import com.wanlong.service.BillService;
import com.wanlong.service.HouseNumberService;
import com.wanlong.service.OwnerService;

@RunWith(SpringRunner.class)
@SpringBootTest
@MapperScan("com.wanlong.dao")
public class zhanghaodao {
	@Autowired
	ComplainDao complainDao;
	@Autowired
	HousenumberMapper housemapper;
	@Autowired
	BillMapper billMapper;
	@Autowired
	HouseNumberService hService;
	@Autowired
	HousenumberMapper hmapper;
	@Autowired
	BillitemsMapper billitemmapper;
	@Autowired
	MessageMapper messMapper;
	@Autowired
	BillService billService;
	@Autowired
	OwnerService oService;

	@Test
	public void test() {
		HousenumberExample example = new HousenumberExample();
		List<Housenumber> list = hService.selectByExample(example);
		System.out.println(list.size());
	}

	@Test
	public void test4() {
		HousenumberExample example = new HousenumberExample();
		Housenumber h = new Housenumber();
		h.setPrice(10000);
		h.setHomeid(1);
		int i = hService.updateByPrimaryKeySelective(h);
		System.out.println(i);
	}

	@Test
	public void test1() {

		List<Bill> list = billMapper.findAll();
		for (Bill bill : list) {
			System.out.println(bill.getBillitem().getBillitemmoney());
		}
	}

	@Test
	public void test2() {

		List<Owner> list1 = billMapper.findPage();
		for (int i = 0; i < list1.size(); i++) {
			System.out.println(list1.get(i).getOname());
			System.out.println("------------=========");
		}

	}

	@Test
	public void test3() {
		List<Owner> list1 = billMapper.findByOwner();
		System.out.println(list1.size());
		for (int i = 0; i < list1.size(); i++) {
			System.out.println(list1.get(i).getOname());
		}
	}

	@Test
	public void test5() {
		Housenumber h = new Housenumber();
		h.setPrice(20000);
		h.setHnumber(709);
		int i = hmapper.insert(h);
		System.out.println(i);
	}

	@Test
	public void test6() {
		BillitemsExample example = new BillitemsExample();
		List<Billitems> list = billitemmapper.selectByExample(example);
		for (Billitems billitems : list) {
			System.out.println(billitems.getBillitemmoney());
		}
	}

	@Test
	public void test7() {

		Billitems bill = new Billitems();
		bill.setBillitemmoney(100.0);
		bill.setBillitemname("绿化费");
		bill.setBillitemtype("一次性");
		int i = billitemmapper.insert(bill);
		System.out.println(i);
	}

	@Test
	public void test8() {

		Billitems b = billitemmapper.selectByPrimaryKey(1);
		System.out.println(b.getBillitemname());
	}

	@Test
	public void test9() {
		String a = "绿化费";
		String b = "2020年11月17日";
		Billitems c = billitemmapper.selectByNameAndTime(a, b);
		System.out.println(c.getBillitemname());
	}

	@Test
	public void test10() {
		String a = "绿化费";
		String b = "2020年11月17日";
		Billitems c = billitemmapper.selectByNameAndTime(a, b);
		System.out.println(c.getBillitemname());
	}

	@Test
	public void testmess() {
		/*
		 * MessageExample example=new MessageExample(); List<Message>
		 * list=messMapper.selectByExample(example); for (int i = 0; i <list.size();
		 * i++) {
		 * System.out.println(list.get(i).getMessinfo()+list.get(i).getMesstime()+list.
		 * get(i).getStatus()+list.get(i).getOid()); }
		 */

		/*
		 * List<Message> m=messMapper.selectByOid(100001);
		 * System.out.println(m.get(0).getMessinfo());
		 */

		/*
		 * Message m=new Message(); m.setMessid(1); m.setStatus("已读"); int
		 * i=messMapper.updateByPrimaryKey(m); System.out.println(i);
		 */
		/*
		 * Message m=messMapper.selectByPrimaryKey(1);
		 * System.out.println(m.getMessinfo());
		 */

		/*
		 * Message m=messMapper.selectByPrimaryKey(2); m.setMessinfo("祝你早生贵子"); int
		 * i=messMapper.updateByPrimaryKey(m); System.out.println(i);
		 */

		/*
		 * int i=messMapper.updateByOid(100004); System.out.println(i);
		 */

		/*
		 * Message mess=new Message(); mess.setMessinfo("祝你生日快乐");
		 * mess.setMesstime("2020-09-05"); mess.setStatus("未阅读"); mess.setOid(100004);
		 * int i=messMapper.insert(mess); System.out.println(i);
		 */

		/*
		 * Owner o=billMapper.findByOid(100004); for (int i = 0; i < o.getBill().size();
		 * i++) { System.out.println(o.getOname()); }
		 */

		String name = "";
		double osum = 0.0;
		int[] a = { 1, 2, 3 };
		List<Bill> list = billMapper.findByOid(a);
		for (int i = 0; i < list.size(); i++) {
			System.out.println(list.get(i).getBillitem().getBillitemname());
		}
	}

	@Test
	public void billtest() {
		int a[]= {1,2,3};
		int i=billService.updateBillStatus("2020-08-08");
		System.out.println(i);
	}
	@Test
	public void ownertest() {
		List<Owner> list = billService.findByOwner();
		for (int i = 0; i < list.size(); i++) {
			System.out.println(list.get(i).getOname());
		}
	}
}