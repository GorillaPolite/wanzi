package com.wanlong;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.wanlong.dao.CleanMapper;
import com.wanlong.dao.MaintainMapper;
import com.wanlong.dao.OwnerMapper;
import com.wanlong.pojos.Clean;
import com.wanlong.pojos.Maintain;
import com.wanlong.pojos.Owner;
import com.wanlong.pojos.OwnerExample;

@RunWith(SpringRunner.class)
@SpringBootTest
@MapperScan("com.wanlong.dao")
public class mufengDao {


	@Autowired
	OwnerMapper ownermapper;
	@Autowired
	MaintainMapper maintainMapper;
	
	@Autowired
	CleanMapper cleanMapper;
	
	@Test
	public void test1() {
		Owner record=new Owner();
		record.setOname("战三");
		record.setOdoorplate("4342");
		record.setOpass("434234");
		record.setOtel("2342432423");
		record.setTowernum(2);
		record.setOidentity("111111111111");
	    ownermapper.insert(record);
		System.out.println(record.getOname());
	    
		
	}
	@Test
	public void test2() {
		OwnerExample ownerExample = new OwnerExample();
		List<Owner> list1 = ownermapper.selectByExample();
		System.out.println(list1.size());
		for (Owner owner : list1) {
		System.out.println(owner.getOname() + "\t" + owner.getOdoorplate()+ "\t" + owner.getTowernum());
		} 
		
	}
	@Test
	public void test4() {
		Owner owner1 = new Owner();
		List<Owner> list1 = ownermapper.findownerlist(3);
		System.out.println(list1.size());
		for (Owner owner : list1) {
		System.out.println(owner.getOname() + "\t" + owner.getOdoorplate()+ "\t" + owner.getTowernum());
		} 
		
	}
	@Test
	public void test3() {
		Owner owner=new Owner();
		owner.setOid(100008);
		owner.setOname("战三");
		owner.setOdoorplate("4342");
		owner.setOpass("434234");
		owner.setOtel("2342432423");
		owner.setOidentity("111111111111");
	    ownermapper.updatesave(owner);	
	}
	@Test
	public void test10() {
		Owner owner=new Owner();
		owner.setOid(100001);
		owner.setOname("张天爱");
		owner.setOpass("222");
		owner.setOtel("18829248030");
		owner.setOidentity("612526199409341243");
	    ownermapper.updateowner(owner);	
	}
	@Test
	public void test5() {
		Maintain maintain=new Maintain();
		maintain.setMid(100001);
		maintain.setClerkid(10006);
		maintain.setMbit("ssssss");
		maintain.setMpart("ffff");
		maintainMapper.updatesave2(maintain);	
	}
	@Test
	public void test6() {
		Maintain maintain=new Maintain();
		maintain.setMid(100002);
		
		maintain.setMfinishtime("2003-5-8");
		maintainMapper.updatmbit(maintain);	
	}
	@Test
	public void test7() {
		Maintain maintain=new Maintain();
		maintain.setMpart("2号楼");
		
		maintain.setMcontent("进大厅灯坏了");
		maintain.setClerkid(10005);
		maintain.setMmaterials("灯泡一个");
		maintain.setMdate("2009-9-4");
		maintainMapper.insert2(maintain);	
	}
	@Test
	public void test8() {
		Clean clean=new Clean(); 
		clean.setClarea("2号楼");
		
		clean.setClcontent("打扫所有楼道");
		clean.setClerkid(100011);
		clean.setClmaterials("扫把一个，清洁剂");
		clean.setCltime("2009-9-4");
		cleanMapper.insert(clean);	
	}
	@Test
	public void test9() {
		Clean clean=new Clean();
		
		clean.setClarea("2号楼");
		
		clean.setClcontent("打扫所有楼道");
		clean.setClerkid(100011);
		clean.setClmaterials("扫把一个，清洁剂");
		clean.setCltime("2009-9-4");
		cleanMapper.insert(clean);	
	}
}
