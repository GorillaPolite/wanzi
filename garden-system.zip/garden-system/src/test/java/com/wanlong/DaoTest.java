package com.wanlong;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.wanlong.dao.BillMapper;
import com.wanlong.dao.ComplainDao;
import com.wanlong.dao.TenderDao;
import com.wanlong.pojos.Bill;
import com.wanlong.pojos.BillExample;
import com.wanlong.pojos.Complain;
import com.wanlong.pojos.ComplainExample;
import com.wanlong.vo.TenderVo;

@RunWith(SpringRunner.class)
@SpringBootTest
@MapperScan("com.wanlong.dao")
public class DaoTest {
	@Autowired
	ComplainDao complainDao;
	@Autowired
	TenderDao tenderDao;
	@Autowired
	BillMapper billmapper;

	/**
	 * @category 测试投诉1
	 */
	@Test
	public void test1() {
		List<Complain> list2 = complainDao.findAll();
		for (Complain c : list2) {
			System.out.println(c.getCid() + "\t" + c.getContent());
		}
	}
	/**
	 * @category 测试联查1
	 */
	@Test
	public void test2() {
		List<TenderVo> list = tenderDao.findByTel("13201671827");
		for (TenderVo t : list) {
			System.out.println(t.getBidding().getArea());
		}
	}

	/**
	 * @category 测试投诉2
	 */
	@Test
	public void test4() {
		List<Complain> list2 = complainDao.findByState("未处理");
		for (Complain c : list2) {
			System.out.println(c.getCid() + "\t" + c.getContent());
		}
	}


}
