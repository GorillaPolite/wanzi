package com.wanlong.dao;

import com.wanlong.pojos.Adorn;
import com.wanlong.pojos.AdornExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

/**
 * @author Leett
 * @date 2020年11月16日 下午7:35:26
 * @category 装修数据访问接口
 */
public interface AdornDao {
	List<Adorn> findAll();
	List<Adorn> findByState(String state);
	
}