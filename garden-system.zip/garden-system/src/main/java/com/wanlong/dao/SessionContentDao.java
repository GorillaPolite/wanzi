package com.wanlong.dao;

import java.util.List;

import com.wanlong.pojos.SessionContent;

/**
 * @author Leett
 * @category 会话数据访问接口
 */
public interface SessionContentDao {
	List<SessionContent> findAll();
	int addOne(SessionContent content);
	int gorgeous(String gorgeous);
	List<SessionContent> findsources();
}
