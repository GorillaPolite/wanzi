package com.wanlong.dao;

import com.wanlong.pojos.Message;
import com.wanlong.pojos.MessageExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface MessageMapper {
    int countByExample(MessageExample example);

    int deleteByExample(MessageExample example);

    int deleteByPrimaryKey(Integer messid);

    /**
     * @category 添加通知
     * @param record
     * @return
     */
    int insert(Message record);

    int insertSelective(Message record);

    /**
     * @category 查找全部通知
     * @param example
     * @return
     */
    List<Message> selectByExample(MessageExample example);

    /**
     * @category 通过业主id查找相应的通知
     * @param oid
     * @return
     */
    List<Message> selectByOid(int oid);
    
    
    /**
     * @category 通过通知id查找id
     * @param missid
     * @return
     */
    Message selectByPrimaryKey(Integer missid);

    int updateByExampleSelective(@Param("record") Message record, @Param("example") MessageExample example);

    int updateByExample(@Param("record") Message record, @Param("example") MessageExample example);

    /**
     * @category 更新通知
     * @param record
     * @return
     */
    int updateByPrimaryKeySelective(Message record);

    int updateByPrimaryKey(Message record);
    
    /**
     * @category 通过业主id更新业主的通知状态
     * @param oid
     * @return
     */
    int updateByOid(int oid);
}