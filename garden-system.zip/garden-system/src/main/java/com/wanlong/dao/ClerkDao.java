
package com.wanlong.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.wanlong.pojos.Clerk;
/**
 * @author June
 * @category 职员数据访问接口
 */
public interface ClerkDao {

	/**
	 * @return 集合
	 * @category 查找所有职员
	 */
	public List<Clerk> find();
	/**
	 * @category 分页查询所有帖子
	 * @return
	 */
	List<Clerk> findPage();
	
	/**
	 * @param clerkname
	 * @return
	 * @category 搜索框模糊分页
	 */
	public List<Clerk> findPageByLike(@Param("like") String like);

	public Clerk findById(int clerkid);

	/**
	 * @param clerk
	 * @return 增加职员
	 */
	public int insert(Clerk clerk);

	/**
	 * @param ids
	 * @return 删除职员
	 */
	public int delete(int[] clerkids);

	/**
	 * @param clerk
	 * @return 更新职员信息
	 */
	public int update(Clerk clerk);
	
	public Clerk findStaffLoginTel(String cltel, String clpass);
}