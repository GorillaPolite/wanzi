package com.wanlong.dao;

import com.wanlong.pojos.Housenumber;
import com.wanlong.pojos.HousenumberExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface HousenumberMapper {
    int countByExample(HousenumberExample example);

    int deleteByExample(HousenumberExample example);

    int deleteByPrimaryKey(Integer homeid);

    int insert(Housenumber record);

    int insertSelective(Housenumber record);

    /**
     * @category 查询所有
     * @param example
     * @return
     */
    List<Housenumber> selectByExample(HousenumberExample example);

    Housenumber selectByPrimaryKey(Integer homeid);

    int updateByExampleSelective(@Param("record") Housenumber record);

    int updateByExample(@Param("record") Housenumber record, @Param("example") HousenumberExample example);

    /**
     * @category 更新什么就设置什么参数
     * @param record
     * @return
     */
    int updateByPrimaryKeySelective(Housenumber record);

    int updateByPrimaryKey(Housenumber record);
}