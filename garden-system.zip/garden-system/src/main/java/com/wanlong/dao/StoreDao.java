package com.wanlong.dao;

import com.wanlong.pojos.Store;
import com.wanlong.pojos.StoreExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

/**
 * @author Leett
 * @date 2020年11月16日 下午8:20:01
 * @category 商铺数据访问接口
 */
public interface StoreDao {
	
	/**
	 * 查找所有商铺
	 */
	List<Store> findAll();
	
	/**
	 * 通过查找所有商铺
	 */
	List<Store> findByState(String state);
}