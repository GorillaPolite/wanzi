package com.wanlong.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.wanlong.pojos.Supplies;

/**
 * @author June
 * @category 物料数据访问层
 */
public interface SuppliesDao {
   
	public List<Supplies> find();
	
	/**
	 * @param like
	 * @return
	 * @category 物料模糊查询
	 */
	public List<Supplies> findByLike(@Param("like")String like);
	
	public Supplies findById(int suppliesid);

	public int insert(Supplies supplies);

	public int delete(int[] suppliesids);

	public int update(Supplies supplies);
}