package com.wanlong.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.wanlong.pojos.Bidding;
import com.wanlong.pojos.Tender;
import com.wanlong.vo.TenderVo;

/**
 * @author Leett
 * @date 2020年11月17日 下午7:07:48
 * @category 竞标人数据访问接口
 */
public interface TenderDao {
	List<Tender> findAll(); 
	int addOne(Tender tender);
	List<TenderVo> findByTel(String tel);
	int deleteTenderOne(int tid);
	List<Tender> findByAudit(String audit);
	List<Tender> findByLiftstate(int liftstate);
	int refuse(@Param("tid")int tid,@Param("remaker")String remaker);
}
