package com.wanlong.dao;


import java.util.List;
import org.apache.ibatis.annotations.Param;

import com.wanlong.pojos.Maintain;
import com.wanlong.pojos.MaintainExample;

public interface MaintainMapper {
    int countByExample(MaintainExample example);

    int deleteByExample(MaintainExample example);

    int deleteByPrimaryKey(Integer mid);

	/* 用户维修登记 */
    int insert(Maintain record);

	/* 维修部门维修登记 */
    int insert2(Maintain record);
    
    int insertSelective(Maintain record);

    List<Maintain> selectByExampleWithBLOBs(MaintainExample example);
    /**
     * 查询所有的维修信息
     * @return
     */
    List<Maintain> selectByExample();

    Maintain selectByPrimaryKey(Integer mid);

    int updateByExampleSelective(@Param("record") Maintain record, @Param("example") MaintainExample example);

    int updateByExampleWithBLOBs(@Param("record") Maintain record, @Param("example") MaintainExample example);

    int updateByExample(@Param("record") Maintain record, @Param("example") MaintainExample example);

    int updateByPrimaryKeySelective(Maintain record);

    int updateByPrimaryKeyWithBLOBs(Maintain record);

    int updateByPrimaryKey(Maintain record);
    /**
   	 * 分类查询
   	 */
   	public  List<Maintain> findMaintainList(@Param("mbit")String mbit);
   	/**
   	 * 通过批量删除
   	 */
   	public int deleteAll(int[] mids );
   	/**
   	 * 更新信息
   	 * @param user
   	 * @return
   	 */
   	public int updatesave2(Maintain maintain);
   	/**
	 * 通过mid查找用户信息
	 * @return
	 */
	public Maintain findMaintainById(int mid);
	
	/* 完成后改变信息的方法 */
	
	public int updatmbit(Maintain maintain);
	/**
	 * 根据发起时间日期查询
	 */
	public  List<Maintain> findMaintainBymdate(String mdate);
	/**
	 * 根据结束时间日期查询
	 */
	public  List<Maintain> findMaintainBymfinishtime(String mfinishtime);
	
	
	public  List<Maintain> findMain(String md);
}