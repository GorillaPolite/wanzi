package com.wanlong.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.wanlong.pojos.Facility;

/**
 * @author June
 * @category 设备数据访问层
 */
public interface FacilityDao {
	/**
	 * @return 集合
	 * @category 查找所有设备
	 */
	public List<Facility> find();
	
	/**
	 * @param like
	 * @return
	 * @category 模糊查询
	 */
	public List<Facility> findLike(@Param("like") String like);

	public Facility findById(int facilityid);

	/**
	 * @param facility
	 * @return
	 * @category 添加设备
	 */
	public int insert(Facility facility);

	/**
	 * @param ids
	 * @return
	 * @category 删除设备
	 */
	public int delete(int[] facilityids);

	/**
	 * @param facility
	 * @return
	 * @category 更新设备
	 */
	public int update(Facility facility);
}