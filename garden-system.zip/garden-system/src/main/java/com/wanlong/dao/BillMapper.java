package com.wanlong.dao;

import com.wanlong.pojos.Bill;

import com.wanlong.pojos.Owner;

import java.util.List;

import org.apache.ibatis.annotations.Param;

/**
 * @author TOM
 * @category 账单数据访问接口
 *
 */
public interface BillMapper {

	/**
	 * @category 更新账单
	 * @param record
	 * @return
	 */
	int updateByPrimaryKeySelective(Bill record);

	/**
	 * @category 查找所有账单
	 * @return
	 */
	List<Bill> findAll();

	/**
	 * @category 返回用户集合
	 * @return
	 */
	List<Owner> findByOwner();

	/**
	 * @category 查询某个业主代缴费用的总和
	 * @return
	 */
	double selectTotal();

	int addBill(Bill bill);

	/**
	 * @category 分页查询
	 * @return
	 */
	List<Owner> findPage();

	/**
	 * @category 通过用户id查找用户
	 * @param oid
	 * @return
	 */
	List<Bill> findByOid(int[] oid);
	
	/**
	 * @category 通过oid查询owner对象未支付
	 * @param oid
	 * @return
	 */
	Owner findByOid1(int oid);
	
	/**
	 * @category 更改账单的订单号
	 * @param billnum
	 * @param bid
	 * @return
	 */
	int updateBillnum(@Param(value = "billnum") String bnum, @Param(value = "billids") int [] bid);
	
	/**
	 * @category 更改账单的支付状态
	 * @param bid
	 * @return
	 */
	int updateBillStatus(String billnum);
	
	/**
	 * @category 通过oid查询owner对象已支付
	 * @param oid
	 * @return
	 */
	Owner findByOid2(int oid);

}