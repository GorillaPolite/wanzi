package com.wanlong.dao;

import org.apache.ibatis.annotations.Param;

import com.wanlong.pojos.StaffLogin;

/**
 * 
 * @author mufeng
 * @category 员工登录数据访问实现
 *
 */
public interface StaffLoginDao {

	/**
	   * 根据电话查询
	 * @param cltei
	 * @return
	 */
	public StaffLogin findcltel(String cltei);
	/**
	  * 增加
	 * @param staffLogin
	 * @return
	 */
	public int addStaffLogin(StaffLogin staffLogin);
	/**
	  * 删除
	 * @param clerkid
	 * @return
	 */
	public int deleteStaffLogin(int clerkid);
	/**
	   * 根据电话和密码查找
	 * @param cltei
	 * @param clpass
	 * @return
	 */
	public StaffLogin findStaffLoginTel(@Param("cltei")String cltei,@Param("clpass")String clpass);
	/**
	 * 更新保存
	 */
	public int saveStaffLogin(StaffLogin staffLogin); 
	/**
	 *  通过用户id 查询
	 */
	public StaffLogin findByclerkid(int clerkid);
	
}
