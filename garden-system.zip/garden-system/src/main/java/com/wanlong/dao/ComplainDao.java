package com.wanlong.dao;

import com.wanlong.pojos.Complain;
import com.wanlong.pojos.ComplainExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

/**
 * @author Leett
 * @date 2020年11月16日 下午1:14:44
 * @category 投诉数据访问接口
 */
public interface ComplainDao {
	List<Complain> findAll();
	
	List<Complain> findByState(@Param("state")String state);
	
    int addOne(Complain complain); 
    
    List<Complain> findByOid(int uid);
   
}