package com.wanlong.dao;

import com.wanlong.pojos.Bill;
import com.wanlong.pojos.Billitems;
import com.wanlong.pojos.BillitemsExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface BillitemsMapper {
    int countByExample(BillitemsExample example);

    int deleteByExample(BillitemsExample example);

    int deleteByPrimaryKey(Integer billitemid);

    /**
     * @category 添加收费项目
     * @param record
     * @return
     */
    int insert(Billitems record);

    List<Billitems> selectByExample(BillitemsExample example);

    /**
     * @category 根据id查找
     * @param billitemid
     * @return
     */
    Billitems selectByPrimaryKey(Integer billitemid);

    /**
     * @category 更新
     * @param record
     * @return
     */
    int updateByPrimaryKeySelective(Billitems record);
    
    /**
     * @category 通过时间和名字查找收费项目
     * @param name
     * @param time
     * @return
     */
    Billitems selectByNameAndTime(String name,String time);
    

 
}