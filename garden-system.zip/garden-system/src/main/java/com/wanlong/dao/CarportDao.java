package com.wanlong.dao;

import com.wanlong.pojos.Carport;
import com.wanlong.pojos.CarportExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

/**
 * @author Leett
 * @date 2020年11月16日 下午5:32:10
 * @category 车位数据访问接口
 * 
 */
public interface CarportDao {
	List<Carport> findAll(@Param("num")int num,@Param("pageNum") int pageNum);
	
	List<Carport> findCarByArea(String area);
	
	List<Carport> findCarByState(String state);
	
	int sellCar(String duration);
	
	List<Carport> findMyCarSeat(int uid);
	
	int suresellcar(Carport carport);
	
	int updatetime();
}