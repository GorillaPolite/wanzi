package com.wanlong.dao;


import java.util.List;
import org.apache.ibatis.annotations.Param;

import com.wanlong.pojos.Afforest;
import com.wanlong.pojos.AfforestExample;

public interface AfforestMapper {
    int countByExample(AfforestExample example);

    int deleteByExample(AfforestExample example);

    int deleteByPrimaryKey(Integer afid);

    int insert(Afforest record);

    int insertSelective(Afforest record);

    List<Afforest> selectByExample();

    Afforest selectByPrimaryKey(Integer afid);

    int updateByExampleSelective(@Param("record") Afforest record, @Param("example") AfforestExample example);

    int updateByExample(@Param("record") Afforest record, @Param("example") AfforestExample example);

    int updateByPrimaryKeySelective(Afforest record);

    int updateByPrimaryKey(Afforest record);
    /**
   	 * 分类查询
   	 */
   	public  List<Afforest> findAfplushList(@Param("afplush")String afplush);
   	/**
   	 * 通过批量删除
   	 */
   	public int deleteAll(int[] afids );
   	/**
   	 * 更新信息
   	 * @param user
   	 * @return
   	 */
   	public int updatesave4(Afforest afforest);
   	/**
	 * 通过mid查找用户信息
	 * @return
	 */
	public Afforest findAfforestById(int afid);
	
	/* 完成后改变信息的方法 */
	
	public int updaaffomplish(Afforest afforest);
	/**
	 * 根据发起时间日期查询
	 */
	public  List<Afforest> findAfforestBymdate(String aftime);
	/**
	 * 根据结束时间日期查询
	 */
	public  List<Afforest> findAfforestBymfinishtime(String afdate);
	
	
	public  List<Afforest> findMainAfforest(String mda);
}