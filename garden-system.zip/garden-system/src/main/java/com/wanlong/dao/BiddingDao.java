package com.wanlong.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.wanlong.pojos.Bidding;

/**
 * @author Leett
 * @category 上架商铺数据访问接口
 *
 */
public interface BiddingDao {
	/**
	 * 添加一个竞标商铺
	 */
	int addOne(Bidding bidding);
	
	/**
	 *  下架一个竞标商铺
	 */
	int deleteOne(int bid);
	/**
	 *  查找竞标商铺
	 */
	List<Bidding> findAll();
	/**
	 *  更新喜欢信息
	 */
	int updateOne(int bid);
	
	/**
	 * 模糊查询
	 */
	List<Bidding> selectLike(@Param("text")String text);
	
	/**
	 * 通过审核
	 */
	int yesPass(int tid);
}
