package com.wanlong.dao;



import java.util.List;
import org.apache.ibatis.annotations.Param;

import com.wanlong.pojos.Clean;
import com.wanlong.pojos.CleanExample;


public interface CleanMapper {
    int countByExample(CleanExample example);

    int deleteByExample(CleanExample example);

    int deleteByPrimaryKey(Integer clid);

    int insert(Clean record);

    int insertSelective(Clean record);

    List<Clean> selectByExample();

    Clean selectByPrimaryKey(Integer clid);

    int updateByExampleSelective(@Param("record") Clean record, @Param("example") CleanExample example);

    int updateByExample(@Param("record") Clean record, @Param("example") CleanExample example);

    int updateByPrimaryKeySelective(Clean record);

    int updateByPrimaryKey(Clean record);
    /**
   	 * 分类查询
   	 */
   	public  List<Clean> findClieanList(@Param("claccomplish")String claccomplish);
   	/**
   	 * 通过批量删除
   	 */
   	public int deleteAll(int[] clids );
   	/**
   	 * 更新信息
   	 * @param user
   	 * @return
   	 */
   	public int updatesave3(Clean clean);
   	/**
	 * 通过mid查找用户信息
	 * @return
	 */
	public Clean findCleanById(int clid);
	
	/* 完成后改变信息的方法 */
	
	public int updaclaccomplish(Clean clean);
	/**
	 * 根据发起时间日期查询
	 */
	public  List<Clean> findCleanBymdate(String cltime);
	/**
	 * 根据结束时间日期查询
	 */
	public  List<Clean> findCleanBymfinishtime(String cldate);
	
	
	public  List<Clean> findMainClean(String mds);
	
	/* 根据员工编号来查询员工工作 */
	
	public List<Clean> fingwork(int clerkid);
}