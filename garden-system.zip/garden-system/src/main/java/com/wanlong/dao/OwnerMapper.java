package com.wanlong.dao;


import java.util.List;
import org.apache.ibatis.annotations.Param;

import com.wanlong.pojos.Maintain;
import com.wanlong.pojos.Owner;
import com.wanlong.pojos.OwnerExample;

/**
 * 
 * @author mufeng
 * @category 住户数据访问接口
 */
public interface OwnerMapper {
	
    int countByExample(OwnerExample example);

    int deleteByExample(OwnerExample example);

    int deleteByPrimaryKey(Integer oid);

    int insert(Owner record);

    int insertSelective(Owner record);
    
    /**
     * 查询所有用户
     * @param example
     * @return
     */
    List<Owner> selectByExample();

    Owner selectByPrimaryKey(Integer oid);

    int updateByExampleSelective(@Param("record") Owner record, @Param("example") OwnerExample example);

    int updateByExample(@Param("record") Owner record, @Param("example") OwnerExample example);

    int updateByPrimaryKeySelective(Owner record);

    int updateByPrimaryKey(Owner record);
    /**
     * @category 通过电话  密码查找用户
     * @param otel
     * @param opass
     * @return
     */
    Owner findOwnerTel(@Param("otel")String otel,@Param("opass")String opass);
    
    /**
	 * 通过tel查找用户信息
	 * @return
	 */
	public Owner findByTel(@Param("otel")String otel);
	/**
	 * 更新信息
	 * @param user
	 * @return
	 */
	public int updatesave(Owner owner);
	/**
	 * 业主更新信息
	 * @param user
	 * @return
	 */
	public int updateowner(Owner owner);
	/**
	 * 通过oid查找用户信息
	 * @return
	 */
	public Owner findById(int oid);
	/**
	 * 通过批量删除
	 */
	public int deleteAll(int[] oids );
	/**
	 * 分类查询
	 */
	public  List<Owner> findownerlist(@Param("towernum")int towernum );
	/**
	 * @category 分页查询所有帖子
	 * @return
	 */
	List<Owner> findPage();

	/* 模糊查询 */
	public  List<Owner> findMain(String mds);
    
}