package com.wanlong.service;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.wanlong.pojos.Complain;
import com.wanlong.pojos.ComplainExample;

/**
 * @author Leett
 * @date 2020年11月16日 上午10:19:56
 * @category 投诉表业务逻辑接口
 */
public interface ComplainService {
		List<Complain> findAll();
		
	    
	    List<Complain> findByState(String state);
	    
	    List<Complain> findByOid(int uid);

	    boolean addOne(Complain complain); 
}
