package com.wanlong.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wanlong.dao.CarportDao;
import com.wanlong.pojos.Carport;
import com.wanlong.service.CarportService;

/**
 * @author Leett
 * @date 2020年11月16日 下午5:34:39
 * @category 车位业务逻辑实现
 * 
 */
@Service
public class CarportServiceImpl implements CarportService {
	@Autowired
	CarportDao carportDao;

	@Override
	public List<Carport> findAll(int num, int pageNum) {
		return carportDao.findAll(num, pageNum);
	}

	@Override
	public List<Carport> findCarByArea(String area) {
		return carportDao.findCarByArea(area);
	}

	@Override
	public List<Carport> findCarByState(String state) {
		return carportDao.findCarByState(state);
	}

	@Override
	public boolean sellCar(String duration) {
		return carportDao.sellCar(duration) > 0 ? true : false;
	}

	@Override
	public List<Carport> findMyCarSeat(int uid) {
		return carportDao.findMyCarSeat(uid);
	}

	@Override
	public boolean suresellcar(Carport carport) {
		return carportDao.suresellcar(carport) > 0 ? true : false;
	}

	@Override
	public boolean updatetime() {
		return carportDao.updatetime() > 0 ? true : false;
	}

}
