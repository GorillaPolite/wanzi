package com.wanlong.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.wanlong.dao.ClerkDao;
import com.wanlong.pojos.Clerk;
import com.wanlong.service.ClerkService;
import com.wanlong.util.PageRequest;
import com.wanlong.util.PageResult;
import com.wanlong.util.PageUtils;

/**
 * @author June
 * @category 职员业务逻辑实现类
 */
@Service
public class ClerkServiceImpl implements ClerkService {
	@Autowired
	ClerkDao clerkDao;

	@Override
	public List<Clerk> find() {
		return clerkDao.find();
	}

	@Override
	public boolean insert(Clerk clerk) {
		return clerkDao.insert(clerk) > 0 ? true : false;
	}

	@Override
	public boolean update(Clerk clerk) {
		return clerkDao.update(clerk) > 0 ? true : false;
	}

	@Override
	public Clerk find(int clerkid) {
		return clerkDao.findById(clerkid);
	}

	@Override
	public boolean delete(int[] clerkids) {
		return clerkDao.delete(clerkids) > 0 ? true : false;
	}

	@Override
	public PageResult findPage(PageRequest pageRequest) {
		return PageUtils.getPageResult(pageRequest, getPageInfo(pageRequest));
	}

	/**
	   *  调用分页插件完成分页 
	 * @param pageQuery
	 * @return
	 */
	private PageInfo<Clerk> getPageInfo(PageRequest pageRequest) {
		int pageNum = pageRequest.getPageNum();
		int pageSize = pageRequest.getPageSize();
		PageHelper.startPage(pageNum, pageSize);
		List<Clerk> clerk = clerkDao.findPage();
		return new PageInfo<Clerk>(clerk);
	}
	/**
	 * 登录
	 */
	@Override
	public Clerk findStaffLoginTel(String cltel, String clpass) {
		return clerkDao.findStaffLoginTel(cltel, clpass);
	}
    //分页模糊查询
	@Override
	public PageResult findPageByLike(String like, PageRequest pageRequest) {
		return PageUtils.getPageResult(pageRequest, getPageLikeInfo(like, pageRequest));
	}

	private PageInfo<Clerk> getPageLikeInfo(String like,PageRequest pageRequest) {
		int pageNum = pageRequest.getPageNum();
		int pageSize = pageRequest.getPageSize();
		PageHelper.startPage(pageNum, pageSize);
		List<Clerk> clerk = clerkDao.findPageByLike(like);
		return new PageInfo<Clerk>(clerk);
	}
}
