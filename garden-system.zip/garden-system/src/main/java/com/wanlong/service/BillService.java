package com.wanlong.service;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.wanlong.pojos.Bill;
import com.wanlong.pojos.Owner;
import com.wanlong.util.PageRequest;
import com.wanlong.util.PageResult;

public interface BillService {

	List<Bill> findAll();

	int updateByPrimaryKeySelective(Bill record);

	List<Owner> findByOwner();

	int addBill(Bill bill);

	public PageResult findPage(PageRequest pageRequest);
	/**
	 * @category 通过用户id查找用户
	 * @param oid
	 * @return
	 */
	List<Bill> findByOid(int[] oid);
	
	/**
	 * @category 通过oid查询owner对象
	 * @param oid
	 * @return
	 */
	Owner findByOid1(int oid);
	/**
	 * @category 更改账单的订单号
	 * @param billnum
	 * @param bid
	 * @return
	 */
	int updateBillnum(@Param(value = "billnum") String bnum, @Param(value = "billids") int [] bid);
	
	/**
	 * @category 更改账单的支付状态
	 * @param bid
	 * @return
	 */
	int updateBillStatus(String billnum);
	/**
	 * @category 通过oid查询owner对象已支付
	 * @param oid
	 * @return
	 */
	Owner findByOid2(int oid);
}
