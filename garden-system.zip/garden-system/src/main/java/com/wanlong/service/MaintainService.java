package com.wanlong.service;

import java.util.List;

import com.wanlong.pojos.Maintain;
/**
 * 
 * @author mufeng
 * @category 数据访问接口
 */
public interface MaintainService {

	  /**
	   * 查询维修信息
	   */
	  public List<Maintain> selectByExample();
	  /**
	   * 分类查询所有维修信息
	   */
	  public List<Maintain>  findMaintainList(String mbit);
	  /**
	   * 批量删除
	   */
	  public boolean deleteAll(int[] mids );
	  /**
	   * 更新信息
	   */
	  public boolean updatesave2(Maintain maintain);
	    /**
		 * 通过id删除一个维修信息
		 */
	  public boolean deleteByPrimaryKey(int mid);
	   /**
		 *  保存住户维修信息上报
		 * @param user
		 * @return
		 */
	  public boolean insert(Maintain record);
	  /**
		 *  保存维修部门维修信息上报
		 * @param user
		 * @return
		 */
	  public boolean insert2(Maintain record);
	  
	/* 完成后状态更改 */
	  public boolean updatmbit(Maintain maintain);
	  /**
	   * 根据id查询所有的维修信息
	   * @param mid
	   * @return
	   */
	  public Maintain findMaintainById(int mid);
	  /**
		 * 根据发起时间日期查询
		 */
	  public  List<Maintain> findMaintainBymdate(String mdate);
		/**
		 * 根据结束时间日期查询
		 */
	  public  List<Maintain> findMaintainBymfinishtime(String mfinishtime);
	  
	  public  List<Maintain> findMain(String md);
}
