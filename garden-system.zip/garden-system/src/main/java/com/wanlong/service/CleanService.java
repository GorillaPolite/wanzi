package com.wanlong.service;

import java.util.List;

import com.wanlong.pojos.Clean;

/**
 * 
 * @author mufeng
 * @category 保洁业务逻辑接口
 */
public interface CleanService {

	  /**
	   * 查询保洁信息
	   */
	  public List<Clean> selectByExample();
	  /**
	   * 分类查询所有保洁信息
	   */
	  public List<Clean>  findClieanList(String claccomplish);
	  /**
	   * 批量删除
	   */
	  public boolean deleteAll(int[] clids );
	  /**
	   * 更新信息
	   */
	  public boolean updatesave3(Clean clean);
	    /**
		 * 通过id删除一个保洁信息
		 */
	  public boolean deleteByPrimaryKey(int clid);
	   /**
		 *  保存保洁维修信息上报
		 * @param user
		 * @return
		 */
	  public boolean insert(Clean record);
	 
	  
	/* 完成后状态更改 */
	  public boolean updaclaccomplish(Clean clean);
	  /**
	   * 根据id查询所有的信息
	   * @param mid
	   * @return
	   */
	  public Clean findCleanById(int clid);
	  /**
		 * 根据发起时间日期查询
		 */
	  public  List<Clean> findCleanBymdate(String cltime);
		/**
		 * 根据结束时间日期查询
		 */
	  public  List<Clean> findCleanBymfinishtime(String cldate);
	  
	  public  List<Clean> findMainClean(String mds);
	  
	  public List<Clean> fingwork(int clerkid);
}

