package com.wanlong.service;

import java.util.List;

import com.wanlong.pojos.Tender;
import com.wanlong.vo.TenderVo;

/**
 * @author Leett
 * @date 2020年11月17日 下午7:08:59
 * @category 竞标者业务逻辑接口
 */
public interface TenderService {
	List<Tender> findAll(); 
	boolean addOne(Tender tender);
	List<TenderVo> findByTel(String tel);
	boolean deleteTenderOne(int tid);
	List<Tender> findByAudit(String audit);
	List<Tender> findByLiftstate(int liftstate);
	boolean refuse(int tid,String remaker);
}
