package com.wanlong.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wanlong.dao.SuppliesDao;
import com.wanlong.pojos.Supplies;
import com.wanlong.service.SuppliesService;

/**
 * @author June
 * @category 物料业务逻辑实现类
 */
@Service
public class SuppliesServiceImpl implements SuppliesService {
	@Autowired
	SuppliesDao suppliesDao;

	@Override
	public List<Supplies> find() {
		return suppliesDao.find();
	}

	@Override
	public Supplies findById(int id) {
		return suppliesDao.findById(id);
	}

	@Override
	public boolean insert(Supplies supplies) {
		return suppliesDao.insert(supplies) > 0 ? true : false;
	}

	@Override
	public boolean delete(int[] ids) {
		return suppliesDao.delete(ids) > 0 ? true : false;
	}

	@Override
	public boolean update(Supplies supplies) {
		return suppliesDao.update(supplies) > 0 ? true : false;
	}

	@Override
	public List<Supplies> findByLike(String like) {
		
		return suppliesDao.findByLike(like);
	}

}
