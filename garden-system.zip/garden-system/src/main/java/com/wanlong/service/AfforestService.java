package com.wanlong.service;

import java.util.List;

import com.wanlong.pojos.Afforest;



/**
 * 
 * @author mufeng
 * @category 绿化的业务逻辑接口
 */
public interface AfforestService {

	 /**
	   * 查询保洁信息
	   */
	  public List<Afforest> selectByExample();
	  /**
	   * 分类查询所有保洁信息
	   */
	  public List<Afforest>  findAfplushList(String afplush);
	  /**
	   * 批量删除
	   */
	  public boolean deleteAll(int[] afids );
	  /**
	   * 更新信息
	   */
	  public boolean updatesave4(Afforest Afforest);
	    /**
		 * 通过id删除一个保洁信息
		 */
	  public boolean deleteByPrimaryKey(int afid);
	   /**
		 *  保存保洁维修信息上报
		 * @param user
		 * @return
		 */
	  public boolean insert(Afforest record);
	 
	  
	/* 完成后状态更改 */
	  public boolean updaaffomplish(Afforest afforest);
	  /**
	   * 根据id查询所有的信息
	   * @param mid
	   * @return
	   */
	  public Afforest findAfforestById(int afid);
	  /**
		 * 根据发起时间日期查询
		 */
	  public  List<Afforest> findAfforestBymdate(String aftime);
		/**
		 * 根据结束时间日期查询
		 */
	  public  List<Afforest> findAfforestBymfinishtime(String afdate);
	  
	  public  List<Afforest> findMainAfforest(String mda);
}
