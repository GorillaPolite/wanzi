package com.wanlong.service;

import java.util.List;

import com.wanlong.pojos.Adorn;

/**
 * @author Leett
 * @date 2020年11月16日 下午7:35:09
 * @category 装修业务逻辑接口
 */
public interface AdornService {
	List<Adorn> findAll();
	
	List<Adorn> findByState(String state);
}
