package com.wanlong.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wanlong.dao.BiddingDao;
import com.wanlong.pojos.Bidding;
import com.wanlong.service.BiddingService;

@Service
public class BiddingServiceImpl implements BiddingService {
	@Autowired
	BiddingDao biddingDao;

	@Override
	public boolean addOne(Bidding bidding) {
		return biddingDao.addOne(bidding) > 0 ? true : false;
	}

	@Override
	public boolean deleteOne(int bid) {
		return biddingDao.deleteOne(bid) > 0 ? true : false;
	}

	@Override
	public List<Bidding> findAll() {
		return biddingDao.findAll();
	}

	@Override
	public boolean updateOne(int bid) {
		return biddingDao.updateOne(bid) > 0 ? true : false;
	}

	@Override
	public List<Bidding> selectLike(String text) {
		return biddingDao.selectLike(text);
	}

	@Override
	public boolean yesPass(int tid) {
		return biddingDao.yesPass(tid) > 0 ? true : false;
	}

}
