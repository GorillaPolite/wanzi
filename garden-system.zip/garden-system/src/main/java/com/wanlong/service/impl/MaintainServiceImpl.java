package com.wanlong.service.impl;

import java.text.SimpleDateFormat;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wanlong.dao.MaintainMapper;
import com.wanlong.pojos.Maintain;
import com.wanlong.service.MaintainService;
/**
 * 
 * @author mufeng
 * @category 业务功能实现
 */
@Service
public class MaintainServiceImpl implements MaintainService {

	@Autowired
	MaintainMapper maintaMapper;
	/**
	 * 查询所有维修信息
	 */
	@Override
	public List<Maintain> selectByExample() {
		
		return maintaMapper.selectByExample();
	}
	/**
	 * 分类查询所有维修信息
	 */
	@Override
	public List<Maintain> findMaintainList(String mbit) {
		
		return maintaMapper.findMaintainList(mbit);
	}
    /**
     * 批量删除
     */
	@Override
	public boolean deleteAll(int[] mids) {
		return maintaMapper.deleteAll(mids)> 0 ? true : false;
	}
    /**
     * 更新保存信息信息
     */
	@Override
	public boolean updatesave2(Maintain maintain) {
		int i=maintaMapper.updatesave2(maintain);
		if (i != 0) {
			return true;
		} else {
			return false;
		}
	}
	@Override
	public boolean updatmbit(Maintain maintain) {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		java.util.Date date = new java.util.Date();
		String long1 = format.format(date);
		maintain.setMfinishtime(long1);
		return maintaMapper.updatmbit(maintain) > 0 ? true : false;
	}
    /**
     * 删除一个
     */
	@Override
	public boolean deleteByPrimaryKey(int mid) {
		return maintaMapper.deleteByPrimaryKey(mid) > 0 ? true : false;
	}
    /**
     * 住户上报信息
     */   
	@Override
	public boolean insert(Maintain record) {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		java.util.Date date = new java.util.Date();
		String long1 = format.format(date);
	    record.setMdate(long1);
		return maintaMapper.insert(record) > 0 ? true : false;
	}
	/**
     * 维修部门上报信息
     */   
	@Override
	public boolean insert2(Maintain record) {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		java.util.Date date = new java.util.Date();
		String long1 = format.format(date);
	    record.setMdate(long1);
		return maintaMapper.insert2(record) > 0 ? true : false;
	}
	@Override
	public Maintain findMaintainById(int mid) {
		return maintaMapper.findMaintainById(mid);
	}
	/**
	 * 根据发起时间日期查询
	 */
	@Override
	public  List<Maintain> findMaintainBymdate(String mdate) {
		return maintaMapper.findMaintainBymdate(mdate);
	}
	/**
	 * 根据结束时间日期查询
	 */
	@Override
	public  List<Maintain> findMaintainBymfinishtime(String mfinishtime) {
		return maintaMapper.findMaintainBymfinishtime(mfinishtime);
	}
	@Override
	public List<Maintain> findMain(String md) {
		return maintaMapper.findMain(md);
	}

	
}
