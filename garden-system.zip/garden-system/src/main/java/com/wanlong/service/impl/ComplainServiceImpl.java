package com.wanlong.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wanlong.dao.ComplainDao;
import com.wanlong.pojos.Complain;
import com.wanlong.service.ComplainService;
@Service
public class ComplainServiceImpl implements ComplainService {
	@Autowired
	ComplainDao complainDao;

	@Override
	public List<Complain> findByState(String state) {
		return complainDao.findByState(state);
	}

	@Override
	public List<Complain> findAll() {
		return complainDao.findAll();
	}

	@Override
	public boolean addOne(Complain complain) {
		return complainDao.addOne(complain)>0?true:false;
	}

	@Override
	public List<Complain> findByOid(int uid) {
		return complainDao.findByOid(uid);
	}

}
