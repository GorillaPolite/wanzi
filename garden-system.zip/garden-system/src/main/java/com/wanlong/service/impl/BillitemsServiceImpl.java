package com.wanlong.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wanlong.dao.BillitemsMapper;
import com.wanlong.pojos.Billitems;
import com.wanlong.pojos.BillitemsExample;
import com.wanlong.service.BillitemsService;


/**
 * @author Tom
 * @category 收费项目的业务实现
 *
 */
@Service
public class BillitemsServiceImpl implements BillitemsService {

	@Autowired
	private BillitemsMapper bMapper;
	
	@Override
	public int insert(Billitems record) {
		
		return bMapper.insert(record);
	}

	@Override
	public List<Billitems> selectByExample(BillitemsExample example) {
		
		return bMapper.selectByExample(example);
	}

	@Override
	public Billitems selectByPrimaryKey(Integer billitemid) {
		
		return bMapper.selectByPrimaryKey(billitemid);
	}

	@Override
	public int updateByPrimaryKeySelective(Billitems record) {
		
		return bMapper.updateByPrimaryKeySelective(record);
	}

	@Override
	public Billitems selectByNameAndTime(String name, String time) {
		
		return bMapper.selectByNameAndTime(name, time) ;
	}

}
