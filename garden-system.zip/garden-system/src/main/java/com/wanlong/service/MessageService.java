package com.wanlong.service;

import java.util.List;

import com.wanlong.pojos.Message;
import com.wanlong.pojos.MessageExample;

public interface MessageService {

	/**
	 * @category 查找全部通知
	 * @param example
	 * @return
	 */
	List<Message> selectByExample(MessageExample example);

	/**
	 * @category 通过业主id查找相应的通知
	 * @param oid
	 * @return
	 */
	List<Message> selectByOid(int oid);

	/**
	 * @category 通过通知id查找id
	 * @param missid
	 * @return
	 */
	Message selectByPrimaryKey(Integer messid);

	/**
	 * @category 更新通知
	 * @param record
	 * @return
	 */
	int updateByPrimaryKeySelective(Message record);

	/**
	 * @category 通过业主id更新业主的通知状态
	 * @param oid
	 * @return
	 */
	int updateByOid(int oid);

	/**
	 * @category 添加通知
	 * @param record
	 * @return
	 */
	int insert(Message record);
}
