package com.wanlong.service;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.wanlong.pojos.Clerk;
import com.wanlong.util.PageRequest;
import com.wanlong.util.PageResult;

/**
 * @author June
 * @category 职员业务逻辑实现接口
 */
public interface ClerkService {
	/**
	 * @return
	 * @category 查找所有职员
	 */
	public List<Clerk> find();
	
	/**
	 * @param pageRequest
	 * @return
	 * @category 分页查询
	 */
	public PageResult findPage(PageRequest pageRequest);
	/**
	 * @param like
	 * @return
	 * @category 模糊分页搜索框查询
	 */
	public  PageResult findPageByLike(@Param("like") String like,PageRequest pageRequest);
	
	/**
	 * @param id
	 * @return
	 * @category  查找所有职员，按照id查询
	 */
	public Clerk find(int clerkid);

	/**
	 * @param clerk
	 * @return
	 * @category 添加职员信息
	 */
	public boolean insert(Clerk clerk);

	/**
	 * @param ids
	 * @return
	 * @category 删除职员信息
	 */
	public boolean delete(int[] clerkids);

	/**
	 * @param clerk
	 * @return
	 * @category 更新职员信息
	 */
	public boolean update(Clerk clerk);

	
	public Clerk findStaffLoginTel(String cltel,String clpass);
}
