package com.wanlong.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wanlong.dao.TenderDao;
import com.wanlong.pojos.Tender;
import com.wanlong.service.TenderService;
import com.wanlong.vo.TenderVo;
/**
 * @author Leett
 * @date 2020年11月17日 下午7:10:34
 * @category 竞标者业务逻辑实现
 */
@Service
public class TenderServiceImpl implements TenderService {
	@Autowired
	TenderDao tenderDao;
	@Override
	public List<Tender> findAll() {
		return tenderDao.findAll();
	}
	@Override
	public boolean addOne(Tender tender) {
		return tenderDao.addOne(tender)>0?true:false;
	}
	@Override
	public List<TenderVo> findByTel(String tel) {
		return tenderDao.findByTel(tel);
	}
	@Override
	public boolean deleteTenderOne(int tid) {
		return tenderDao.deleteTenderOne(tid)>0?true:false;
	}
	@Override
	public List<Tender> findByAudit(String audit) {
		return tenderDao.findByAudit(audit);
	}
	@Override
	public List<Tender> findByLiftstate(int liftstate) {
		return tenderDao.findByLiftstate(liftstate);
	}
	@Override
	public boolean refuse(int tid,String remaker) {
		return tenderDao.refuse(tid,remaker)>0?true:false;
	}

}
