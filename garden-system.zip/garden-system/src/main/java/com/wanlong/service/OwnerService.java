package com.wanlong.service;


import java.util.List;

import com.wanlong.pojos.Maintain;
import com.wanlong.pojos.Owner;
import com.wanlong.util.PageRequest;
import com.wanlong.util.PageResult;

/**
 * 
 * @author mufeng
 * @category 用户的业务访问接口
 */
public interface OwnerService {
	
  /**
   * @category 通过用户的电话和密码来查找用户
   * @param otel 电话
   * @param opass 密码
   * @return 返回客户
   */
  public Owner findOwnerTel(String otel,String opass);
  /**
          *     通过电话查询用户信息
   * @param otel
   * @return
   */
  public String findByTel(String otel);
  Owner findByTel1(String otel);
  /**
	 *  保存客户信息，详情注册
	 * @param user
	 * @return
	 */
  public boolean insert(Owner record);
  /**
   * 查询所有用户
   */
  public List<Owner> selectByExample();
  /**
   * 分类查询所有用户
   */
  public List<Owner>  findownerlist(int towernum);
  /**
	 * @category 更新操作
	 * @param user
	 * @return
	 */
  public boolean updatesave(Owner owner);
  
  
  public boolean updateowner(Owner owner);
  
  public Owner findById(int oid);
    /**
	 * 通过id删除一个住户
	 */
  public boolean deleteByPrimaryKey(int oid);
  /**
   * 批量删除
   */
  public boolean deleteAll(int[] oids );
  /**
	 * @param pageRequest
	 * @return
	 * @category 分页查询
	 */
 public PageResult findPage(PageRequest pageRequest);
 
 public  List<Owner> findMain(String mds);
}
