package com.wanlong.service;

import java.util.List;

import com.wanlong.pojos.SessionContent;

/**
 * @author Leett
 * @category 会话业务逻辑接口
 *
 */
public interface SessionContentService {
	List<SessionContent> findAll();
	boolean addOne(SessionContent content);
	boolean gorgeous(String gorgeous);
	List<SessionContent> findsources();
}
