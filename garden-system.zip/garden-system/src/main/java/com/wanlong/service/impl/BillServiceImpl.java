package com.wanlong.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.wanlong.dao.BillMapper;
import com.wanlong.pojos.Bill;
import com.wanlong.pojos.BillExample;
import com.wanlong.pojos.Owner;
import com.wanlong.service.BillService;
import com.wanlong.util.PageRequest;
import com.wanlong.util.PageResult;
import com.wanlong.util.PageUtils;

@Service
public class BillServiceImpl implements BillService {
	
	@Autowired 
	private BillMapper billMapper;
	
	

	@Override
	public int updateByPrimaryKeySelective(Bill record) {

		return billMapper.updateByPrimaryKeySelective(record);
	}



	@Override
	public List<Bill> findAll() {
		
		return billMapper.findAll();
	}



	@Override
	public List<Owner> findByOwner() {
		
		return billMapper.findByOwner();
	}



	@Override
	public int addBill(Bill bill) {
		
		return billMapper.addBill(bill);
	}



	@Override
	public PageResult findPage(PageRequest pageRequest) {
		
		return PageUtils.getPageResult(pageRequest, getPageInfo(pageRequest));
	}
	private PageInfo<Owner> getPageInfo(PageRequest pageRequest) {
        int pageNum = pageRequest.getPageNum();
        int pageSize = pageRequest.getPageSize();
        PageHelper.startPage(pageNum, pageSize);
        List<Owner> invitation = billMapper.findPage();
        return new PageInfo<Owner>(invitation);
    }



	@Override
	public List<Bill> findByOid(int[] oid) {
		
		return billMapper.findByOid(oid);
	}



	@Override
	public Owner findByOid1(int oid) {
		
		return billMapper.findByOid1(oid);
	}



	@Override
	public int updateBillnum(String bnum, int[] bid) {
		
		return billMapper.updateBillnum(bnum, bid);
	}



	@Override
	public int updateBillStatus(String billnum) {
		
		return billMapper.updateBillStatus(billnum);
	}



	@Override
	public Owner findByOid2(int oid) {
		
		return billMapper.findByOid2(oid);
	}



	

}
