package com.wanlong.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wanlong.dao.SessionContentDao;
import com.wanlong.pojos.SessionContent;
import com.wanlong.service.SessionContentService;

/**
 * @author Leett
 * @category 会话业务逻辑实现
 *
 */
@Service
public class SessionContentServiceImpl implements SessionContentService {

	@Autowired
	SessionContentDao sessionContentDao;
	@Override
	public List<SessionContent> findAll() {
		return sessionContentDao.findAll();
	}
	@Override
	public boolean addOne(SessionContent content) {
		return sessionContentDao.addOne(content)>0?true:false;
	}
	
	@Override
	public boolean gorgeous(String gorgeous) {
		return sessionContentDao.gorgeous(gorgeous) > 0 ? true : false;
	}
	@Override
	public List<SessionContent> findsources() {
		return sessionContentDao.findsources();
	}

}
