package com.wanlong.service.impl;

import java.text.SimpleDateFormat;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.wanlong.dao.OwnerMapper;
import com.wanlong.pojos.Maintain;
import com.wanlong.pojos.Owner;
import com.wanlong.service.OwnerService;
import com.wanlong.util.PageRequest;
import com.wanlong.util.PageResult;
import com.wanlong.util.PageUtils;

/**
 * 
 * @author mufeng
 * @category 住户业务功能实现
 */

@Service
public class OwmerServiceImpl implements OwnerService {

	@Autowired
	OwnerMapper ownerMapper;

	@Override
	public Owner findOwnerTel(String otel, String opass) {
		return ownerMapper.findOwnerTel(otel, opass);
	}

	@Override
	public String findByTel(String otel) {
		Owner owner = ownerMapper.findByTel(otel);
		if (owner == null) {
			return "true";
		} else {
			return "false";
		}
	}

	/**
	 * 详细信息保存
	 */
	@Override
	public boolean insert(Owner record) {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		java.util.Date date = new java.util.Date();
		String long1 = format.format(date);
		record.setOiputdate(long1);
		return ownerMapper.insert(record) > 0 ? true : false;
	}

	/**
	 * 查询住户集合
	 */
	@Override
	public List<Owner> selectByExample() {
		return ownerMapper.selectByExample();
	}

	@Override
	public boolean updatesave(Owner owner) {
		int i = ownerMapper.updatesave(owner);
		if (i != 0) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean updateowner(Owner owner) {
		int i = ownerMapper.updateowner(owner);
		if (i != 0) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * 通过ID查询
	 */
	@Override
	public Owner findById(int oid) {
		return ownerMapper.findById(oid);
	}

	/**
	 * 通过id删除一个住户
	 */
	public boolean deleteByPrimaryKey(int oid) {
		return ownerMapper.deleteByPrimaryKey(oid) > 0 ? true : false;
	}

	@Override
	public boolean deleteAll(int[] oids) {

		return ownerMapper.deleteAll(oids) > 0 ? true : false;
	}

	/**
	 * 分类查询住户集合
	 */
	@Override
	public List<Owner> findownerlist(int towernum) {
		return ownerMapper.findownerlist(towernum);
	}

	@Override
	public Owner findByTel1(String otel) {
		return ownerMapper.findByTel(otel);
	}

	@Override
	public PageResult findPage(PageRequest pageRequest) {
		return PageUtils.getPageResult(pageRequest, getPageInfo(pageRequest));
	}

	/**
	   *  调用分页插件完成分页 
	 * @param pageQuery
	 * @return
	 */
	private PageInfo<Owner> getPageInfo(PageRequest pageRequest) {
		int pageNum = pageRequest.getPageNum();
		int pageSize = pageRequest.getPageSize();
		PageHelper.startPage(pageNum, pageSize);
		List<Owner> owner = ownerMapper.findPage();
		return new PageInfo<Owner>(owner);
	}
	
	@Override
	public List<Owner> findMain(String mds) {
		return ownerMapper.findMain(mds);
	}
	
}