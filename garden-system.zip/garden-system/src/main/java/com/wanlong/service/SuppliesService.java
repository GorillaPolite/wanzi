package com.wanlong.service;

import java.util.List;
import com.wanlong.pojos.Supplies;

/**
 * @author June
 * @category 物料业务逻辑接口
 */
public interface SuppliesService {
	  
		public List<Supplies> find();
		
		/**
		 * @param like
		 * @return
		 * @category 模糊查询
		 */
		public List<Supplies> findByLike(String like);
		
		public Supplies findById(int id);

		public boolean insert(Supplies supplies);

		public boolean delete(int[] ids);

		public boolean update(Supplies supplies);
}
