package com.wanlong.service;

import java.util.List;

import com.wanlong.pojos.Facility;

/**
 * @author June
 * @category 设备业务逻辑类
 */
public interface FacilityService {
	/**
	 * @category 查询所有设备信息
	 */
	public List<Facility> find();
	/**
	 * @param like
	 * @return
	 * @category  模糊查询
	 */
	public List<Facility> findLike(String like);
	/**
	 * @param id
	 * @return
	 * @category 查询所有设备信息
	 */
	public Facility find(int facilityid);

	public boolean insert(Facility facility);

	public boolean delete(int[] facilityids);

	public boolean update(Facility facility);

}
