package com.wanlong.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wanlong.dao.HousenumberMapper;
import com.wanlong.pojos.Housenumber;
import com.wanlong.pojos.HousenumberExample;
import com.wanlong.service.HouseNumberService;
@Service
public class HouseNumberServiceImpl implements HouseNumberService {
	@Autowired
	private HousenumberMapper houseMapper;
	
	@Override
	public int countByExample(HousenumberExample example) {
	
		return 0;
	}

	@Override
	public int deleteByExample(HousenumberExample example) {
		
		return 0;
	}

	@Override
	public int deleteByPrimaryKey(Integer homeid) {
		
		return 0;
	}

	@Override
	public int insert(Housenumber record) {
		
		return houseMapper.insert(record);
	}

	@Override
	public int insertSelective(Housenumber record) {
		
		return 0;
	}

	@Override
	public List<Housenumber> selectByExample(HousenumberExample example) {
		
		return houseMapper.selectByExample(example);
	}

	@Override
	public Housenumber selectByPrimaryKey(Integer homeid) {
		
		return houseMapper.selectByPrimaryKey(homeid);
	}

	@Override
	public int updateByExampleSelective(Housenumber record, HousenumberExample example) {
		
		return 0;
	}

	@Override
	public int updateByExample(Housenumber record, HousenumberExample example) {
		
		return 0;
	}

	@Override
	public int updateByPrimaryKeySelective(Housenumber record) {
		
		return houseMapper.updateByPrimaryKeySelective(record);
	}

	@Override
	public int updateByPrimaryKey(Housenumber record) {
		
		return 0;
	}

}
