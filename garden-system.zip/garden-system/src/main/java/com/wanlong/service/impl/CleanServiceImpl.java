package com.wanlong.service.impl;

import java.text.SimpleDateFormat;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wanlong.dao.CleanMapper;
import com.wanlong.pojos.Clean;
import com.wanlong.service.CleanService;

@Service
public class CleanServiceImpl implements CleanService {

	@Autowired
	CleanMapper cleanMapper;
	@Override
	public List<Clean> selectByExample() {
		return cleanMapper.selectByExample();
	}

	/**
	 * 分类查询所有信息
	 */
	@Override
	public List<Clean> findClieanList(String claccomplish) {
		return cleanMapper.findClieanList(claccomplish);
	}

	@Override
	public boolean deleteAll(int[] clids) {
		return cleanMapper.deleteAll(clids)> 0 ? true : false;
	}

	@Override
	public boolean updatesave3(Clean clean) {
		return cleanMapper.updatesave3(clean)> 0 ? true : false;
	}

	@Override
	public boolean deleteByPrimaryKey(int clid) {
		return cleanMapper.deleteByPrimaryKey(clid)> 0 ? true : false;
	}

	@Override
	public boolean insert(Clean record) {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		java.util.Date date = new java.util.Date();
		String long1 = format.format(date);
	    record.setCltime(long1);
		return cleanMapper.insert(record)> 0 ? true : false;
	}

	@Override
	public boolean updaclaccomplish(Clean clean) {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		java.util.Date date = new java.util.Date();
		String long1 = format.format(date);
		clean.setCldate(long1);
		return cleanMapper.updaclaccomplish(clean)>0?true:false;
	}

	@Override
	public Clean findCleanById(int clid) {
		
		return cleanMapper.findCleanById(clid);
	}

	@Override
	public List<Clean> findCleanBymdate(String cltime) {
		return cleanMapper.findCleanBymdate(cltime);
	}

	@Override
	public List<Clean> findCleanBymfinishtime(String cldate) {
		
		return cleanMapper.findCleanBymfinishtime(cldate);
	}

	@Override
	public List<Clean> findMainClean(String mds) {
		
		return cleanMapper.findMainClean(mds);
	}

	@Override
	public List<Clean> fingwork(int clerkid) {
		return cleanMapper.fingwork(clerkid);
	}

}
