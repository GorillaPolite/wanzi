package com.wanlong.service;

import java.util.List;

import com.wanlong.pojos.Bidding;

/**
 * @author Leett
 * @category 竞标商铺业务逻辑访问接口
 *
 */
public interface BiddingService {
	/**
	 * 添加一个竞标商铺
	 */
	boolean addOne(Bidding bidding);
	
	/**
	 *  下架一个竞标商铺
	 */
	/**
	 *  查找竞标商铺
	 */
	List<Bidding> findAll();
	boolean updateOne(int bid);

	boolean deleteOne(int bid);
	
	/**
	 * 模糊查询
	 */
	List<Bidding> selectLike(String text);
	
	boolean yesPass(int tid);
}
