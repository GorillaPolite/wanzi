package com.wanlong.service;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.wanlong.pojos.Housenumber;
import com.wanlong.pojos.HousenumberExample;

/**
 * @author Tom
 * @category 房产资源管理业务接口
 *
 */
public interface HouseNumberService {

	int countByExample(HousenumberExample example);

    int deleteByExample(HousenumberExample example);

    int deleteByPrimaryKey(Integer homeid);

    int insert(Housenumber record);

    int insertSelective(Housenumber record);

    List<Housenumber> selectByExample(HousenumberExample example);

    Housenumber selectByPrimaryKey(Integer homeid);

    int updateByExampleSelective(@Param("record") Housenumber record, @Param("example") HousenumberExample example);

    int updateByExample(@Param("record") Housenumber record, @Param("example") HousenumberExample example);

    int updateByPrimaryKeySelective(Housenumber record);

    int updateByPrimaryKey(Housenumber record);
	
}
