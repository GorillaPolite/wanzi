package com.wanlong.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wanlong.dao.FacilityDao;
import com.wanlong.pojos.Facility;
import com.wanlong.service.FacilityService;

/**
 * @author June
 * @category 设备业务逻辑实现类
 */
@Service
public class FacilityServiceImpl implements FacilityService {
	@Autowired
	FacilityDao facilityDao;
	
	@Override
	public List<Facility> find() {
		return facilityDao.find();
	}

	@Override
	public Facility find(int facilityid) {
		return facilityDao.findById(facilityid);
	}

	@Override
	public boolean insert(Facility facility) {
		return facilityDao.insert(facility)>0?true:false;
	}

	@Override
	public boolean delete(int[] facilityids) {
		return facilityDao.delete(facilityids)>0?true:false;
	}

	@Override
	public boolean update(Facility facility) {
		return facilityDao.update(facility)>0?true:false;
	}

	@Override
	public List<Facility> findLike(String like) {
		return facilityDao.findLike(like);
	}

}
