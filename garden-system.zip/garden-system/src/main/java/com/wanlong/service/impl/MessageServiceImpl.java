package com.wanlong.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wanlong.dao.MessageMapper;
import com.wanlong.pojos.Message;
import com.wanlong.pojos.MessageExample;
import com.wanlong.service.MessageService;

@Service
public class MessageServiceImpl implements MessageService {
	
	@Autowired
	private MessageMapper messMapper;
	
	@Override
	public List<Message> selectByExample(MessageExample example) {
		
		return messMapper.selectByExample(example);
	}

	@Override
	public List<Message> selectByOid(int oid) {
		
		return messMapper.selectByOid(oid);
	}

	@Override
	public Message selectByPrimaryKey(Integer messid) {
		
		return messMapper.selectByPrimaryKey(messid);
	}

	@Override
	public int updateByPrimaryKeySelective(Message record) {
		
		return messMapper.updateByPrimaryKeySelective(record);
	}

	@Override
	public int updateByOid(int oid) {
		
		return messMapper.updateByOid(oid);
	}

	@Override
	public int insert(Message record) {
		
		return messMapper.insert(record);
	}

}
