package com.wanlong.service;

import java.util.List;

import com.wanlong.pojos.Carport;

/**
 * @author Leett
 * @date 2020年11月16日 下午5:33:24
 * @category 车位业务逻辑
 */
public interface CarportService {
	List<Carport> findAll(int num,int pageNum);
	
	List<Carport> findCarByArea(String area);
	
	List<Carport> findCarByState(String state);
	
	boolean sellCar(String duration);
	
	List<Carport> findMyCarSeat(int uid);
	
	boolean suresellcar(Carport carport);
	
	boolean updatetime();
}
