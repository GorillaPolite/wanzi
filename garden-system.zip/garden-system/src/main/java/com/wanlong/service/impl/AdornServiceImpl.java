package com.wanlong.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wanlong.dao.AdornDao;
import com.wanlong.pojos.Adorn;
import com.wanlong.service.AdornService;

/**
 * @author Leett
 * @date 2020年11月16日 下午7:36:23
 * @category 装修业务逻辑实现
 */
@Service
public class AdornServiceImpl implements AdornService {
	@Autowired
	AdornDao adornDao;
	@Override
	public List<Adorn> findAll() {
		return adornDao.findAll();
	}
	@Override
	public List<Adorn> findByState(String state) {
		return adornDao.findByState(state);
	}

}
