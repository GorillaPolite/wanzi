package com.wanlong.service;

import java.util.List;

import com.wanlong.pojos.Store;

/**
 * @author Leett
 * @date 2020年11月16日 下午8:22:42
 * @category 
 */
public interface StoreService {
	/**
	 * 查找所有商铺
	 */
	List<Store> findAll();
	
	/**
	 * 通过查找所有商铺
	 */
	List<Store> findByState(String state);
}
