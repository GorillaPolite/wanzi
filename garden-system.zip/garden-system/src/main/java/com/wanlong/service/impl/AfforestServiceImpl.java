package com.wanlong.service.impl;

import java.text.SimpleDateFormat;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wanlong.dao.AfforestMapper;
import com.wanlong.pojos.Afforest;
import com.wanlong.service.AfforestService;

/**
 * 
 * @author mufeng
 * @category 绿化的业务实现
 */
@Service
public class AfforestServiceImpl implements AfforestService {

	@Autowired 
	AfforestMapper afforestMapper;
	@Override
	public List<Afforest> selectByExample() {
		return afforestMapper.selectByExample();
	}

	@Override
	public List<Afforest> findAfplushList(String afplush) {
		return afforestMapper.findAfplushList(afplush);
	}

	@Override
	public boolean deleteAll(int[] afids) {
		return afforestMapper.deleteAll(afids)>0?true:false;
	}

	@Override
	public boolean updatesave4(Afforest Afforest) {
		return afforestMapper.updatesave4(Afforest)>0?true:false;
	}

	@Override
	public boolean deleteByPrimaryKey(int afid) {
		return afforestMapper.deleteByPrimaryKey(afid)>0?true:false;
	}

	@Override
	public boolean insert(Afforest record) {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		java.util.Date date = new java.util.Date();
		String long1 = format.format(date);
	    record.setAftime(long1);
		return afforestMapper.insert(record)>0?true:false;
	}

	@Override
	public boolean updaaffomplish(Afforest afforest) {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		java.util.Date date = new java.util.Date();
		String long1 = format.format(date);
		afforest.setAfdate(long1);
		return afforestMapper.updaaffomplish(afforest)>0?true:false;
	}

	@Override
	public Afforest findAfforestById(int afid) {
		
		return afforestMapper.findAfforestById(afid);
	}

	@Override
	public List<Afforest> findAfforestBymdate(String aftime) {
		return afforestMapper.findAfforestBymdate(aftime);
	}

	@Override
	public List<Afforest> findAfforestBymfinishtime(String afdate) {
		return afforestMapper.findAfforestBymfinishtime(afdate);
	}

	@Override
	public List<Afforest> findMainAfforest(String mda) {
		return afforestMapper.findMainAfforest(mda);
	}

}
