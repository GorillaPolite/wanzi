package com.wanlong.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wanlong.dao.StoreDao;
import com.wanlong.pojos.Store;
import com.wanlong.service.StoreService;
@Service
public class StoreServiceImpl implements StoreService {
@Autowired
StoreDao storeDao;
	@Override
	public List<Store> findAll() {
		return storeDao.findAll();
	}

	@Override
	public List<Store> findByState(String state) {
		return storeDao.findByState(state);
	}

}
