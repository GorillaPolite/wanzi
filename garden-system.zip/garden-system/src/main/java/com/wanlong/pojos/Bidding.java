package com.wanlong.pojos;

import java.sql.Timestamp;

/**
 * @author Leett
 * @category 上架实体类
 */
public class Bidding {
	private int bid;
	private int sid;
	private double area;
	private double price;
	private Timestamp date;
	private String state;
	private int likeheart;
	private String remark;
	public int getBid() {
		return bid;
	}

	public void setBid(int bid) {
		this.bid = bid;
	}

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public double getArea() {
		return area;
	}

	public void setArea(double area) {
		this.area = area;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public Timestamp getDate() {
		return date;
	}

	public void setDate(Timestamp d) {
		this.date = d;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public int getLikeheart() {
		return likeheart;
	}

	public void setLikeheart(int likeheart) {
		this.likeheart = likeheart;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}
	
}
