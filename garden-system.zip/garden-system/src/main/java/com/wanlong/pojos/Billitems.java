package com.wanlong.pojos;

public class Billitems {
    private Integer billitemid;

    private String billitemname;

    private Double billitemmoney;

    private String billitemtype;

    private String billitemtime;

    public Integer getBillitemid() {
        return billitemid;
    }

    public void setBillitemid(Integer billitemid) {
        this.billitemid = billitemid;
    }

    public String getBillitemname() {
        return billitemname;
    }

    public void setBillitemname(String billitemname) {
        this.billitemname = billitemname == null ? null : billitemname.trim();
    }

    public Double getBillitemmoney() {
        return billitemmoney;
    }

    public void setBillitemmoney(Double billitemmoney) {
        this.billitemmoney = billitemmoney;
    }

    public String getBillitemtype() {
        return billitemtype;
    }

    public void setBillitemtype(String billitemtype) {
        this.billitemtype = billitemtype == null ? null : billitemtype.trim();
    }

    public String getBillitemtime() {
        return billitemtime;
    }

    public void setBillitemtime(String billitemtime) {
        this.billitemtime = billitemtime == null ? null : billitemtime.trim();
    }
}