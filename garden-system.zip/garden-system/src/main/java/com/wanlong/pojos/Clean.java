package com.wanlong.pojos;

public class Clean {
    private Integer clid;

    private Integer clerkid;

    private String clarea;

    private String clcontent;

    private String cltime;

    private String cldate;

    private String claccomplish;

    private String clmaterials;

    public Integer getClid() {
        return clid;
    }

    public void setClid(Integer clid) {
        this.clid = clid;
    }

    public Integer getClerkid() {
        return clerkid;
    }

    public void setClerkid(Integer clerkid) {
        this.clerkid = clerkid;
    }

    public String getClarea() {
        return clarea;
    }

    public void setClarea(String clarea) {
        this.clarea = clarea == null ? null : clarea.trim();
    }

    public String getClcontent() {
        return clcontent;
    }

    public void setClcontent(String clcontent) {
        this.clcontent = clcontent == null ? null : clcontent.trim();
    }

    public String getCltime() {
        return cltime;
    }

    public void setCltime(String cltime) {
        this.cltime = cltime == null ? null : cltime.trim();
    }

    public String getCldate() {
        return cldate;
    }

    public void setCldate(String cldate) {
        this.cldate = cldate == null ? null : cldate.trim();
    }

    public String getClaccomplish() {
        return claccomplish;
    }

    public void setClaccomplish(String claccomplish) {
        this.claccomplish = claccomplish == null ? null : claccomplish.trim();
    }

    public String getClmaterials() {
        return clmaterials;
    }

    public void setClmaterials(String clmaterials) {
        this.clmaterials = clmaterials == null ? null : clmaterials.trim();
    }
}