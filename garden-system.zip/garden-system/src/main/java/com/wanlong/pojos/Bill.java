package com.wanlong.pojos;

public class Bill {
	private Integer billid;

	private String billname;

	private String paystatus;

	private String billtime;

	private Integer uid;

	private Integer billitemid;

	private Billitems billitem;
	
	private String billNum;

	public String getBillNum() {
		return billNum;
	}

	public void setBillNum(String billNum) {
		this.billNum = billNum;
	}

	public void setBillitemid(Integer billitemid) {
		this.billitemid = billitemid;
	}

	public int getBillitemid() {
		return billitemid;
	}

	public void setBillitemid(int billitemid) {
		this.billitemid = billitemid;
	}

	public Billitems getBillitem() {
		return billitem;
	}

	public void setBillitem(Billitems billitem) {
		this.billitem = billitem;
	}

	public Integer getBillid() {
		return billid;
	}

	public void setBillid(Integer billid) {
		this.billid = billid;
	}

	public String getBillname() {
		return billname;
	}

	public void setBillname(String billname) {
		this.billname = billname == null ? null : billname.trim();
	}

	public String getPaystatus() {
		return paystatus;
	}

	public void setPaystatus(String paystatus) {
		this.paystatus = paystatus == null ? null : paystatus.trim();
	}

	public String getBilltime() {
		return billtime;
	}

	public void setBilltime(String billtime) {
		this.billtime = billtime == null ? null : billtime.trim();
	}

	public Integer getUid() {
		return uid;
	}

	public void setUid(Integer uid) {
		this.uid = uid;
	}
}