package com.wanlong.pojos;

/**
 * 
 * @author mufeng
 * @category 员工登录实体类
 */
public class StaffLogin {
	
	/**
	 * 员工编号
	 */
	private int clerkid;
	
	/**
	 * 员工登录密码
	 */
	private String clpass;
	
	/**
	 * 员工电话
	 */
	private String cltei;

	
	public StaffLogin() {
		super();
	}


	public StaffLogin(int clerkid, String clpass, String cltei) {
		super();
		this.clerkid = clerkid;
		this.clpass = clpass;
		this.cltei = cltei;
	}


	public int getClerkid() {
		return clerkid;
	}


	public void setClerkid(int clerkid) {
		this.clerkid = clerkid;
	}


	public String getClpass() {
		return clpass;
	}


	public void setClpass(String clpass) {
		this.clpass = clpass;
	}


	public String getCltei() {
		return cltei;
	}


	public void setCltei(String cltei) {
		this.cltei = cltei;
	}

	
	
}
