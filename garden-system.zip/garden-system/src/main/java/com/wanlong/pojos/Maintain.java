package com.wanlong.pojos;

public class Maintain {
    private Integer mid;

    private String mpart;

    private String mcontent;

    private String mbit;

    private Integer clerkid;

    private String mmaterials;

    private String mdate;

    private String mfinishtime;

    public Integer getMid() {
        return mid;
    }

    public void setMid(Integer mid) {
        this.mid = mid;
    }

    public String getMpart() {
        return mpart;
    }

    public void setMpart(String mpart) {
        this.mpart = mpart == null ? null : mpart.trim();
    }

    public String getMcontent() {
        return mcontent;
    }

    public void setMcontent(String mcontent) {
        this.mcontent = mcontent == null ? null : mcontent.trim();
    }

    public String getMbit() {
        return mbit;
    }

    public void setMbit(String mbit) {
        this.mbit = mbit == null ? null : mbit.trim();
    }

    public Integer getClerkid() {
        return clerkid;
    }

    public void setClerkid(Integer clerkid) {
        this.clerkid = clerkid;
    }

    public String getMmaterials() {
        return mmaterials;
    }

    public void setMmaterials(String mmaterials) {
        this.mmaterials = mmaterials == null ? null : mmaterials.trim();
    }

    public String getMdate() {
        return mdate;
    }

    public void setMdate(String mdate) {
        this.mdate = mdate == null ? null : mdate.trim();
    }

    public String getMfinishtime() {
        return mfinishtime;
    }

    public void setMfinishtime(String mfinishtime) {
        this.mfinishtime = mfinishtime == null ? null : mfinishtime.trim();
    }
}