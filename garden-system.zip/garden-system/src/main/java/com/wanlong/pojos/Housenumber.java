package com.wanlong.pojos;

public class Housenumber {
    private Integer homeid;

    private Integer hnumber;

    private String unitname;

    private Integer price;

    private String status;

    private String own;

    private String housename;

    private Integer saleprice;

    public Integer getHomeid() {
        return homeid;
    }

    public void setHomeid(Integer homeid) {
        this.homeid = homeid;
    }

    public Integer getHnumber() {
        return hnumber;
    }

    public void setHnumber(Integer hnumber) {
        this.hnumber = hnumber;
    }

    public String getUnitname() {
        return unitname;
    }

    public void setUnitname(String unitname) {
        this.unitname = unitname == null ? null : unitname.trim();
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status == null ? null : status.trim();
    }

    public String getOwn() {
        return own;
    }

    public void setOwn(String own) {
        this.own = own == null ? null : own.trim();
    }

    public String getHousename() {
        return housename;
    }

    public void setHousename(String housename) {
        this.housename = housename == null ? null : housename.trim();
    }

    public Integer getSaleprice() {
        return saleprice;
    }

    public void setSaleprice(Integer saleprice) {
        this.saleprice = saleprice;
    }
}