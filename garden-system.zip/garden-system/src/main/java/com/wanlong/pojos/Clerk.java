package com.wanlong.pojos;

/**
 * @author June
 * @category 职员表
 */
public class Clerk {
    /**
     * 职员id
     */
    private int clerkid;
    /**
     * 职员性名
     */
    private String clerkname;
    /**
     * 职员性别
     */
    private String clerksex;
    /**
     * 职员岗位
     */
    
    private String clerkpost;
    /**
     * 职员上班时间
     */
    private String clerkstarttime;
    /**
     * 职员下班时间
     */
    private String clerkendtime;
    /**
     * 职员工资
     */
    private Double clerksale;
    /**
     * 职员奖金
     */
    private Double clerkbonus;
    /**
     * 职员入职时间
     */
    private String hiredate;
    
    /**
     * 密码
     */
    private String clpass;
    
    private String cltel;
    
	public Clerk() {
		super();
	}

	public Clerk(int clerkid, String clerkname, String clerksex, String clerkpost, String clerkstarttime,
			String clerkendtime, Double clerksale, Double clerkbonus, String hiredate, String clpass, String cltel) {
		super();
		this.clerkid = clerkid;
		this.clerkname = clerkname;
		this.clerksex = clerksex;
		this.clerkpost = clerkpost;
		this.clerkstarttime = clerkstarttime;
		this.clerkendtime = clerkendtime;
		this.clerksale = clerksale;
		this.clerkbonus = clerkbonus;
		this.hiredate = hiredate;
		this.clpass = clpass;
		this.cltel = cltel;
	}

	public int getClerkid() {
		return clerkid;
	}
	public void setClerkid(int clerkid) {
		this.clerkid = clerkid;
	}
	public String getClerkname() {
		return clerkname;
	}
	public void setClerkname(String clerkname) {
		this.clerkname = clerkname;
	}
	public String getClerksex() {
		return clerksex;
	}
	public void setClerksex(String clerksex) {
		this.clerksex = clerksex;
	}
	public String getClerkpost() {
		return clerkpost;
	}
	public void setClerkpost(String clerkpost) {
		this.clerkpost = clerkpost;
	}
	public String getClerkstarttime() {
		return clerkstarttime;
	}
	public void setClerkstarttime(String clerkstarttime) {
		this.clerkstarttime = clerkstarttime;
	}
	public String getClerkendtime() {
		return clerkendtime;
	}
	public void setClerkendtime(String clerkendtime) {
		this.clerkendtime = clerkendtime;
	}
	public Double getClerksale() {
		return clerksale;
	}
	public void setClerksale(Double clerksale) {
		this.clerksale = clerksale;
	}
	public Double getClerkbonus() {
		return clerkbonus;
	}
	public void setClerkbonus(Double clerkbonus) {
		this.clerkbonus = clerkbonus;
	}
	public String getHiredate() {
		return hiredate;
	}
	public void setHiredate(String hiredate) {
		this.hiredate = hiredate;
	}

	public String getClpass() {
		return clpass;
	}

	public void setClpass(String clpass) {
		this.clpass = clpass;
	}

	public String getCltel() {
		return cltel;
	}

	public void setCltel(String cltel) {
		this.cltel = cltel;
	}  
	
}