package com.wanlong.pojos;

import java.util.ArrayList;
import java.util.List;

public class CleanExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public CleanExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andClidIsNull() {
            addCriterion("clid is null");
            return (Criteria) this;
        }

        public Criteria andClidIsNotNull() {
            addCriterion("clid is not null");
            return (Criteria) this;
        }

        public Criteria andClidEqualTo(Integer value) {
            addCriterion("clid =", value, "clid");
            return (Criteria) this;
        }

        public Criteria andClidNotEqualTo(Integer value) {
            addCriterion("clid <>", value, "clid");
            return (Criteria) this;
        }

        public Criteria andClidGreaterThan(Integer value) {
            addCriterion("clid >", value, "clid");
            return (Criteria) this;
        }

        public Criteria andClidGreaterThanOrEqualTo(Integer value) {
            addCriterion("clid >=", value, "clid");
            return (Criteria) this;
        }

        public Criteria andClidLessThan(Integer value) {
            addCriterion("clid <", value, "clid");
            return (Criteria) this;
        }

        public Criteria andClidLessThanOrEqualTo(Integer value) {
            addCriterion("clid <=", value, "clid");
            return (Criteria) this;
        }

        public Criteria andClidIn(List<Integer> values) {
            addCriterion("clid in", values, "clid");
            return (Criteria) this;
        }

        public Criteria andClidNotIn(List<Integer> values) {
            addCriterion("clid not in", values, "clid");
            return (Criteria) this;
        }

        public Criteria andClidBetween(Integer value1, Integer value2) {
            addCriterion("clid between", value1, value2, "clid");
            return (Criteria) this;
        }

        public Criteria andClidNotBetween(Integer value1, Integer value2) {
            addCriterion("clid not between", value1, value2, "clid");
            return (Criteria) this;
        }

        public Criteria andClerkidIsNull() {
            addCriterion("clerkid is null");
            return (Criteria) this;
        }

        public Criteria andClerkidIsNotNull() {
            addCriterion("clerkid is not null");
            return (Criteria) this;
        }

        public Criteria andClerkidEqualTo(Integer value) {
            addCriterion("clerkid =", value, "clerkid");
            return (Criteria) this;
        }

        public Criteria andClerkidNotEqualTo(Integer value) {
            addCriterion("clerkid <>", value, "clerkid");
            return (Criteria) this;
        }

        public Criteria andClerkidGreaterThan(Integer value) {
            addCriterion("clerkid >", value, "clerkid");
            return (Criteria) this;
        }

        public Criteria andClerkidGreaterThanOrEqualTo(Integer value) {
            addCriterion("clerkid >=", value, "clerkid");
            return (Criteria) this;
        }

        public Criteria andClerkidLessThan(Integer value) {
            addCriterion("clerkid <", value, "clerkid");
            return (Criteria) this;
        }

        public Criteria andClerkidLessThanOrEqualTo(Integer value) {
            addCriterion("clerkid <=", value, "clerkid");
            return (Criteria) this;
        }

        public Criteria andClerkidIn(List<Integer> values) {
            addCriterion("clerkid in", values, "clerkid");
            return (Criteria) this;
        }

        public Criteria andClerkidNotIn(List<Integer> values) {
            addCriterion("clerkid not in", values, "clerkid");
            return (Criteria) this;
        }

        public Criteria andClerkidBetween(Integer value1, Integer value2) {
            addCriterion("clerkid between", value1, value2, "clerkid");
            return (Criteria) this;
        }

        public Criteria andClerkidNotBetween(Integer value1, Integer value2) {
            addCriterion("clerkid not between", value1, value2, "clerkid");
            return (Criteria) this;
        }

        public Criteria andClareaIsNull() {
            addCriterion("clarea is null");
            return (Criteria) this;
        }

        public Criteria andClareaIsNotNull() {
            addCriterion("clarea is not null");
            return (Criteria) this;
        }

        public Criteria andClareaEqualTo(String value) {
            addCriterion("clarea =", value, "clarea");
            return (Criteria) this;
        }

        public Criteria andClareaNotEqualTo(String value) {
            addCriterion("clarea <>", value, "clarea");
            return (Criteria) this;
        }

        public Criteria andClareaGreaterThan(String value) {
            addCriterion("clarea >", value, "clarea");
            return (Criteria) this;
        }

        public Criteria andClareaGreaterThanOrEqualTo(String value) {
            addCriterion("clarea >=", value, "clarea");
            return (Criteria) this;
        }

        public Criteria andClareaLessThan(String value) {
            addCriterion("clarea <", value, "clarea");
            return (Criteria) this;
        }

        public Criteria andClareaLessThanOrEqualTo(String value) {
            addCriterion("clarea <=", value, "clarea");
            return (Criteria) this;
        }

        public Criteria andClareaLike(String value) {
            addCriterion("clarea like", value, "clarea");
            return (Criteria) this;
        }

        public Criteria andClareaNotLike(String value) {
            addCriterion("clarea not like", value, "clarea");
            return (Criteria) this;
        }

        public Criteria andClareaIn(List<String> values) {
            addCriterion("clarea in", values, "clarea");
            return (Criteria) this;
        }

        public Criteria andClareaNotIn(List<String> values) {
            addCriterion("clarea not in", values, "clarea");
            return (Criteria) this;
        }

        public Criteria andClareaBetween(String value1, String value2) {
            addCriterion("clarea between", value1, value2, "clarea");
            return (Criteria) this;
        }

        public Criteria andClareaNotBetween(String value1, String value2) {
            addCriterion("clarea not between", value1, value2, "clarea");
            return (Criteria) this;
        }

        public Criteria andClcontentIsNull() {
            addCriterion("clcontent is null");
            return (Criteria) this;
        }

        public Criteria andClcontentIsNotNull() {
            addCriterion("clcontent is not null");
            return (Criteria) this;
        }

        public Criteria andClcontentEqualTo(String value) {
            addCriterion("clcontent =", value, "clcontent");
            return (Criteria) this;
        }

        public Criteria andClcontentNotEqualTo(String value) {
            addCriterion("clcontent <>", value, "clcontent");
            return (Criteria) this;
        }

        public Criteria andClcontentGreaterThan(String value) {
            addCriterion("clcontent >", value, "clcontent");
            return (Criteria) this;
        }

        public Criteria andClcontentGreaterThanOrEqualTo(String value) {
            addCriterion("clcontent >=", value, "clcontent");
            return (Criteria) this;
        }

        public Criteria andClcontentLessThan(String value) {
            addCriterion("clcontent <", value, "clcontent");
            return (Criteria) this;
        }

        public Criteria andClcontentLessThanOrEqualTo(String value) {
            addCriterion("clcontent <=", value, "clcontent");
            return (Criteria) this;
        }

        public Criteria andClcontentLike(String value) {
            addCriterion("clcontent like", value, "clcontent");
            return (Criteria) this;
        }

        public Criteria andClcontentNotLike(String value) {
            addCriterion("clcontent not like", value, "clcontent");
            return (Criteria) this;
        }

        public Criteria andClcontentIn(List<String> values) {
            addCriterion("clcontent in", values, "clcontent");
            return (Criteria) this;
        }

        public Criteria andClcontentNotIn(List<String> values) {
            addCriterion("clcontent not in", values, "clcontent");
            return (Criteria) this;
        }

        public Criteria andClcontentBetween(String value1, String value2) {
            addCriterion("clcontent between", value1, value2, "clcontent");
            return (Criteria) this;
        }

        public Criteria andClcontentNotBetween(String value1, String value2) {
            addCriterion("clcontent not between", value1, value2, "clcontent");
            return (Criteria) this;
        }

        public Criteria andCltimeIsNull() {
            addCriterion("cltime is null");
            return (Criteria) this;
        }

        public Criteria andCltimeIsNotNull() {
            addCriterion("cltime is not null");
            return (Criteria) this;
        }

        public Criteria andCltimeEqualTo(String value) {
            addCriterion("cltime =", value, "cltime");
            return (Criteria) this;
        }

        public Criteria andCltimeNotEqualTo(String value) {
            addCriterion("cltime <>", value, "cltime");
            return (Criteria) this;
        }

        public Criteria andCltimeGreaterThan(String value) {
            addCriterion("cltime >", value, "cltime");
            return (Criteria) this;
        }

        public Criteria andCltimeGreaterThanOrEqualTo(String value) {
            addCriterion("cltime >=", value, "cltime");
            return (Criteria) this;
        }

        public Criteria andCltimeLessThan(String value) {
            addCriterion("cltime <", value, "cltime");
            return (Criteria) this;
        }

        public Criteria andCltimeLessThanOrEqualTo(String value) {
            addCriterion("cltime <=", value, "cltime");
            return (Criteria) this;
        }

        public Criteria andCltimeLike(String value) {
            addCriterion("cltime like", value, "cltime");
            return (Criteria) this;
        }

        public Criteria andCltimeNotLike(String value) {
            addCriterion("cltime not like", value, "cltime");
            return (Criteria) this;
        }

        public Criteria andCltimeIn(List<String> values) {
            addCriterion("cltime in", values, "cltime");
            return (Criteria) this;
        }

        public Criteria andCltimeNotIn(List<String> values) {
            addCriterion("cltime not in", values, "cltime");
            return (Criteria) this;
        }

        public Criteria andCltimeBetween(String value1, String value2) {
            addCriterion("cltime between", value1, value2, "cltime");
            return (Criteria) this;
        }

        public Criteria andCltimeNotBetween(String value1, String value2) {
            addCriterion("cltime not between", value1, value2, "cltime");
            return (Criteria) this;
        }

        public Criteria andCldateIsNull() {
            addCriterion("cldate is null");
            return (Criteria) this;
        }

        public Criteria andCldateIsNotNull() {
            addCriterion("cldate is not null");
            return (Criteria) this;
        }

        public Criteria andCldateEqualTo(String value) {
            addCriterion("cldate =", value, "cldate");
            return (Criteria) this;
        }

        public Criteria andCldateNotEqualTo(String value) {
            addCriterion("cldate <>", value, "cldate");
            return (Criteria) this;
        }

        public Criteria andCldateGreaterThan(String value) {
            addCriterion("cldate >", value, "cldate");
            return (Criteria) this;
        }

        public Criteria andCldateGreaterThanOrEqualTo(String value) {
            addCriterion("cldate >=", value, "cldate");
            return (Criteria) this;
        }

        public Criteria andCldateLessThan(String value) {
            addCriterion("cldate <", value, "cldate");
            return (Criteria) this;
        }

        public Criteria andCldateLessThanOrEqualTo(String value) {
            addCriterion("cldate <=", value, "cldate");
            return (Criteria) this;
        }

        public Criteria andCldateLike(String value) {
            addCriterion("cldate like", value, "cldate");
            return (Criteria) this;
        }

        public Criteria andCldateNotLike(String value) {
            addCriterion("cldate not like", value, "cldate");
            return (Criteria) this;
        }

        public Criteria andCldateIn(List<String> values) {
            addCriterion("cldate in", values, "cldate");
            return (Criteria) this;
        }

        public Criteria andCldateNotIn(List<String> values) {
            addCriterion("cldate not in", values, "cldate");
            return (Criteria) this;
        }

        public Criteria andCldateBetween(String value1, String value2) {
            addCriterion("cldate between", value1, value2, "cldate");
            return (Criteria) this;
        }

        public Criteria andCldateNotBetween(String value1, String value2) {
            addCriterion("cldate not between", value1, value2, "cldate");
            return (Criteria) this;
        }

        public Criteria andClaccomplishIsNull() {
            addCriterion("claccomplish is null");
            return (Criteria) this;
        }

        public Criteria andClaccomplishIsNotNull() {
            addCriterion("claccomplish is not null");
            return (Criteria) this;
        }

        public Criteria andClaccomplishEqualTo(String value) {
            addCriterion("claccomplish =", value, "claccomplish");
            return (Criteria) this;
        }

        public Criteria andClaccomplishNotEqualTo(String value) {
            addCriterion("claccomplish <>", value, "claccomplish");
            return (Criteria) this;
        }

        public Criteria andClaccomplishGreaterThan(String value) {
            addCriterion("claccomplish >", value, "claccomplish");
            return (Criteria) this;
        }

        public Criteria andClaccomplishGreaterThanOrEqualTo(String value) {
            addCriterion("claccomplish >=", value, "claccomplish");
            return (Criteria) this;
        }

        public Criteria andClaccomplishLessThan(String value) {
            addCriterion("claccomplish <", value, "claccomplish");
            return (Criteria) this;
        }

        public Criteria andClaccomplishLessThanOrEqualTo(String value) {
            addCriterion("claccomplish <=", value, "claccomplish");
            return (Criteria) this;
        }

        public Criteria andClaccomplishLike(String value) {
            addCriterion("claccomplish like", value, "claccomplish");
            return (Criteria) this;
        }

        public Criteria andClaccomplishNotLike(String value) {
            addCriterion("claccomplish not like", value, "claccomplish");
            return (Criteria) this;
        }

        public Criteria andClaccomplishIn(List<String> values) {
            addCriterion("claccomplish in", values, "claccomplish");
            return (Criteria) this;
        }

        public Criteria andClaccomplishNotIn(List<String> values) {
            addCriterion("claccomplish not in", values, "claccomplish");
            return (Criteria) this;
        }

        public Criteria andClaccomplishBetween(String value1, String value2) {
            addCriterion("claccomplish between", value1, value2, "claccomplish");
            return (Criteria) this;
        }

        public Criteria andClaccomplishNotBetween(String value1, String value2) {
            addCriterion("claccomplish not between", value1, value2, "claccomplish");
            return (Criteria) this;
        }

        public Criteria andClmaterialsIsNull() {
            addCriterion("clmaterials is null");
            return (Criteria) this;
        }

        public Criteria andClmaterialsIsNotNull() {
            addCriterion("clmaterials is not null");
            return (Criteria) this;
        }

        public Criteria andClmaterialsEqualTo(String value) {
            addCriterion("clmaterials =", value, "clmaterials");
            return (Criteria) this;
        }

        public Criteria andClmaterialsNotEqualTo(String value) {
            addCriterion("clmaterials <>", value, "clmaterials");
            return (Criteria) this;
        }

        public Criteria andClmaterialsGreaterThan(String value) {
            addCriterion("clmaterials >", value, "clmaterials");
            return (Criteria) this;
        }

        public Criteria andClmaterialsGreaterThanOrEqualTo(String value) {
            addCriterion("clmaterials >=", value, "clmaterials");
            return (Criteria) this;
        }

        public Criteria andClmaterialsLessThan(String value) {
            addCriterion("clmaterials <", value, "clmaterials");
            return (Criteria) this;
        }

        public Criteria andClmaterialsLessThanOrEqualTo(String value) {
            addCriterion("clmaterials <=", value, "clmaterials");
            return (Criteria) this;
        }

        public Criteria andClmaterialsLike(String value) {
            addCriterion("clmaterials like", value, "clmaterials");
            return (Criteria) this;
        }

        public Criteria andClmaterialsNotLike(String value) {
            addCriterion("clmaterials not like", value, "clmaterials");
            return (Criteria) this;
        }

        public Criteria andClmaterialsIn(List<String> values) {
            addCriterion("clmaterials in", values, "clmaterials");
            return (Criteria) this;
        }

        public Criteria andClmaterialsNotIn(List<String> values) {
            addCriterion("clmaterials not in", values, "clmaterials");
            return (Criteria) this;
        }

        public Criteria andClmaterialsBetween(String value1, String value2) {
            addCriterion("clmaterials between", value1, value2, "clmaterials");
            return (Criteria) this;
        }

        public Criteria andClmaterialsNotBetween(String value1, String value2) {
            addCriterion("clmaterials not between", value1, value2, "clmaterials");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}