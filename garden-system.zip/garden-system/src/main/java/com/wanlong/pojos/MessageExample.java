package com.wanlong.pojos;

import java.util.ArrayList;
import java.util.List;

public class MessageExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public MessageExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andMessidIsNull() {
            addCriterion("messid is null");
            return (Criteria) this;
        }

        public Criteria andMessidIsNotNull() {
            addCriterion("messid is not null");
            return (Criteria) this;
        }

        public Criteria andMessidEqualTo(Integer value) {
            addCriterion("messid =", value, "messid");
            return (Criteria) this;
        }

        public Criteria andMessidNotEqualTo(Integer value) {
            addCriterion("messid <>", value, "messid");
            return (Criteria) this;
        }

        public Criteria andMessidGreaterThan(Integer value) {
            addCriterion("messid >", value, "messid");
            return (Criteria) this;
        }

        public Criteria andMessidGreaterThanOrEqualTo(Integer value) {
            addCriterion("messid >=", value, "messid");
            return (Criteria) this;
        }

        public Criteria andMessidLessThan(Integer value) {
            addCriterion("messid <", value, "messid");
            return (Criteria) this;
        }

        public Criteria andMessidLessThanOrEqualTo(Integer value) {
            addCriterion("messid <=", value, "messid");
            return (Criteria) this;
        }

        public Criteria andMessidIn(List<Integer> values) {
            addCriterion("messid in", values, "messid");
            return (Criteria) this;
        }

        public Criteria andMessidNotIn(List<Integer> values) {
            addCriterion("messid not in", values, "messid");
            return (Criteria) this;
        }

        public Criteria andMessidBetween(Integer value1, Integer value2) {
            addCriterion("messid between", value1, value2, "messid");
            return (Criteria) this;
        }

        public Criteria andMessidNotBetween(Integer value1, Integer value2) {
            addCriterion("messid not between", value1, value2, "messid");
            return (Criteria) this;
        }

        public Criteria andOidIsNull() {
            addCriterion("oid is null");
            return (Criteria) this;
        }

        public Criteria andOidIsNotNull() {
            addCriterion("oid is not null");
            return (Criteria) this;
        }

        public Criteria andOidEqualTo(Integer value) {
            addCriterion("oid =", value, "oid");
            return (Criteria) this;
        }

        public Criteria andOidNotEqualTo(Integer value) {
            addCriterion("oid <>", value, "oid");
            return (Criteria) this;
        }

        public Criteria andOidGreaterThan(Integer value) {
            addCriterion("oid >", value, "oid");
            return (Criteria) this;
        }

        public Criteria andOidGreaterThanOrEqualTo(Integer value) {
            addCriterion("oid >=", value, "oid");
            return (Criteria) this;
        }

        public Criteria andOidLessThan(Integer value) {
            addCriterion("oid <", value, "oid");
            return (Criteria) this;
        }

        public Criteria andOidLessThanOrEqualTo(Integer value) {
            addCriterion("oid <=", value, "oid");
            return (Criteria) this;
        }

        public Criteria andOidIn(List<Integer> values) {
            addCriterion("oid in", values, "oid");
            return (Criteria) this;
        }

        public Criteria andOidNotIn(List<Integer> values) {
            addCriterion("oid not in", values, "oid");
            return (Criteria) this;
        }

        public Criteria andOidBetween(Integer value1, Integer value2) {
            addCriterion("oid between", value1, value2, "oid");
            return (Criteria) this;
        }

        public Criteria andOidNotBetween(Integer value1, Integer value2) {
            addCriterion("oid not between", value1, value2, "oid");
            return (Criteria) this;
        }

        public Criteria andMessinfoIsNull() {
            addCriterion("messinfo is null");
            return (Criteria) this;
        }

        public Criteria andMessinfoIsNotNull() {
            addCriterion("messinfo is not null");
            return (Criteria) this;
        }

        public Criteria andMessinfoEqualTo(String value) {
            addCriterion("messinfo =", value, "messinfo");
            return (Criteria) this;
        }

        public Criteria andMessinfoNotEqualTo(String value) {
            addCriterion("messinfo <>", value, "messinfo");
            return (Criteria) this;
        }

        public Criteria andMessinfoGreaterThan(String value) {
            addCriterion("messinfo >", value, "messinfo");
            return (Criteria) this;
        }

        public Criteria andMessinfoGreaterThanOrEqualTo(String value) {
            addCriterion("messinfo >=", value, "messinfo");
            return (Criteria) this;
        }

        public Criteria andMessinfoLessThan(String value) {
            addCriterion("messinfo <", value, "messinfo");
            return (Criteria) this;
        }

        public Criteria andMessinfoLessThanOrEqualTo(String value) {
            addCriterion("messinfo <=", value, "messinfo");
            return (Criteria) this;
        }

        public Criteria andMessinfoLike(String value) {
            addCriterion("messinfo like", value, "messinfo");
            return (Criteria) this;
        }

        public Criteria andMessinfoNotLike(String value) {
            addCriterion("messinfo not like", value, "messinfo");
            return (Criteria) this;
        }

        public Criteria andMessinfoIn(List<String> values) {
            addCriterion("messinfo in", values, "messinfo");
            return (Criteria) this;
        }

        public Criteria andMessinfoNotIn(List<String> values) {
            addCriterion("messinfo not in", values, "messinfo");
            return (Criteria) this;
        }

        public Criteria andMessinfoBetween(String value1, String value2) {
            addCriterion("messinfo between", value1, value2, "messinfo");
            return (Criteria) this;
        }

        public Criteria andMessinfoNotBetween(String value1, String value2) {
            addCriterion("messinfo not between", value1, value2, "messinfo");
            return (Criteria) this;
        }

        public Criteria andStatusIsNull() {
            addCriterion("status is null");
            return (Criteria) this;
        }

        public Criteria andStatusIsNotNull() {
            addCriterion("status is not null");
            return (Criteria) this;
        }

        public Criteria andStatusEqualTo(String value) {
            addCriterion("status =", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotEqualTo(String value) {
            addCriterion("status <>", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThan(String value) {
            addCriterion("status >", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThanOrEqualTo(String value) {
            addCriterion("status >=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThan(String value) {
            addCriterion("status <", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThanOrEqualTo(String value) {
            addCriterion("status <=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLike(String value) {
            addCriterion("status like", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotLike(String value) {
            addCriterion("status not like", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusIn(List<String> values) {
            addCriterion("status in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotIn(List<String> values) {
            addCriterion("status not in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusBetween(String value1, String value2) {
            addCriterion("status between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotBetween(String value1, String value2) {
            addCriterion("status not between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andMesstimeIsNull() {
            addCriterion("messtime is null");
            return (Criteria) this;
        }

        public Criteria andMesstimeIsNotNull() {
            addCriterion("messtime is not null");
            return (Criteria) this;
        }

        public Criteria andMesstimeEqualTo(String value) {
            addCriterion("messtime =", value, "messtime");
            return (Criteria) this;
        }

        public Criteria andMesstimeNotEqualTo(String value) {
            addCriterion("messtime <>", value, "messtime");
            return (Criteria) this;
        }

        public Criteria andMesstimeGreaterThan(String value) {
            addCriterion("messtime >", value, "messtime");
            return (Criteria) this;
        }

        public Criteria andMesstimeGreaterThanOrEqualTo(String value) {
            addCriterion("messtime >=", value, "messtime");
            return (Criteria) this;
        }

        public Criteria andMesstimeLessThan(String value) {
            addCriterion("messtime <", value, "messtime");
            return (Criteria) this;
        }

        public Criteria andMesstimeLessThanOrEqualTo(String value) {
            addCriterion("messtime <=", value, "messtime");
            return (Criteria) this;
        }

        public Criteria andMesstimeLike(String value) {
            addCriterion("messtime like", value, "messtime");
            return (Criteria) this;
        }

        public Criteria andMesstimeNotLike(String value) {
            addCriterion("messtime not like", value, "messtime");
            return (Criteria) this;
        }

        public Criteria andMesstimeIn(List<String> values) {
            addCriterion("messtime in", values, "messtime");
            return (Criteria) this;
        }

        public Criteria andMesstimeNotIn(List<String> values) {
            addCriterion("messtime not in", values, "messtime");
            return (Criteria) this;
        }

        public Criteria andMesstimeBetween(String value1, String value2) {
            addCriterion("messtime between", value1, value2, "messtime");
            return (Criteria) this;
        }

        public Criteria andMesstimeNotBetween(String value1, String value2) {
            addCriterion("messtime not between", value1, value2, "messtime");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}