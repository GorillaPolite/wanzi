package com.wanlong.pojos;

/**
 * @author June
 * @category 物料表
 */
public class Supplies {
    /**
     * 物料id
     */
    private int suppliesid;
    /**
     * 物料名称
     */
    private String suppliesname;
    /**
     * 物料图片
     */
    private String suppliespic;
    /**
     * 物料功能
     */
    private String suppliesfun;
    /**
     * 物料数量
     */
    private String suppliesnum;
    /**
     * 物料供应商
     */
    private String suppliesprovider;
	public Supplies() {
		super();
	}
	public Supplies(int suppliesid, String suppliesname, String suppliespic, String suppliesfun, String suppliesnum,
			String suppliesprovider) {
		super();
		this.suppliesid = suppliesid;
		this.suppliesname = suppliesname;
		this.suppliespic = suppliespic;
		this.suppliesfun = suppliesfun;
		this.suppliesnum = suppliesnum;
		this.suppliesprovider = suppliesprovider;
	}
	public int getSuppliesid() {
		return suppliesid;
	}
	public void setSuppliesid(int suppliesid) {
		this.suppliesid = suppliesid;
	}
	public String getSuppliesname() {
		return suppliesname;
	}
	public void setSuppliesname(String suppliesname) {
		this.suppliesname = suppliesname;
	}
	public String getSuppliespic() {
		return suppliespic;
	}
	public void setSuppliespic(String suppliespic) {
		this.suppliespic = suppliespic;
	}
	public String getSuppliesfun() {
		return suppliesfun;
	}
	public void setSuppliesfun(String suppliesfun) {
		this.suppliesfun = suppliesfun;
	}
	public String getSuppliesnum() {
		return suppliesnum;
	}
	public void setSuppliesnum(String suppliesnum) {
		this.suppliesnum = suppliesnum;
	}
	public String getSuppliesprovider() {
		return suppliesprovider;
	}
	public void setSuppliesprovider(String suppliesprovider) {
		this.suppliesprovider = suppliesprovider;
	}

    
}