package com.wanlong.pojos;

import java.util.ArrayList;
import java.util.List;

public class OwnerExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public OwnerExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andOidIsNull() {
            addCriterion("oid is null");
            return (Criteria) this;
        }

        public Criteria andOidIsNotNull() {
            addCriterion("oid is not null");
            return (Criteria) this;
        }

        public Criteria andOidEqualTo(Integer value) {
            addCriterion("oid =", value, "oid");
            return (Criteria) this;
        }

        public Criteria andOidNotEqualTo(Integer value) {
            addCriterion("oid <>", value, "oid");
            return (Criteria) this;
        }

        public Criteria andOidGreaterThan(Integer value) {
            addCriterion("oid >", value, "oid");
            return (Criteria) this;
        }

        public Criteria andOidGreaterThanOrEqualTo(Integer value) {
            addCriterion("oid >=", value, "oid");
            return (Criteria) this;
        }

        public Criteria andOidLessThan(Integer value) {
            addCriterion("oid <", value, "oid");
            return (Criteria) this;
        }

        public Criteria andOidLessThanOrEqualTo(Integer value) {
            addCriterion("oid <=", value, "oid");
            return (Criteria) this;
        }

        public Criteria andOidIn(List<Integer> values) {
            addCriterion("oid in", values, "oid");
            return (Criteria) this;
        }

        public Criteria andOidNotIn(List<Integer> values) {
            addCriterion("oid not in", values, "oid");
            return (Criteria) this;
        }

        public Criteria andOidBetween(Integer value1, Integer value2) {
            addCriterion("oid between", value1, value2, "oid");
            return (Criteria) this;
        }

        public Criteria andOidNotBetween(Integer value1, Integer value2) {
            addCriterion("oid not between", value1, value2, "oid");
            return (Criteria) this;
        }

        public Criteria andRidIsNull() {
            addCriterion("rid is null");
            return (Criteria) this;
        }

        public Criteria andRidIsNotNull() {
            addCriterion("rid is not null");
            return (Criteria) this;
        }

        public Criteria andRidEqualTo(Integer value) {
            addCriterion("rid =", value, "rid");
            return (Criteria) this;
        }

        public Criteria andRidNotEqualTo(Integer value) {
            addCriterion("rid <>", value, "rid");
            return (Criteria) this;
        }

        public Criteria andRidGreaterThan(Integer value) {
            addCriterion("rid >", value, "rid");
            return (Criteria) this;
        }

        public Criteria andRidGreaterThanOrEqualTo(Integer value) {
            addCriterion("rid >=", value, "rid");
            return (Criteria) this;
        }

        public Criteria andRidLessThan(Integer value) {
            addCriterion("rid <", value, "rid");
            return (Criteria) this;
        }

        public Criteria andRidLessThanOrEqualTo(Integer value) {
            addCriterion("rid <=", value, "rid");
            return (Criteria) this;
        }

        public Criteria andRidIn(List<Integer> values) {
            addCriterion("rid in", values, "rid");
            return (Criteria) this;
        }

        public Criteria andRidNotIn(List<Integer> values) {
            addCriterion("rid not in", values, "rid");
            return (Criteria) this;
        }

        public Criteria andRidBetween(Integer value1, Integer value2) {
            addCriterion("rid between", value1, value2, "rid");
            return (Criteria) this;
        }

        public Criteria andRidNotBetween(Integer value1, Integer value2) {
            addCriterion("rid not between", value1, value2, "rid");
            return (Criteria) this;
        }

        public Criteria andTowernumIsNull() {
            addCriterion("towernum is null");
            return (Criteria) this;
        }

        public Criteria andTowernumIsNotNull() {
            addCriterion("towernum is not null");
            return (Criteria) this;
        }

        public Criteria andTowernumEqualTo(Integer value) {
            addCriterion("towernum =", value, "towernum");
            return (Criteria) this;
        }

        public Criteria andTowernumNotEqualTo(Integer value) {
            addCriterion("towernum <>", value, "towernum");
            return (Criteria) this;
        }

        public Criteria andTowernumGreaterThan(Integer value) {
            addCriterion("towernum >", value, "towernum");
            return (Criteria) this;
        }

        public Criteria andTowernumGreaterThanOrEqualTo(Integer value) {
            addCriterion("towernum >=", value, "towernum");
            return (Criteria) this;
        }

        public Criteria andTowernumLessThan(Integer value) {
            addCriterion("towernum <", value, "towernum");
            return (Criteria) this;
        }

        public Criteria andTowernumLessThanOrEqualTo(Integer value) {
            addCriterion("towernum <=", value, "towernum");
            return (Criteria) this;
        }

        public Criteria andTowernumIn(List<Integer> values) {
            addCriterion("towernum in", values, "towernum");
            return (Criteria) this;
        }

        public Criteria andTowernumNotIn(List<Integer> values) {
            addCriterion("towernum not in", values, "towernum");
            return (Criteria) this;
        }

        public Criteria andTowernumBetween(Integer value1, Integer value2) {
            addCriterion("towernum between", value1, value2, "towernum");
            return (Criteria) this;
        }

        public Criteria andTowernumNotBetween(Integer value1, Integer value2) {
            addCriterion("towernum not between", value1, value2, "towernum");
            return (Criteria) this;
        }

        public Criteria andOdoorplateIsNull() {
            addCriterion("odoorplate is null");
            return (Criteria) this;
        }

        public Criteria andOdoorplateIsNotNull() {
            addCriterion("odoorplate is not null");
            return (Criteria) this;
        }

        public Criteria andOdoorplateEqualTo(String value) {
            addCriterion("odoorplate =", value, "odoorplate");
            return (Criteria) this;
        }

        public Criteria andOdoorplateNotEqualTo(String value) {
            addCriterion("odoorplate <>", value, "odoorplate");
            return (Criteria) this;
        }

        public Criteria andOdoorplateGreaterThan(String value) {
            addCriterion("odoorplate >", value, "odoorplate");
            return (Criteria) this;
        }

        public Criteria andOdoorplateGreaterThanOrEqualTo(String value) {
            addCriterion("odoorplate >=", value, "odoorplate");
            return (Criteria) this;
        }

        public Criteria andOdoorplateLessThan(String value) {
            addCriterion("odoorplate <", value, "odoorplate");
            return (Criteria) this;
        }

        public Criteria andOdoorplateLessThanOrEqualTo(String value) {
            addCriterion("odoorplate <=", value, "odoorplate");
            return (Criteria) this;
        }

        public Criteria andOdoorplateLike(String value) {
            addCriterion("odoorplate like", value, "odoorplate");
            return (Criteria) this;
        }

        public Criteria andOdoorplateNotLike(String value) {
            addCriterion("odoorplate not like", value, "odoorplate");
            return (Criteria) this;
        }

        public Criteria andOdoorplateIn(List<String> values) {
            addCriterion("odoorplate in", values, "odoorplate");
            return (Criteria) this;
        }

        public Criteria andOdoorplateNotIn(List<String> values) {
            addCriterion("odoorplate not in", values, "odoorplate");
            return (Criteria) this;
        }

        public Criteria andOdoorplateBetween(String value1, String value2) {
            addCriterion("odoorplate between", value1, value2, "odoorplate");
            return (Criteria) this;
        }

        public Criteria andOdoorplateNotBetween(String value1, String value2) {
            addCriterion("odoorplate not between", value1, value2, "odoorplate");
            return (Criteria) this;
        }

        public Criteria andOnameIsNull() {
            addCriterion("oname is null");
            return (Criteria) this;
        }

        public Criteria andOnameIsNotNull() {
            addCriterion("oname is not null");
            return (Criteria) this;
        }

        public Criteria andOnameEqualTo(String value) {
            addCriterion("oname =", value, "oname");
            return (Criteria) this;
        }

        public Criteria andOnameNotEqualTo(String value) {
            addCriterion("oname <>", value, "oname");
            return (Criteria) this;
        }

        public Criteria andOnameGreaterThan(String value) {
            addCriterion("oname >", value, "oname");
            return (Criteria) this;
        }

        public Criteria andOnameGreaterThanOrEqualTo(String value) {
            addCriterion("oname >=", value, "oname");
            return (Criteria) this;
        }

        public Criteria andOnameLessThan(String value) {
            addCriterion("oname <", value, "oname");
            return (Criteria) this;
        }

        public Criteria andOnameLessThanOrEqualTo(String value) {
            addCriterion("oname <=", value, "oname");
            return (Criteria) this;
        }

        public Criteria andOnameLike(String value) {
            addCriterion("oname like", value, "oname");
            return (Criteria) this;
        }

        public Criteria andOnameNotLike(String value) {
            addCriterion("oname not like", value, "oname");
            return (Criteria) this;
        }

        public Criteria andOnameIn(List<String> values) {
            addCriterion("oname in", values, "oname");
            return (Criteria) this;
        }

        public Criteria andOnameNotIn(List<String> values) {
            addCriterion("oname not in", values, "oname");
            return (Criteria) this;
        }

        public Criteria andOnameBetween(String value1, String value2) {
            addCriterion("oname between", value1, value2, "oname");
            return (Criteria) this;
        }

        public Criteria andOnameNotBetween(String value1, String value2) {
            addCriterion("oname not between", value1, value2, "oname");
            return (Criteria) this;
        }

        public Criteria andOpassIsNull() {
            addCriterion("opass is null");
            return (Criteria) this;
        }

        public Criteria andOpassIsNotNull() {
            addCriterion("opass is not null");
            return (Criteria) this;
        }

        public Criteria andOpassEqualTo(String value) {
            addCriterion("opass =", value, "opass");
            return (Criteria) this;
        }

        public Criteria andOpassNotEqualTo(String value) {
            addCriterion("opass <>", value, "opass");
            return (Criteria) this;
        }

        public Criteria andOpassGreaterThan(String value) {
            addCriterion("opass >", value, "opass");
            return (Criteria) this;
        }

        public Criteria andOpassGreaterThanOrEqualTo(String value) {
            addCriterion("opass >=", value, "opass");
            return (Criteria) this;
        }

        public Criteria andOpassLessThan(String value) {
            addCriterion("opass <", value, "opass");
            return (Criteria) this;
        }

        public Criteria andOpassLessThanOrEqualTo(String value) {
            addCriterion("opass <=", value, "opass");
            return (Criteria) this;
        }

        public Criteria andOpassLike(String value) {
            addCriterion("opass like", value, "opass");
            return (Criteria) this;
        }

        public Criteria andOpassNotLike(String value) {
            addCriterion("opass not like", value, "opass");
            return (Criteria) this;
        }

        public Criteria andOpassIn(List<String> values) {
            addCriterion("opass in", values, "opass");
            return (Criteria) this;
        }

        public Criteria andOpassNotIn(List<String> values) {
            addCriterion("opass not in", values, "opass");
            return (Criteria) this;
        }

        public Criteria andOpassBetween(String value1, String value2) {
            addCriterion("opass between", value1, value2, "opass");
            return (Criteria) this;
        }

        public Criteria andOpassNotBetween(String value1, String value2) {
            addCriterion("opass not between", value1, value2, "opass");
            return (Criteria) this;
        }

        public Criteria andOtelIsNull() {
            addCriterion("otel is null");
            return (Criteria) this;
        }

        public Criteria andOtelIsNotNull() {
            addCriterion("otel is not null");
            return (Criteria) this;
        }

        public Criteria andOtelEqualTo(String value) {
            addCriterion("otel =", value, "otel");
            return (Criteria) this;
        }

        public Criteria andOtelNotEqualTo(String value) {
            addCriterion("otel <>", value, "otel");
            return (Criteria) this;
        }

        public Criteria andOtelGreaterThan(String value) {
            addCriterion("otel >", value, "otel");
            return (Criteria) this;
        }

        public Criteria andOtelGreaterThanOrEqualTo(String value) {
            addCriterion("otel >=", value, "otel");
            return (Criteria) this;
        }

        public Criteria andOtelLessThan(String value) {
            addCriterion("otel <", value, "otel");
            return (Criteria) this;
        }

        public Criteria andOtelLessThanOrEqualTo(String value) {
            addCriterion("otel <=", value, "otel");
            return (Criteria) this;
        }

        public Criteria andOtelLike(String value) {
            addCriterion("otel like", value, "otel");
            return (Criteria) this;
        }

        public Criteria andOtelNotLike(String value) {
            addCriterion("otel not like", value, "otel");
            return (Criteria) this;
        }

        public Criteria andOtelIn(List<String> values) {
            addCriterion("otel in", values, "otel");
            return (Criteria) this;
        }

        public Criteria andOtelNotIn(List<String> values) {
            addCriterion("otel not in", values, "otel");
            return (Criteria) this;
        }

        public Criteria andOtelBetween(String value1, String value2) {
            addCriterion("otel between", value1, value2, "otel");
            return (Criteria) this;
        }

        public Criteria andOtelNotBetween(String value1, String value2) {
            addCriterion("otel not between", value1, value2, "otel");
            return (Criteria) this;
        }

        public Criteria andOidentityIsNull() {
            addCriterion("oidentity is null");
            return (Criteria) this;
        }

        public Criteria andOidentityIsNotNull() {
            addCriterion("oidentity is not null");
            return (Criteria) this;
        }

        public Criteria andOidentityEqualTo(String value) {
            addCriterion("oidentity =", value, "oidentity");
            return (Criteria) this;
        }

        public Criteria andOidentityNotEqualTo(String value) {
            addCriterion("oidentity <>", value, "oidentity");
            return (Criteria) this;
        }

        public Criteria andOidentityGreaterThan(String value) {
            addCriterion("oidentity >", value, "oidentity");
            return (Criteria) this;
        }

        public Criteria andOidentityGreaterThanOrEqualTo(String value) {
            addCriterion("oidentity >=", value, "oidentity");
            return (Criteria) this;
        }

        public Criteria andOidentityLessThan(String value) {
            addCriterion("oidentity <", value, "oidentity");
            return (Criteria) this;
        }

        public Criteria andOidentityLessThanOrEqualTo(String value) {
            addCriterion("oidentity <=", value, "oidentity");
            return (Criteria) this;
        }

        public Criteria andOidentityLike(String value) {
            addCriterion("oidentity like", value, "oidentity");
            return (Criteria) this;
        }

        public Criteria andOidentityNotLike(String value) {
            addCriterion("oidentity not like", value, "oidentity");
            return (Criteria) this;
        }

        public Criteria andOidentityIn(List<String> values) {
            addCriterion("oidentity in", values, "oidentity");
            return (Criteria) this;
        }

        public Criteria andOidentityNotIn(List<String> values) {
            addCriterion("oidentity not in", values, "oidentity");
            return (Criteria) this;
        }

        public Criteria andOidentityBetween(String value1, String value2) {
            addCriterion("oidentity between", value1, value2, "oidentity");
            return (Criteria) this;
        }

        public Criteria andOidentityNotBetween(String value1, String value2) {
            addCriterion("oidentity not between", value1, value2, "oidentity");
            return (Criteria) this;
        }

        public Criteria andOiputdateIsNull() {
            addCriterion("oiputdate is null");
            return (Criteria) this;
        }

        public Criteria andOiputdateIsNotNull() {
            addCriterion("oiputdate is not null");
            return (Criteria) this;
        }

        public Criteria andOiputdateEqualTo(String value) {
            addCriterion("oiputdate =", value, "oiputdate");
            return (Criteria) this;
        }

        public Criteria andOiputdateNotEqualTo(String value) {
            addCriterion("oiputdate <>", value, "oiputdate");
            return (Criteria) this;
        }

        public Criteria andOiputdateGreaterThan(String value) {
            addCriterion("oiputdate >", value, "oiputdate");
            return (Criteria) this;
        }

        public Criteria andOiputdateGreaterThanOrEqualTo(String value) {
            addCriterion("oiputdate >=", value, "oiputdate");
            return (Criteria) this;
        }

        public Criteria andOiputdateLessThan(String value) {
            addCriterion("oiputdate <", value, "oiputdate");
            return (Criteria) this;
        }

        public Criteria andOiputdateLessThanOrEqualTo(String value) {
            addCriterion("oiputdate <=", value, "oiputdate");
            return (Criteria) this;
        }

        public Criteria andOiputdateLike(String value) {
            addCriterion("oiputdate like", value, "oiputdate");
            return (Criteria) this;
        }

        public Criteria andOiputdateNotLike(String value) {
            addCriterion("oiputdate not like", value, "oiputdate");
            return (Criteria) this;
        }

        public Criteria andOiputdateIn(List<String> values) {
            addCriterion("oiputdate in", values, "oiputdate");
            return (Criteria) this;
        }

        public Criteria andOiputdateNotIn(List<String> values) {
            addCriterion("oiputdate not in", values, "oiputdate");
            return (Criteria) this;
        }

        public Criteria andOiputdateBetween(String value1, String value2) {
            addCriterion("oiputdate between", value1, value2, "oiputdate");
            return (Criteria) this;
        }

        public Criteria andOiputdateNotBetween(String value1, String value2) {
            addCriterion("oiputdate not between", value1, value2, "oiputdate");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}