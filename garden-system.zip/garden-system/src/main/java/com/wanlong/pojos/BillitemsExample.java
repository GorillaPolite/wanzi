package com.wanlong.pojos;

import java.util.ArrayList;
import java.util.List;

public class BillitemsExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public BillitemsExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andBillitemidIsNull() {
            addCriterion("billitemid is null");
            return (Criteria) this;
        }

        public Criteria andBillitemidIsNotNull() {
            addCriterion("billitemid is not null");
            return (Criteria) this;
        }

        public Criteria andBillitemidEqualTo(Integer value) {
            addCriterion("billitemid =", value, "billitemid");
            return (Criteria) this;
        }

        public Criteria andBillitemidNotEqualTo(Integer value) {
            addCriterion("billitemid <>", value, "billitemid");
            return (Criteria) this;
        }

        public Criteria andBillitemidGreaterThan(Integer value) {
            addCriterion("billitemid >", value, "billitemid");
            return (Criteria) this;
        }

        public Criteria andBillitemidGreaterThanOrEqualTo(Integer value) {
            addCriterion("billitemid >=", value, "billitemid");
            return (Criteria) this;
        }

        public Criteria andBillitemidLessThan(Integer value) {
            addCriterion("billitemid <", value, "billitemid");
            return (Criteria) this;
        }

        public Criteria andBillitemidLessThanOrEqualTo(Integer value) {
            addCriterion("billitemid <=", value, "billitemid");
            return (Criteria) this;
        }

        public Criteria andBillitemidIn(List<Integer> values) {
            addCriterion("billitemid in", values, "billitemid");
            return (Criteria) this;
        }

        public Criteria andBillitemidNotIn(List<Integer> values) {
            addCriterion("billitemid not in", values, "billitemid");
            return (Criteria) this;
        }

        public Criteria andBillitemidBetween(Integer value1, Integer value2) {
            addCriterion("billitemid between", value1, value2, "billitemid");
            return (Criteria) this;
        }

        public Criteria andBillitemidNotBetween(Integer value1, Integer value2) {
            addCriterion("billitemid not between", value1, value2, "billitemid");
            return (Criteria) this;
        }

        public Criteria andBillitemnameIsNull() {
            addCriterion("billitemname is null");
            return (Criteria) this;
        }

        public Criteria andBillitemnameIsNotNull() {
            addCriterion("billitemname is not null");
            return (Criteria) this;
        }

        public Criteria andBillitemnameEqualTo(String value) {
            addCriterion("billitemname =", value, "billitemname");
            return (Criteria) this;
        }

        public Criteria andBillitemnameNotEqualTo(String value) {
            addCriterion("billitemname <>", value, "billitemname");
            return (Criteria) this;
        }

        public Criteria andBillitemnameGreaterThan(String value) {
            addCriterion("billitemname >", value, "billitemname");
            return (Criteria) this;
        }

        public Criteria andBillitemnameGreaterThanOrEqualTo(String value) {
            addCriterion("billitemname >=", value, "billitemname");
            return (Criteria) this;
        }

        public Criteria andBillitemnameLessThan(String value) {
            addCriterion("billitemname <", value, "billitemname");
            return (Criteria) this;
        }

        public Criteria andBillitemnameLessThanOrEqualTo(String value) {
            addCriterion("billitemname <=", value, "billitemname");
            return (Criteria) this;
        }

        public Criteria andBillitemnameLike(String value) {
            addCriterion("billitemname like", value, "billitemname");
            return (Criteria) this;
        }

        public Criteria andBillitemnameNotLike(String value) {
            addCriterion("billitemname not like", value, "billitemname");
            return (Criteria) this;
        }

        public Criteria andBillitemnameIn(List<String> values) {
            addCriterion("billitemname in", values, "billitemname");
            return (Criteria) this;
        }

        public Criteria andBillitemnameNotIn(List<String> values) {
            addCriterion("billitemname not in", values, "billitemname");
            return (Criteria) this;
        }

        public Criteria andBillitemnameBetween(String value1, String value2) {
            addCriterion("billitemname between", value1, value2, "billitemname");
            return (Criteria) this;
        }

        public Criteria andBillitemnameNotBetween(String value1, String value2) {
            addCriterion("billitemname not between", value1, value2, "billitemname");
            return (Criteria) this;
        }

        public Criteria andBillitemmoneyIsNull() {
            addCriterion("billitemmoney is null");
            return (Criteria) this;
        }

        public Criteria andBillitemmoneyIsNotNull() {
            addCriterion("billitemmoney is not null");
            return (Criteria) this;
        }

        public Criteria andBillitemmoneyEqualTo(Double value) {
            addCriterion("billitemmoney =", value, "billitemmoney");
            return (Criteria) this;
        }

        public Criteria andBillitemmoneyNotEqualTo(Double value) {
            addCriterion("billitemmoney <>", value, "billitemmoney");
            return (Criteria) this;
        }

        public Criteria andBillitemmoneyGreaterThan(Double value) {
            addCriterion("billitemmoney >", value, "billitemmoney");
            return (Criteria) this;
        }

        public Criteria andBillitemmoneyGreaterThanOrEqualTo(Double value) {
            addCriterion("billitemmoney >=", value, "billitemmoney");
            return (Criteria) this;
        }

        public Criteria andBillitemmoneyLessThan(Double value) {
            addCriterion("billitemmoney <", value, "billitemmoney");
            return (Criteria) this;
        }

        public Criteria andBillitemmoneyLessThanOrEqualTo(Double value) {
            addCriterion("billitemmoney <=", value, "billitemmoney");
            return (Criteria) this;
        }

        public Criteria andBillitemmoneyIn(List<Double> values) {
            addCriterion("billitemmoney in", values, "billitemmoney");
            return (Criteria) this;
        }

        public Criteria andBillitemmoneyNotIn(List<Double> values) {
            addCriterion("billitemmoney not in", values, "billitemmoney");
            return (Criteria) this;
        }

        public Criteria andBillitemmoneyBetween(Double value1, Double value2) {
            addCriterion("billitemmoney between", value1, value2, "billitemmoney");
            return (Criteria) this;
        }

        public Criteria andBillitemmoneyNotBetween(Double value1, Double value2) {
            addCriterion("billitemmoney not between", value1, value2, "billitemmoney");
            return (Criteria) this;
        }

        public Criteria andBillitemtypeIsNull() {
            addCriterion("billitemtype is null");
            return (Criteria) this;
        }

        public Criteria andBillitemtypeIsNotNull() {
            addCriterion("billitemtype is not null");
            return (Criteria) this;
        }

        public Criteria andBillitemtypeEqualTo(String value) {
            addCriterion("billitemtype =", value, "billitemtype");
            return (Criteria) this;
        }

        public Criteria andBillitemtypeNotEqualTo(String value) {
            addCriterion("billitemtype <>", value, "billitemtype");
            return (Criteria) this;
        }

        public Criteria andBillitemtypeGreaterThan(String value) {
            addCriterion("billitemtype >", value, "billitemtype");
            return (Criteria) this;
        }

        public Criteria andBillitemtypeGreaterThanOrEqualTo(String value) {
            addCriterion("billitemtype >=", value, "billitemtype");
            return (Criteria) this;
        }

        public Criteria andBillitemtypeLessThan(String value) {
            addCriterion("billitemtype <", value, "billitemtype");
            return (Criteria) this;
        }

        public Criteria andBillitemtypeLessThanOrEqualTo(String value) {
            addCriterion("billitemtype <=", value, "billitemtype");
            return (Criteria) this;
        }

        public Criteria andBillitemtypeLike(String value) {
            addCriterion("billitemtype like", value, "billitemtype");
            return (Criteria) this;
        }

        public Criteria andBillitemtypeNotLike(String value) {
            addCriterion("billitemtype not like", value, "billitemtype");
            return (Criteria) this;
        }

        public Criteria andBillitemtypeIn(List<String> values) {
            addCriterion("billitemtype in", values, "billitemtype");
            return (Criteria) this;
        }

        public Criteria andBillitemtypeNotIn(List<String> values) {
            addCriterion("billitemtype not in", values, "billitemtype");
            return (Criteria) this;
        }

        public Criteria andBillitemtypeBetween(String value1, String value2) {
            addCriterion("billitemtype between", value1, value2, "billitemtype");
            return (Criteria) this;
        }

        public Criteria andBillitemtypeNotBetween(String value1, String value2) {
            addCriterion("billitemtype not between", value1, value2, "billitemtype");
            return (Criteria) this;
        }

        public Criteria andBillitemtimeIsNull() {
            addCriterion("billitemtime is null");
            return (Criteria) this;
        }

        public Criteria andBillitemtimeIsNotNull() {
            addCriterion("billitemtime is not null");
            return (Criteria) this;
        }

        public Criteria andBillitemtimeEqualTo(String value) {
            addCriterion("billitemtime =", value, "billitemtime");
            return (Criteria) this;
        }

        public Criteria andBillitemtimeNotEqualTo(String value) {
            addCriterion("billitemtime <>", value, "billitemtime");
            return (Criteria) this;
        }

        public Criteria andBillitemtimeGreaterThan(String value) {
            addCriterion("billitemtime >", value, "billitemtime");
            return (Criteria) this;
        }

        public Criteria andBillitemtimeGreaterThanOrEqualTo(String value) {
            addCriterion("billitemtime >=", value, "billitemtime");
            return (Criteria) this;
        }

        public Criteria andBillitemtimeLessThan(String value) {
            addCriterion("billitemtime <", value, "billitemtime");
            return (Criteria) this;
        }

        public Criteria andBillitemtimeLessThanOrEqualTo(String value) {
            addCriterion("billitemtime <=", value, "billitemtime");
            return (Criteria) this;
        }

        public Criteria andBillitemtimeLike(String value) {
            addCriterion("billitemtime like", value, "billitemtime");
            return (Criteria) this;
        }

        public Criteria andBillitemtimeNotLike(String value) {
            addCriterion("billitemtime not like", value, "billitemtime");
            return (Criteria) this;
        }

        public Criteria andBillitemtimeIn(List<String> values) {
            addCriterion("billitemtime in", values, "billitemtime");
            return (Criteria) this;
        }

        public Criteria andBillitemtimeNotIn(List<String> values) {
            addCriterion("billitemtime not in", values, "billitemtime");
            return (Criteria) this;
        }

        public Criteria andBillitemtimeBetween(String value1, String value2) {
            addCriterion("billitemtime between", value1, value2, "billitemtime");
            return (Criteria) this;
        }

        public Criteria andBillitemtimeNotBetween(String value1, String value2) {
            addCriterion("billitemtime not between", value1, value2, "billitemtime");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}