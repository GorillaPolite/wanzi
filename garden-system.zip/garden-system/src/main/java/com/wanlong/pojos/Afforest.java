package com.wanlong.pojos;

public class Afforest {
    private Integer afid;

    private Integer clerkid;

    private String afarea;

    private String afcontent;

    private String aftime;

    private String afdate;

    private String afplush;

    private String afmaterials;

    public Integer getAfid() {
        return afid;
    }

    public void setAfid(Integer afid) {
        this.afid = afid;
    }

    public Integer getClerkid() {
        return clerkid;
    }

    public void setClerkid(Integer clerkid) {
        this.clerkid = clerkid;
    }

    public String getAfarea() {
        return afarea;
    }

    public void setAfarea(String afarea) {
        this.afarea = afarea == null ? null : afarea.trim();
    }

    public String getAfcontent() {
        return afcontent;
    }

    public void setAfcontent(String afcontent) {
        this.afcontent = afcontent == null ? null : afcontent.trim();
    }

    public String getAftime() {
        return aftime;
    }

    public void setAftime(String aftime) {
        this.aftime = aftime == null ? null : aftime.trim();
    }

    public String getAfdate() {
        return afdate;
    }

    public void setAfdate(String afdate) {
        this.afdate = afdate == null ? null : afdate.trim();
    }

    public String getAfplush() {
        return afplush;
    }

    public void setAfplush(String afplush) {
        this.afplush = afplush == null ? null : afplush.trim();
    }

    public String getAfmaterials() {
        return afmaterials;
    }

    public void setAfmaterials(String afmaterials) {
        this.afmaterials = afmaterials == null ? null : afmaterials.trim();
    }
}