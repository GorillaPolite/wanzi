package com.wanlong.pojos;

public class Message {
    private Integer messid;

    private Integer oid;

    private String messinfo;

    private String status;

    private String messtime;

    public Integer getMessid() {
        return messid;
    }

    public void setMessid(Integer messid) {
        this.messid = messid;
    }

    public Integer getOid() {
        return oid;
    }

    public void setOid(Integer oid) {
        this.oid = oid;
    }

    public String getMessinfo() {
        return messinfo;
    }

    public void setMessinfo(String messinfo) {
        this.messinfo = messinfo == null ? null : messinfo.trim();
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status == null ? null : status.trim();
    }

    public String getMesstime() {
        return messtime;
    }

    public void setMesstime(String messtime) {
        this.messtime = messtime == null ? null : messtime.trim();
    }
}