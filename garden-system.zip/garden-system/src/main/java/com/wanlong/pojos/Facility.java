package com.wanlong.pojos;

/**
 * @author June
 * @category 设备表
 */
public class Facility {
    /**
     * 设备id
     */
    private int facilityid;
    /**
     * 设备名称
     */
    private String facilityname;

    /**
     * 设备图片
     */
    private String facilitypic;
    /**
     * 设备所在区域
     */
    private String facilityfun;
    /**
     * 设备使用时间段
     */
    private String facilityarea;
    /**
     * 设备起始年限
     */
    private String facilitystrattime;
    /**
     * 设备到期年限
     */
    private String facilityendtime;
    
    
	public Facility() {
		super();
	}
	
	public Facility(int facilityid, String facilityname, String facilitypic, String facilityfun, String facilityarea,
			String facilitystrattime, String facilityendtime) {
		super();
		this.facilityid = facilityid;
		this.facilityname = facilityname;
		this.facilitypic = facilitypic;
		this.facilityfun = facilityfun;
		this.facilityarea = facilityarea;
		this.facilitystrattime = facilitystrattime;
		this.facilityendtime = facilityendtime;
	}

	public int getFacilityid() {
		return facilityid;
	}
	public void setFacilityid(int facilityid) {
		this.facilityid = facilityid;
	}
	public String getFacilityname() {
		return facilityname;
	}
	public void setFacilityname(String facilityname) {
		this.facilityname = facilityname;
	}
	public String getFacilitypic() {
		return facilitypic;
	}
	public void setFacilitypic(String facilitypic) {
		this.facilitypic = facilitypic;
	}
	public String getFacilityfun() {
		return facilityfun;
	}
	public void setFacilityfun(String facilityfun) {
		this.facilityfun = facilityfun;
	}
	public String getFacilityarea() {
		return facilityarea;
	}
	public void setFacilityarea(String facilityarea) {
		this.facilityarea = facilityarea;
	}
	public String getFacilitystrattime() {
		return facilitystrattime;
	}
	public void setFacilitystrattime(String facilitystrattime) {
		this.facilitystrattime = facilitystrattime;
	}
	public String getFacilityendtime() {
		return facilityendtime;
	}
	public void setFacilityendtime(String facilityendtime) {
		this.facilityendtime = facilityendtime;
	}
    
 
}