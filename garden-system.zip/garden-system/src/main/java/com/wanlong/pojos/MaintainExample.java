package com.wanlong.pojos;

import java.util.ArrayList;
import java.util.List;

public class MaintainExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public MaintainExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andMidIsNull() {
            addCriterion("mid is null");
            return (Criteria) this;
        }

        public Criteria andMidIsNotNull() {
            addCriterion("mid is not null");
            return (Criteria) this;
        }

        public Criteria andMidEqualTo(Integer value) {
            addCriterion("mid =", value, "mid");
            return (Criteria) this;
        }

        public Criteria andMidNotEqualTo(Integer value) {
            addCriterion("mid <>", value, "mid");
            return (Criteria) this;
        }

        public Criteria andMidGreaterThan(Integer value) {
            addCriterion("mid >", value, "mid");
            return (Criteria) this;
        }

        public Criteria andMidGreaterThanOrEqualTo(Integer value) {
            addCriterion("mid >=", value, "mid");
            return (Criteria) this;
        }

        public Criteria andMidLessThan(Integer value) {
            addCriterion("mid <", value, "mid");
            return (Criteria) this;
        }

        public Criteria andMidLessThanOrEqualTo(Integer value) {
            addCriterion("mid <=", value, "mid");
            return (Criteria) this;
        }

        public Criteria andMidIn(List<Integer> values) {
            addCriterion("mid in", values, "mid");
            return (Criteria) this;
        }

        public Criteria andMidNotIn(List<Integer> values) {
            addCriterion("mid not in", values, "mid");
            return (Criteria) this;
        }

        public Criteria andMidBetween(Integer value1, Integer value2) {
            addCriterion("mid between", value1, value2, "mid");
            return (Criteria) this;
        }

        public Criteria andMidNotBetween(Integer value1, Integer value2) {
            addCriterion("mid not between", value1, value2, "mid");
            return (Criteria) this;
        }

        public Criteria andMpartIsNull() {
            addCriterion("mpart is null");
            return (Criteria) this;
        }

        public Criteria andMpartIsNotNull() {
            addCriterion("mpart is not null");
            return (Criteria) this;
        }

        public Criteria andMpartEqualTo(String value) {
            addCriterion("mpart =", value, "mpart");
            return (Criteria) this;
        }

        public Criteria andMpartNotEqualTo(String value) {
            addCriterion("mpart <>", value, "mpart");
            return (Criteria) this;
        }

        public Criteria andMpartGreaterThan(String value) {
            addCriterion("mpart >", value, "mpart");
            return (Criteria) this;
        }

        public Criteria andMpartGreaterThanOrEqualTo(String value) {
            addCriterion("mpart >=", value, "mpart");
            return (Criteria) this;
        }

        public Criteria andMpartLessThan(String value) {
            addCriterion("mpart <", value, "mpart");
            return (Criteria) this;
        }

        public Criteria andMpartLessThanOrEqualTo(String value) {
            addCriterion("mpart <=", value, "mpart");
            return (Criteria) this;
        }

        public Criteria andMpartLike(String value) {
            addCriterion("mpart like", value, "mpart");
            return (Criteria) this;
        }

        public Criteria andMpartNotLike(String value) {
            addCriterion("mpart not like", value, "mpart");
            return (Criteria) this;
        }

        public Criteria andMpartIn(List<String> values) {
            addCriterion("mpart in", values, "mpart");
            return (Criteria) this;
        }

        public Criteria andMpartNotIn(List<String> values) {
            addCriterion("mpart not in", values, "mpart");
            return (Criteria) this;
        }

        public Criteria andMpartBetween(String value1, String value2) {
            addCriterion("mpart between", value1, value2, "mpart");
            return (Criteria) this;
        }

        public Criteria andMpartNotBetween(String value1, String value2) {
            addCriterion("mpart not between", value1, value2, "mpart");
            return (Criteria) this;
        }

        public Criteria andMcontentIsNull() {
            addCriterion("mcontent is null");
            return (Criteria) this;
        }

        public Criteria andMcontentIsNotNull() {
            addCriterion("mcontent is not null");
            return (Criteria) this;
        }

        public Criteria andMcontentEqualTo(String value) {
            addCriterion("mcontent =", value, "mcontent");
            return (Criteria) this;
        }

        public Criteria andMcontentNotEqualTo(String value) {
            addCriterion("mcontent <>", value, "mcontent");
            return (Criteria) this;
        }

        public Criteria andMcontentGreaterThan(String value) {
            addCriterion("mcontent >", value, "mcontent");
            return (Criteria) this;
        }

        public Criteria andMcontentGreaterThanOrEqualTo(String value) {
            addCriterion("mcontent >=", value, "mcontent");
            return (Criteria) this;
        }

        public Criteria andMcontentLessThan(String value) {
            addCriterion("mcontent <", value, "mcontent");
            return (Criteria) this;
        }

        public Criteria andMcontentLessThanOrEqualTo(String value) {
            addCriterion("mcontent <=", value, "mcontent");
            return (Criteria) this;
        }

        public Criteria andMcontentLike(String value) {
            addCriterion("mcontent like", value, "mcontent");
            return (Criteria) this;
        }

        public Criteria andMcontentNotLike(String value) {
            addCriterion("mcontent not like", value, "mcontent");
            return (Criteria) this;
        }

        public Criteria andMcontentIn(List<String> values) {
            addCriterion("mcontent in", values, "mcontent");
            return (Criteria) this;
        }

        public Criteria andMcontentNotIn(List<String> values) {
            addCriterion("mcontent not in", values, "mcontent");
            return (Criteria) this;
        }

        public Criteria andMcontentBetween(String value1, String value2) {
            addCriterion("mcontent between", value1, value2, "mcontent");
            return (Criteria) this;
        }

        public Criteria andMcontentNotBetween(String value1, String value2) {
            addCriterion("mcontent not between", value1, value2, "mcontent");
            return (Criteria) this;
        }

        public Criteria andMbitIsNull() {
            addCriterion("mbit is null");
            return (Criteria) this;
        }

        public Criteria andMbitIsNotNull() {
            addCriterion("mbit is not null");
            return (Criteria) this;
        }

        public Criteria andMbitEqualTo(String value) {
            addCriterion("mbit =", value, "mbit");
            return (Criteria) this;
        }

        public Criteria andMbitNotEqualTo(String value) {
            addCriterion("mbit <>", value, "mbit");
            return (Criteria) this;
        }

        public Criteria andMbitGreaterThan(String value) {
            addCriterion("mbit >", value, "mbit");
            return (Criteria) this;
        }

        public Criteria andMbitGreaterThanOrEqualTo(String value) {
            addCriterion("mbit >=", value, "mbit");
            return (Criteria) this;
        }

        public Criteria andMbitLessThan(String value) {
            addCriterion("mbit <", value, "mbit");
            return (Criteria) this;
        }

        public Criteria andMbitLessThanOrEqualTo(String value) {
            addCriterion("mbit <=", value, "mbit");
            return (Criteria) this;
        }

        public Criteria andMbitLike(String value) {
            addCriterion("mbit like", value, "mbit");
            return (Criteria) this;
        }

        public Criteria andMbitNotLike(String value) {
            addCriterion("mbit not like", value, "mbit");
            return (Criteria) this;
        }

        public Criteria andMbitIn(List<String> values) {
            addCriterion("mbit in", values, "mbit");
            return (Criteria) this;
        }

        public Criteria andMbitNotIn(List<String> values) {
            addCriterion("mbit not in", values, "mbit");
            return (Criteria) this;
        }

        public Criteria andMbitBetween(String value1, String value2) {
            addCriterion("mbit between", value1, value2, "mbit");
            return (Criteria) this;
        }

        public Criteria andMbitNotBetween(String value1, String value2) {
            addCriterion("mbit not between", value1, value2, "mbit");
            return (Criteria) this;
        }

        public Criteria andClerkidIsNull() {
            addCriterion("clerkid is null");
            return (Criteria) this;
        }

        public Criteria andClerkidIsNotNull() {
            addCriterion("clerkid is not null");
            return (Criteria) this;
        }

        public Criteria andClerkidEqualTo(Integer value) {
            addCriterion("clerkid =", value, "clerkid");
            return (Criteria) this;
        }

        public Criteria andClerkidNotEqualTo(Integer value) {
            addCriterion("clerkid <>", value, "clerkid");
            return (Criteria) this;
        }

        public Criteria andClerkidGreaterThan(Integer value) {
            addCriterion("clerkid >", value, "clerkid");
            return (Criteria) this;
        }

        public Criteria andClerkidGreaterThanOrEqualTo(Integer value) {
            addCriterion("clerkid >=", value, "clerkid");
            return (Criteria) this;
        }

        public Criteria andClerkidLessThan(Integer value) {
            addCriterion("clerkid <", value, "clerkid");
            return (Criteria) this;
        }

        public Criteria andClerkidLessThanOrEqualTo(Integer value) {
            addCriterion("clerkid <=", value, "clerkid");
            return (Criteria) this;
        }

        public Criteria andClerkidIn(List<Integer> values) {
            addCriterion("clerkid in", values, "clerkid");
            return (Criteria) this;
        }

        public Criteria andClerkidNotIn(List<Integer> values) {
            addCriterion("clerkid not in", values, "clerkid");
            return (Criteria) this;
        }

        public Criteria andClerkidBetween(Integer value1, Integer value2) {
            addCriterion("clerkid between", value1, value2, "clerkid");
            return (Criteria) this;
        }

        public Criteria andClerkidNotBetween(Integer value1, Integer value2) {
            addCriterion("clerkid not between", value1, value2, "clerkid");
            return (Criteria) this;
        }

        public Criteria andMmaterialsIsNull() {
            addCriterion("mmaterials is null");
            return (Criteria) this;
        }

        public Criteria andMmaterialsIsNotNull() {
            addCriterion("mmaterials is not null");
            return (Criteria) this;
        }

        public Criteria andMmaterialsEqualTo(String value) {
            addCriterion("mmaterials =", value, "mmaterials");
            return (Criteria) this;
        }

        public Criteria andMmaterialsNotEqualTo(String value) {
            addCriterion("mmaterials <>", value, "mmaterials");
            return (Criteria) this;
        }

        public Criteria andMmaterialsGreaterThan(String value) {
            addCriterion("mmaterials >", value, "mmaterials");
            return (Criteria) this;
        }

        public Criteria andMmaterialsGreaterThanOrEqualTo(String value) {
            addCriterion("mmaterials >=", value, "mmaterials");
            return (Criteria) this;
        }

        public Criteria andMmaterialsLessThan(String value) {
            addCriterion("mmaterials <", value, "mmaterials");
            return (Criteria) this;
        }

        public Criteria andMmaterialsLessThanOrEqualTo(String value) {
            addCriterion("mmaterials <=", value, "mmaterials");
            return (Criteria) this;
        }

        public Criteria andMmaterialsLike(String value) {
            addCriterion("mmaterials like", value, "mmaterials");
            return (Criteria) this;
        }

        public Criteria andMmaterialsNotLike(String value) {
            addCriterion("mmaterials not like", value, "mmaterials");
            return (Criteria) this;
        }

        public Criteria andMmaterialsIn(List<String> values) {
            addCriterion("mmaterials in", values, "mmaterials");
            return (Criteria) this;
        }

        public Criteria andMmaterialsNotIn(List<String> values) {
            addCriterion("mmaterials not in", values, "mmaterials");
            return (Criteria) this;
        }

        public Criteria andMmaterialsBetween(String value1, String value2) {
            addCriterion("mmaterials between", value1, value2, "mmaterials");
            return (Criteria) this;
        }

        public Criteria andMmaterialsNotBetween(String value1, String value2) {
            addCriterion("mmaterials not between", value1, value2, "mmaterials");
            return (Criteria) this;
        }

        public Criteria andMdateIsNull() {
            addCriterion("mdate is null");
            return (Criteria) this;
        }

        public Criteria andMdateIsNotNull() {
            addCriterion("mdate is not null");
            return (Criteria) this;
        }

        public Criteria andMdateEqualTo(String value) {
            addCriterion("mdate =", value, "mdate");
            return (Criteria) this;
        }

        public Criteria andMdateNotEqualTo(String value) {
            addCriterion("mdate <>", value, "mdate");
            return (Criteria) this;
        }

        public Criteria andMdateGreaterThan(String value) {
            addCriterion("mdate >", value, "mdate");
            return (Criteria) this;
        }

        public Criteria andMdateGreaterThanOrEqualTo(String value) {
            addCriterion("mdate >=", value, "mdate");
            return (Criteria) this;
        }

        public Criteria andMdateLessThan(String value) {
            addCriterion("mdate <", value, "mdate");
            return (Criteria) this;
        }

        public Criteria andMdateLessThanOrEqualTo(String value) {
            addCriterion("mdate <=", value, "mdate");
            return (Criteria) this;
        }

        public Criteria andMdateLike(String value) {
            addCriterion("mdate like", value, "mdate");
            return (Criteria) this;
        }

        public Criteria andMdateNotLike(String value) {
            addCriterion("mdate not like", value, "mdate");
            return (Criteria) this;
        }

        public Criteria andMdateIn(List<String> values) {
            addCriterion("mdate in", values, "mdate");
            return (Criteria) this;
        }

        public Criteria andMdateNotIn(List<String> values) {
            addCriterion("mdate not in", values, "mdate");
            return (Criteria) this;
        }

        public Criteria andMdateBetween(String value1, String value2) {
            addCriterion("mdate between", value1, value2, "mdate");
            return (Criteria) this;
        }

        public Criteria andMdateNotBetween(String value1, String value2) {
            addCriterion("mdate not between", value1, value2, "mdate");
            return (Criteria) this;
        }

        public Criteria andMfinishtimeIsNull() {
            addCriterion("mfinishtime is null");
            return (Criteria) this;
        }

        public Criteria andMfinishtimeIsNotNull() {
            addCriterion("mfinishtime is not null");
            return (Criteria) this;
        }

        public Criteria andMfinishtimeEqualTo(String value) {
            addCriterion("mfinishtime =", value, "mfinishtime");
            return (Criteria) this;
        }

        public Criteria andMfinishtimeNotEqualTo(String value) {
            addCriterion("mfinishtime <>", value, "mfinishtime");
            return (Criteria) this;
        }

        public Criteria andMfinishtimeGreaterThan(String value) {
            addCriterion("mfinishtime >", value, "mfinishtime");
            return (Criteria) this;
        }

        public Criteria andMfinishtimeGreaterThanOrEqualTo(String value) {
            addCriterion("mfinishtime >=", value, "mfinishtime");
            return (Criteria) this;
        }

        public Criteria andMfinishtimeLessThan(String value) {
            addCriterion("mfinishtime <", value, "mfinishtime");
            return (Criteria) this;
        }

        public Criteria andMfinishtimeLessThanOrEqualTo(String value) {
            addCriterion("mfinishtime <=", value, "mfinishtime");
            return (Criteria) this;
        }

        public Criteria andMfinishtimeLike(String value) {
            addCriterion("mfinishtime like", value, "mfinishtime");
            return (Criteria) this;
        }

        public Criteria andMfinishtimeNotLike(String value) {
            addCriterion("mfinishtime not like", value, "mfinishtime");
            return (Criteria) this;
        }

        public Criteria andMfinishtimeIn(List<String> values) {
            addCriterion("mfinishtime in", values, "mfinishtime");
            return (Criteria) this;
        }

        public Criteria andMfinishtimeNotIn(List<String> values) {
            addCriterion("mfinishtime not in", values, "mfinishtime");
            return (Criteria) this;
        }

        public Criteria andMfinishtimeBetween(String value1, String value2) {
            addCriterion("mfinishtime between", value1, value2, "mfinishtime");
            return (Criteria) this;
        }

        public Criteria andMfinishtimeNotBetween(String value1, String value2) {
            addCriterion("mfinishtime not between", value1, value2, "mfinishtime");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}