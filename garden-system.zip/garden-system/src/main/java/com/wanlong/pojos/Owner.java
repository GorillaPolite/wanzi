package com.wanlong.pojos;

import java.util.List;

/**
 * 
 * @author mufeng
 * @category 住户实体类
 */
public class Owner {
	
    private Integer oid;

    private Integer rid;

    private String odoorplate;

    private String oname;

    private String opass;

    private String otel;

    private String oidentity;

	private String oiputdate;
    
    private List<Bill>  bill;
    
    private double total;
    /**
     * 楼号
     */
    private int towernum;
    
    public List<Bill> getBill() {
		return bill;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	public void setBill(List<Bill> bill) {
		this.bill = bill;
	}

	public Integer getOid() {
        return oid;
    }

    public void setOid(Integer oid) {
        this.oid = oid;
    }

    public Integer getRid() {
        return rid;
    }

    public void setRid(Integer rid) {
        this.rid = rid;
    }

    public String getOdoorplate() {
        return odoorplate;
    }

    public void setOdoorplate(String odoorplate) {
        this.odoorplate = odoorplate == null ? null : odoorplate.trim();
    }

    public String getOname() {
        return oname;
    }

    public void setOname(String oname) {
        this.oname = oname == null ? null : oname.trim();
    }

    public String getOpass() {
        return opass;
    }

    public void setOpass(String opass) {
        this.opass = opass == null ? null : opass.trim();
    }

    public String getOtel() {
        return otel;
    }

    public void setOtel(String otel) {
        this.otel = otel == null ? null : otel.trim();
    }

    public String getOidentity() {
        return oidentity;
    }

    public void setOidentity(String oidentity) {
        this.oidentity = oidentity == null ? null : oidentity.trim();
    }

    public String getOiputdate() {
        return oiputdate;
    }

    public void setOiputdate(String oiputdate) {
        this.oiputdate = oiputdate == null ? null : oiputdate.trim();
    }

	public int getTowernum() {
		return towernum;
	}

	public void setTowernum(int towernum) {
		this.towernum = towernum;
	}
    
}