package com.wanlong.pojos;

import java.util.ArrayList;
import java.util.List;

public class AfforestExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public AfforestExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andAfidIsNull() {
            addCriterion("afid is null");
            return (Criteria) this;
        }

        public Criteria andAfidIsNotNull() {
            addCriterion("afid is not null");
            return (Criteria) this;
        }

        public Criteria andAfidEqualTo(Integer value) {
            addCriterion("afid =", value, "afid");
            return (Criteria) this;
        }

        public Criteria andAfidNotEqualTo(Integer value) {
            addCriterion("afid <>", value, "afid");
            return (Criteria) this;
        }

        public Criteria andAfidGreaterThan(Integer value) {
            addCriterion("afid >", value, "afid");
            return (Criteria) this;
        }

        public Criteria andAfidGreaterThanOrEqualTo(Integer value) {
            addCriterion("afid >=", value, "afid");
            return (Criteria) this;
        }

        public Criteria andAfidLessThan(Integer value) {
            addCriterion("afid <", value, "afid");
            return (Criteria) this;
        }

        public Criteria andAfidLessThanOrEqualTo(Integer value) {
            addCriterion("afid <=", value, "afid");
            return (Criteria) this;
        }

        public Criteria andAfidIn(List<Integer> values) {
            addCriterion("afid in", values, "afid");
            return (Criteria) this;
        }

        public Criteria andAfidNotIn(List<Integer> values) {
            addCriterion("afid not in", values, "afid");
            return (Criteria) this;
        }

        public Criteria andAfidBetween(Integer value1, Integer value2) {
            addCriterion("afid between", value1, value2, "afid");
            return (Criteria) this;
        }

        public Criteria andAfidNotBetween(Integer value1, Integer value2) {
            addCriterion("afid not between", value1, value2, "afid");
            return (Criteria) this;
        }

        public Criteria andClerkidIsNull() {
            addCriterion("clerkid is null");
            return (Criteria) this;
        }

        public Criteria andClerkidIsNotNull() {
            addCriterion("clerkid is not null");
            return (Criteria) this;
        }

        public Criteria andClerkidEqualTo(Integer value) {
            addCriterion("clerkid =", value, "clerkid");
            return (Criteria) this;
        }

        public Criteria andClerkidNotEqualTo(Integer value) {
            addCriterion("clerkid <>", value, "clerkid");
            return (Criteria) this;
        }

        public Criteria andClerkidGreaterThan(Integer value) {
            addCriterion("clerkid >", value, "clerkid");
            return (Criteria) this;
        }

        public Criteria andClerkidGreaterThanOrEqualTo(Integer value) {
            addCriterion("clerkid >=", value, "clerkid");
            return (Criteria) this;
        }

        public Criteria andClerkidLessThan(Integer value) {
            addCriterion("clerkid <", value, "clerkid");
            return (Criteria) this;
        }

        public Criteria andClerkidLessThanOrEqualTo(Integer value) {
            addCriterion("clerkid <=", value, "clerkid");
            return (Criteria) this;
        }

        public Criteria andClerkidIn(List<Integer> values) {
            addCriterion("clerkid in", values, "clerkid");
            return (Criteria) this;
        }

        public Criteria andClerkidNotIn(List<Integer> values) {
            addCriterion("clerkid not in", values, "clerkid");
            return (Criteria) this;
        }

        public Criteria andClerkidBetween(Integer value1, Integer value2) {
            addCriterion("clerkid between", value1, value2, "clerkid");
            return (Criteria) this;
        }

        public Criteria andClerkidNotBetween(Integer value1, Integer value2) {
            addCriterion("clerkid not between", value1, value2, "clerkid");
            return (Criteria) this;
        }

        public Criteria andAfareaIsNull() {
            addCriterion("afarea is null");
            return (Criteria) this;
        }

        public Criteria andAfareaIsNotNull() {
            addCriterion("afarea is not null");
            return (Criteria) this;
        }

        public Criteria andAfareaEqualTo(String value) {
            addCriterion("afarea =", value, "afarea");
            return (Criteria) this;
        }

        public Criteria andAfareaNotEqualTo(String value) {
            addCriterion("afarea <>", value, "afarea");
            return (Criteria) this;
        }

        public Criteria andAfareaGreaterThan(String value) {
            addCriterion("afarea >", value, "afarea");
            return (Criteria) this;
        }

        public Criteria andAfareaGreaterThanOrEqualTo(String value) {
            addCriterion("afarea >=", value, "afarea");
            return (Criteria) this;
        }

        public Criteria andAfareaLessThan(String value) {
            addCriterion("afarea <", value, "afarea");
            return (Criteria) this;
        }

        public Criteria andAfareaLessThanOrEqualTo(String value) {
            addCriterion("afarea <=", value, "afarea");
            return (Criteria) this;
        }

        public Criteria andAfareaLike(String value) {
            addCriterion("afarea like", value, "afarea");
            return (Criteria) this;
        }

        public Criteria andAfareaNotLike(String value) {
            addCriterion("afarea not like", value, "afarea");
            return (Criteria) this;
        }

        public Criteria andAfareaIn(List<String> values) {
            addCriterion("afarea in", values, "afarea");
            return (Criteria) this;
        }

        public Criteria andAfareaNotIn(List<String> values) {
            addCriterion("afarea not in", values, "afarea");
            return (Criteria) this;
        }

        public Criteria andAfareaBetween(String value1, String value2) {
            addCriterion("afarea between", value1, value2, "afarea");
            return (Criteria) this;
        }

        public Criteria andAfareaNotBetween(String value1, String value2) {
            addCriterion("afarea not between", value1, value2, "afarea");
            return (Criteria) this;
        }

        public Criteria andAfcontentIsNull() {
            addCriterion("afcontent is null");
            return (Criteria) this;
        }

        public Criteria andAfcontentIsNotNull() {
            addCriterion("afcontent is not null");
            return (Criteria) this;
        }

        public Criteria andAfcontentEqualTo(String value) {
            addCriterion("afcontent =", value, "afcontent");
            return (Criteria) this;
        }

        public Criteria andAfcontentNotEqualTo(String value) {
            addCriterion("afcontent <>", value, "afcontent");
            return (Criteria) this;
        }

        public Criteria andAfcontentGreaterThan(String value) {
            addCriterion("afcontent >", value, "afcontent");
            return (Criteria) this;
        }

        public Criteria andAfcontentGreaterThanOrEqualTo(String value) {
            addCriterion("afcontent >=", value, "afcontent");
            return (Criteria) this;
        }

        public Criteria andAfcontentLessThan(String value) {
            addCriterion("afcontent <", value, "afcontent");
            return (Criteria) this;
        }

        public Criteria andAfcontentLessThanOrEqualTo(String value) {
            addCriterion("afcontent <=", value, "afcontent");
            return (Criteria) this;
        }

        public Criteria andAfcontentLike(String value) {
            addCriterion("afcontent like", value, "afcontent");
            return (Criteria) this;
        }

        public Criteria andAfcontentNotLike(String value) {
            addCriterion("afcontent not like", value, "afcontent");
            return (Criteria) this;
        }

        public Criteria andAfcontentIn(List<String> values) {
            addCriterion("afcontent in", values, "afcontent");
            return (Criteria) this;
        }

        public Criteria andAfcontentNotIn(List<String> values) {
            addCriterion("afcontent not in", values, "afcontent");
            return (Criteria) this;
        }

        public Criteria andAfcontentBetween(String value1, String value2) {
            addCriterion("afcontent between", value1, value2, "afcontent");
            return (Criteria) this;
        }

        public Criteria andAfcontentNotBetween(String value1, String value2) {
            addCriterion("afcontent not between", value1, value2, "afcontent");
            return (Criteria) this;
        }

        public Criteria andAftimeIsNull() {
            addCriterion("aftime is null");
            return (Criteria) this;
        }

        public Criteria andAftimeIsNotNull() {
            addCriterion("aftime is not null");
            return (Criteria) this;
        }

        public Criteria andAftimeEqualTo(String value) {
            addCriterion("aftime =", value, "aftime");
            return (Criteria) this;
        }

        public Criteria andAftimeNotEqualTo(String value) {
            addCriterion("aftime <>", value, "aftime");
            return (Criteria) this;
        }

        public Criteria andAftimeGreaterThan(String value) {
            addCriterion("aftime >", value, "aftime");
            return (Criteria) this;
        }

        public Criteria andAftimeGreaterThanOrEqualTo(String value) {
            addCriterion("aftime >=", value, "aftime");
            return (Criteria) this;
        }

        public Criteria andAftimeLessThan(String value) {
            addCriterion("aftime <", value, "aftime");
            return (Criteria) this;
        }

        public Criteria andAftimeLessThanOrEqualTo(String value) {
            addCriterion("aftime <=", value, "aftime");
            return (Criteria) this;
        }

        public Criteria andAftimeLike(String value) {
            addCriterion("aftime like", value, "aftime");
            return (Criteria) this;
        }

        public Criteria andAftimeNotLike(String value) {
            addCriterion("aftime not like", value, "aftime");
            return (Criteria) this;
        }

        public Criteria andAftimeIn(List<String> values) {
            addCriterion("aftime in", values, "aftime");
            return (Criteria) this;
        }

        public Criteria andAftimeNotIn(List<String> values) {
            addCriterion("aftime not in", values, "aftime");
            return (Criteria) this;
        }

        public Criteria andAftimeBetween(String value1, String value2) {
            addCriterion("aftime between", value1, value2, "aftime");
            return (Criteria) this;
        }

        public Criteria andAftimeNotBetween(String value1, String value2) {
            addCriterion("aftime not between", value1, value2, "aftime");
            return (Criteria) this;
        }

        public Criteria andAfdateIsNull() {
            addCriterion("afdate is null");
            return (Criteria) this;
        }

        public Criteria andAfdateIsNotNull() {
            addCriterion("afdate is not null");
            return (Criteria) this;
        }

        public Criteria andAfdateEqualTo(String value) {
            addCriterion("afdate =", value, "afdate");
            return (Criteria) this;
        }

        public Criteria andAfdateNotEqualTo(String value) {
            addCriterion("afdate <>", value, "afdate");
            return (Criteria) this;
        }

        public Criteria andAfdateGreaterThan(String value) {
            addCriterion("afdate >", value, "afdate");
            return (Criteria) this;
        }

        public Criteria andAfdateGreaterThanOrEqualTo(String value) {
            addCriterion("afdate >=", value, "afdate");
            return (Criteria) this;
        }

        public Criteria andAfdateLessThan(String value) {
            addCriterion("afdate <", value, "afdate");
            return (Criteria) this;
        }

        public Criteria andAfdateLessThanOrEqualTo(String value) {
            addCriterion("afdate <=", value, "afdate");
            return (Criteria) this;
        }

        public Criteria andAfdateLike(String value) {
            addCriterion("afdate like", value, "afdate");
            return (Criteria) this;
        }

        public Criteria andAfdateNotLike(String value) {
            addCriterion("afdate not like", value, "afdate");
            return (Criteria) this;
        }

        public Criteria andAfdateIn(List<String> values) {
            addCriterion("afdate in", values, "afdate");
            return (Criteria) this;
        }

        public Criteria andAfdateNotIn(List<String> values) {
            addCriterion("afdate not in", values, "afdate");
            return (Criteria) this;
        }

        public Criteria andAfdateBetween(String value1, String value2) {
            addCriterion("afdate between", value1, value2, "afdate");
            return (Criteria) this;
        }

        public Criteria andAfdateNotBetween(String value1, String value2) {
            addCriterion("afdate not between", value1, value2, "afdate");
            return (Criteria) this;
        }

        public Criteria andAfplushIsNull() {
            addCriterion("afplush is null");
            return (Criteria) this;
        }

        public Criteria andAfplushIsNotNull() {
            addCriterion("afplush is not null");
            return (Criteria) this;
        }

        public Criteria andAfplushEqualTo(String value) {
            addCriterion("afplush =", value, "afplush");
            return (Criteria) this;
        }

        public Criteria andAfplushNotEqualTo(String value) {
            addCriterion("afplush <>", value, "afplush");
            return (Criteria) this;
        }

        public Criteria andAfplushGreaterThan(String value) {
            addCriterion("afplush >", value, "afplush");
            return (Criteria) this;
        }

        public Criteria andAfplushGreaterThanOrEqualTo(String value) {
            addCriterion("afplush >=", value, "afplush");
            return (Criteria) this;
        }

        public Criteria andAfplushLessThan(String value) {
            addCriterion("afplush <", value, "afplush");
            return (Criteria) this;
        }

        public Criteria andAfplushLessThanOrEqualTo(String value) {
            addCriterion("afplush <=", value, "afplush");
            return (Criteria) this;
        }

        public Criteria andAfplushLike(String value) {
            addCriterion("afplush like", value, "afplush");
            return (Criteria) this;
        }

        public Criteria andAfplushNotLike(String value) {
            addCriterion("afplush not like", value, "afplush");
            return (Criteria) this;
        }

        public Criteria andAfplushIn(List<String> values) {
            addCriterion("afplush in", values, "afplush");
            return (Criteria) this;
        }

        public Criteria andAfplushNotIn(List<String> values) {
            addCriterion("afplush not in", values, "afplush");
            return (Criteria) this;
        }

        public Criteria andAfplushBetween(String value1, String value2) {
            addCriterion("afplush between", value1, value2, "afplush");
            return (Criteria) this;
        }

        public Criteria andAfplushNotBetween(String value1, String value2) {
            addCriterion("afplush not between", value1, value2, "afplush");
            return (Criteria) this;
        }

        public Criteria andAfmaterialsIsNull() {
            addCriterion("afmaterials is null");
            return (Criteria) this;
        }

        public Criteria andAfmaterialsIsNotNull() {
            addCriterion("afmaterials is not null");
            return (Criteria) this;
        }

        public Criteria andAfmaterialsEqualTo(String value) {
            addCriterion("afmaterials =", value, "afmaterials");
            return (Criteria) this;
        }

        public Criteria andAfmaterialsNotEqualTo(String value) {
            addCriterion("afmaterials <>", value, "afmaterials");
            return (Criteria) this;
        }

        public Criteria andAfmaterialsGreaterThan(String value) {
            addCriterion("afmaterials >", value, "afmaterials");
            return (Criteria) this;
        }

        public Criteria andAfmaterialsGreaterThanOrEqualTo(String value) {
            addCriterion("afmaterials >=", value, "afmaterials");
            return (Criteria) this;
        }

        public Criteria andAfmaterialsLessThan(String value) {
            addCriterion("afmaterials <", value, "afmaterials");
            return (Criteria) this;
        }

        public Criteria andAfmaterialsLessThanOrEqualTo(String value) {
            addCriterion("afmaterials <=", value, "afmaterials");
            return (Criteria) this;
        }

        public Criteria andAfmaterialsLike(String value) {
            addCriterion("afmaterials like", value, "afmaterials");
            return (Criteria) this;
        }

        public Criteria andAfmaterialsNotLike(String value) {
            addCriterion("afmaterials not like", value, "afmaterials");
            return (Criteria) this;
        }

        public Criteria andAfmaterialsIn(List<String> values) {
            addCriterion("afmaterials in", values, "afmaterials");
            return (Criteria) this;
        }

        public Criteria andAfmaterialsNotIn(List<String> values) {
            addCriterion("afmaterials not in", values, "afmaterials");
            return (Criteria) this;
        }

        public Criteria andAfmaterialsBetween(String value1, String value2) {
            addCriterion("afmaterials between", value1, value2, "afmaterials");
            return (Criteria) this;
        }

        public Criteria andAfmaterialsNotBetween(String value1, String value2) {
            addCriterion("afmaterials not between", value1, value2, "afmaterials");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}