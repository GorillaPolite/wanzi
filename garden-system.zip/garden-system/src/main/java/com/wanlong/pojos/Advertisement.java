package com.wanlong.pojos;

public class Advertisement {
    private Integer aid;

    private String site;

    private String duration;

    private String state;

    private String residuedate;

    public Integer getAid() {
        return aid;
    }

    public void setAid(Integer aid) {
        this.aid = aid;
    }

    public String getSite() {
        return site;
    }

    public void setSite(String site) {
        this.site = site == null ? null : site.trim();
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration == null ? null : duration.trim();
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public String getResiduedate() {
        return residuedate;
    }

    public void setResiduedate(String residuedate) {
        this.residuedate = residuedate == null ? null : residuedate.trim();
    }
}