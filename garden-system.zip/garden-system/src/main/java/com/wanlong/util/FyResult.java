package com.wanlong.util;

import java.util.ArrayList;
import java.util.List;

import com.wanlong.pojos.Owner;

/**
 * @author Tom
 * @category 返回分页结果的工具类
 *
 */
public class FyResult {

	public static List<Owner> getOwnerList(int pageSize, int pageNum, List<Owner> list1, String type) {
		double listnum = list1.size();
		// 总页数
		int totalnum = (int) Math.ceil(listnum / pageSize);
		// System.out.println(list1.size());
		if (type.equals("z")) {

			++pageNum;
		}
		if (type.equals("j")) {

			--pageNum;
		}
		if (pageNum > totalnum) {

			pageNum = totalnum;

		}
		if (pageNum < 1) {

			pageNum = 1;

		}
		List<Owner> list = new ArrayList<>();
		int index = pageSize * pageNum;
		if (index >= list1.size()) {
			index = list1.size();
		}
		for (int i = (pageNum - 1) * pageSize; i < index; i++) {
			list.add(list1.get(i));
		}
		return list;
	}

}
