package com.wanlong.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wanlong.dao.OwnerMapper;
import com.wanlong.pojos.Owner;
import com.wanlong.pojos.SessionContent;
import com.wanlong.service.OwnerService;
import com.wanlong.service.SessionContentService;

/**
 * @author Leett
 * @category 会话Controller
 *
 */
@Controller
public class DialogueController {

	@Autowired
	OwnerService OwnerService;
	@Autowired
	SessionContentService sessionContentService;
	@RequestMapping(value="/dialogue",method=RequestMethod.POST)
	public @ResponseBody List<SessionContent> dialogue(String content,String tel) {
		Owner owner = OwnerService.findByTel1(tel);
		SessionContent sessionContent = new SessionContent();
		sessionContent.setUname(owner.getOname());
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date time = new Date();
		String date = format.format(time);
		sessionContent.setTime(date);
		sessionContent.setContent(content);
		sessionContent.setCustomer("客服1");
		sessionContentService.addOne(sessionContent);
		List<SessionContent> list = sessionContentService.findAll();
		return list;
	}
	@RequestMapping(value="/dialogue1",method=RequestMethod.POST)
	public @ResponseBody List<SessionContent> dialogue1() {
		List<SessionContent> list = sessionContentService.findAll();
		return list;
	}
	
	@RequestMapping("/scoreshow")
	public String scoreshow(Model model){
		List<SessionContent> list = sessionContentService.findsources();
		model.addAttribute("sessionlist", list);
		return "scoreshow";
		
	}
}
