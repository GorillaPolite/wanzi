package com.wanlong.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.wanlong.pojos.Maintain;
import com.wanlong.service.MaintainService;

/**
 * 
 * @author mufeng
 * @category 维修控制器
 *
 */
@Controller
public class MaintainController {

	@Autowired
	MaintainService mainService;
	/**
	 * 查询所有维修内容
	 */
	@RequestMapping("/malist")
	public String malist(Model model) {
		List<Maintain>list=mainService.selectByExample();
		model.addAttribute("malist", list);
		System.out.println(list.size());
		return "maintain";
	}
	/**
	 * 分类查询维修信息
	 */
	@RequestMapping("/malist2")
	public String malist2(Model model,String mbit) {
		List<Maintain> list=mainService.findMaintainList(mbit);
		model.addAttribute("malist", list);
		return "maintain2";
	}
	/**
	 * 保存
	 * 
	 * @return
	 */
	@RequestMapping("/save1")
	public String save(Maintain maintain, Model model) {
		mainService.updatesave2(maintain);
		return "redirect:malist.action";
	}
	/**
	 * 根据id查询所有的维修信息
	 */
	@RequestMapping("/findMaintainById")
	public String findMaintainById(Model model, @RequestParam(value = "mid", defaultValue = "0") int mid) {
		Maintain maintain = mainService.findMaintainById(mid);
		model.addAttribute("malist", maintain);
		return "maintain";
	}
	/**
	 * 点击更改完成状态
	 */
	@RequestMapping("/mbitupdate")
	public String mbitupdate(Maintain maintain) {
		mainService.updatmbit(maintain);
		return "redirect:malist.action";
	}
	/**
	 * 删除一个住户
	 */
	@RequestMapping("/deletemm1")
	public String deleteone(int mid) {
		mainService.deleteByPrimaryKey(mid);
		return "redirect:malist.action";
	}
	
	/**
	 * 用户登记维修信息
	 */
	@RequestMapping("/addmaintain")
	public String signin() {
		return "appealma";
	}

	// 客户注册控制器
	@RequestMapping("/signinjudge11")
	public String signinjudge(Maintain maintain) {
	
		boolean flag = mainService.insert(maintain);
		
		if (flag == true) {

			// 使用重定向，返回登录界面
			return "udatesuccess";
		} else {
			return "appealma";
		}
	}
	/**
	 * 维修部门自己登记
	 * @param maintain
	 * @return
	 */
	@RequestMapping("/addmm")
	public String addmm(Maintain maintain) {
	
		boolean flag = mainService.insert2(maintain);	
		if (flag == true) {

			// 使用重定向，返回登录界面
			return "redirect:malist.action";
		} else {
			return "css";
		}
	}
	/**
	 * 根据结束时间日期查询
	 */
	@RequestMapping("/findMaintainBymdate")
	public String findMaintainBymdate(Model model,String mdate) {
		List<Maintain>list2 = mainService.findMaintainBymdate(mdate);
		model.addAttribute("malist", list2);
		return "maintain";
	}

	/**
	 * 根据id  完成时间   提交时间 模糊查询
	 * @param model
	 * @param md
	 * @return
	 */
	@RequestMapping("/findMain")
	public String findMain(Model model,String md) {
		System.out.println("+++++++++++++");
		System.out.println(md);
		List<Maintain>list3 = mainService.findMain(md);
		model.addAttribute("malist", list3);
		
		return "maintain";
	}
	/**
	 *  跳转显示页面
	 */
	@RequestMapping("/company")
	public String company(Model model,String md) {
		return "company";
	}
}
