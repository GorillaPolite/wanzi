package com.wanlong.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.wanlong.pojos.Complain;
import com.wanlong.pojos.ComplainExample;
import com.wanlong.service.ComplainService;

@Controller
public class ComplainController {
	@Autowired
	ComplainService complainService;
	ComplainExample complainExample = new ComplainExample() ;
	@RequestMapping("/main")
	public String test() {
		return "main";
	}
	
	/**
	 * 全部投诉信息
	 */
	@RequestMapping("/complain")
	public String complain(Model model) {
		List<Complain> list =complainService.findAll();
		model.addAttribute("complainlist", list);
		return "complain";
	}
	/**
	 * 业主跳转添加投诉页面
	 */
	@RequestMapping("/addcomplaint")
	public String addcomplaint() {
		return "addonecomplain";
	}
	/**
	 * 添加投诉到数据库
	 */
	@RequestMapping("/savecomplain")
	public String savecomplain(Complain complain) {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");
		Date date = new Date();
		String d = format.format(date);
		complain.setStatedate(d);
		complainService.addOne(complain);
		return "addonecomplain";
	}
	/**
	 * 分类投诉信息
	 */
	@RequestMapping("/complainstate")
	public String complainstate(Model model,String state) {
		List<Complain> list =complainService.findByState(state);
		model.addAttribute("complainlist", list);
		return "complain";
	}
	/**
	 * 查询投诉信息
	 */
	@RequestMapping("/mycomplaint")
	public String mycomplaint(Model model,HttpSession session) {
		System.out.println("mycomplaint:"+(int)session.getAttribute("owneruid"));
		List<Complain> list = complainService.findByOid((int) session.getAttribute("owneruid"));
		model.addAttribute("mycomplaintlist", list);
		return "mycomplaint";
	}
	@RequestMapping("/test")
	public String test1() {
		return "test";
	}
}
