package com.wanlong.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.wanlong.pojos.Bill;
import com.wanlong.pojos.Owner;
import com.wanlong.service.BillService;

@Controller
public class MybillController {
	
	@Autowired
	private BillService billService;
	
	@RequestMapping("/mybill")
	public String mybill(HttpSession session,Model model) {
		Owner owner1=(Owner) session.getAttribute("currentOwnerr");
		Owner owner=billService.findByOid1(owner1.getOid());
		model.addAttribute("owner", owner);
		return "mybill";
	}
	@RequestMapping("/checkout")
	public String checkout(int[] ids,Model model) {
		String name = "";
		double osum = 0;
		Date date = new Date();
		SimpleDateFormat ornumber = new SimpleDateFormat("yyyyMMddHHmmssSSSS");
		String ordernumber = ornumber.format(date);
		List<Bill> list=billService.findByOid(ids);
		for (int i = 0; i < list.size(); i++) {
			name+=list.get(i).getBillitem().getBillitemname()+list.get(i).getBilltime()+"￥"+list.get(i).getBillitem().getBillitemmoney()+"\t";
			osum+=list.get(i).getBillitem().getBillitemmoney();
		}
		 
		billService.updateBillnum(ordernumber, ids);
		
		model.addAttribute("orderNumber", ordernumber);
		model.addAttribute("name", name);
		model.addAttribute("osum", osum);
		
		return "checkout";
	}
	@RequestMapping("/mybillpay")
	public String mybillpay(HttpSession session,Model model) {
		Owner owner1=(Owner) session.getAttribute("currentOwnerr");
		Owner owner=billService.findByOid2(owner1.getOid());
		model.addAttribute("owner", owner);
		return "mybillpay";
	}
}
