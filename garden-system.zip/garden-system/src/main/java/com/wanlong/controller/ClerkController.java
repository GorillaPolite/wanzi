package com.wanlong.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.wanlong.pojos.Clerk;
import com.wanlong.service.ClerkService;
import com.wanlong.util.PageRequest;
import com.wanlong.util.PageResult;

/**
 * @author June
 * @category 职员控制器
 */
@Controller
public class ClerkController {
	@Autowired
	ClerkService clerkService;

	@RequestMapping("/clerkselectall")
	public String ClerkSelectAll(Model model) {
		List<Clerk> list = clerkService.find();
		System.out.println(list.size());
		model.addAttribute("clerkselectall", list);
		return "clerklist";
	}

	// 进入添加职员页面
	@RequestMapping("/clerkadd")
	public String ClerkAdd() {
		return "clerkadd";
	}

	// 添加页面提交添加数据返回查找控制器
	@RequestMapping("/clerkaddsave")
	public String ClerkAddSave(Clerk clerk) {
		boolean flag = clerkService.insert(clerk);
		return "redirect:findpage2.action";
	}

	// 删除职员
	@RequestMapping("/clerkdelete")
	public String ClerkDelete(int[] clerkids) {
		boolean flag = clerkService.delete(clerkids);
		return "redirect:findpage2.action";
	}

	// 进入更新职员页面
	@RequestMapping("/clerkupdate")
	public String ClerkUpdate(int clerkid, Model model) {
		System.out.println(clerkid + "我进来了！！！！！！");
		Clerk clerk = clerkService.find(clerkid);
		model.addAttribute("clerk", clerk);
		return "updateclerk";
	}

	// 更新页面提交数据返回查找控制器
	@RequestMapping("/clerkupdatesave")
	public String ClerkUpdate(Clerk clerk) {
		boolean flag = clerkService.update(clerk);
		return "redirect:findpage2.action";
	}

	// 分页查询
	@RequestMapping("/findpage")
	public String findPage(int pageSize, int pageNum, Model model, String str, HttpSession session) {
		System.out.println("进来了");
		System.out.println(pageSize);
		System.out.println(str);
		if (str.equals("z")) {
			++pageNum;
		} else if (str.equals("j")) {
			--pageNum;
		}
		session.setAttribute("pageSize", pageSize);
		PageRequest pageQuery = new PageRequest();
		pageQuery.setPageNum(pageNum);
		pageQuery.setPageSize(pageSize);
		PageResult pageResult = clerkService.findPage(pageQuery);
		model.addAttribute("pageResult", pageResult);
		return "clerklist";

	}

	// 分页模糊查询
	@RequestMapping("/clerkselectlike")
	public String ClerkSelectLike(String like, int pageSize, int pageNum, Model model, String str,
			HttpSession session) {
		System.out.println("进来了");
		System.out.println(pageSize);
		System.out.println(str);
		System.out.println(like);
		if (str.equals("z")) {
			++pageNum;
		} else if (str.equals("j")) {
			--pageNum;
		}
		session.setAttribute("like",like);
		session.setAttribute("pageSize", pageSize);
		PageRequest pageQuery = new PageRequest();
		pageQuery.setPageNum(pageNum);
		pageQuery.setPageSize(pageSize);
		PageResult pageResult = clerkService.findPageByLike(like, pageQuery);
		model.addAttribute("pageResult", pageResult);
		return "clerklist2";
	}

	@RequestMapping("/clerkselectlike1")
	public String clerkselectlike1( String like,int pageSize, Model model, HttpSession session) {
		System.out.println("进来了");
		System.out.println(pageSize);
		PageRequest pageQuery = new PageRequest();
		pageQuery.setPageNum(1);
		pageQuery.setPageSize(pageSize);
		session.setAttribute("pageSize", pageSize);
		PageResult pageResult = clerkService.findPageByLike(like, pageQuery);
		model.addAttribute("pageResult", pageResult);
		return "clerklist2";

	}

	@RequestMapping("/findpage1")
	public String findPage1(int pageSize, Model model, HttpSession session) {
		System.out.println("进来了");
		System.out.println(pageSize);
		PageRequest pageQuery = new PageRequest();
		pageQuery.setPageNum(1);
		pageQuery.setPageSize(pageSize);
		session.setAttribute("pageSize", pageSize);
		PageResult pageResult = clerkService.findPage(pageQuery);
		model.addAttribute("pageResult", pageResult);
		return "clerklist";

	}

	@RequestMapping("/findpage2")
	public String findPage2(Model model, HttpSession session) {
		System.out.println("进来了");
		int pageSize = (int) session.getAttribute("pageSize");
		System.out.println(pageSize);
		PageRequest pageQuery = new PageRequest();
		pageQuery.setPageNum(1);
		pageQuery.setPageSize(pageSize);
		session.setAttribute("pageSize", pageSize);
		PageResult pageResult = clerkService.findPage(pageQuery);
		model.addAttribute("pageResult", pageResult);
		return "clerklist";

	}
}
