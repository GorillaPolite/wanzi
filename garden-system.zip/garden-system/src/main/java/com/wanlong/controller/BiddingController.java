package com.wanlong.controller;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.wanlong.pojos.Bidding;
import com.wanlong.pojos.Tender;
import com.wanlong.service.BiddingService;
import com.wanlong.service.TenderService;
import com.wanlong.vo.TenderVo;

/**
 * @author Leett
 * @category 商铺控制器
 *
 */
@Controller
public class BiddingController {
	@Autowired
	BiddingService biddingService;
	@Autowired
	TenderService tenderService;

	@RequestMapping("/savestorebid")
	public String addOne(Model model, Bidding bidding, double price) {
		double price1 = bidding.getArea() * price;
		Timestamp d = new Timestamp(System.currentTimeMillis());
		bidding.setPrice(price1);
		bidding.setDate(d);
		bidding.setState("正在竞标");
		biddingService.addOne(bidding);
		return "redirect:biddinging.action";
	}

	@RequestMapping("/")
	public String zhuye() {
		return "redirect:jingbiao.action";
	}
	@RequestMapping("/biddingshow")
	public String biddingShow(Model model) {
		List<Bidding> list = biddingService.findAll();
		model.addAttribute("biddinglist", list);
		return "bidding";
	}

	@RequestMapping("/deletebiddingone")
	public String deleteOne(int bid) {
		return null;
	}

	@RequestMapping("/biddinging")
	public String biddingIng(Model model) {
		List<Tender> list = tenderService.findAll();
		model.addAttribute("adornShowList", list);
		return "audit";
	}

	@RequestMapping("/mybidding")
	public String mybidding(Model model, HttpSession session) {
		String tel = (String) session.getAttribute("userTel");
		List<TenderVo> list = tenderService.findByTel(tel);
		for (TenderVo t : list) {
			System.out.println(t.getTid());
		}
		model.addAttribute("mylist", list);
		return "myjingbiao";
	}

	@RequestMapping("/savejingbianman")
	public String savejingbianman(int bid, Tender tender, Model model, HttpSession session) {
		biddingService.updateOne(bid);
		try {
			Thread.sleep(1000);
			tenderService.addOne(tender);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		session.setAttribute("userTel", tender.getTel());
		return "redirect:jingbiao.action";
	}

	@RequestMapping("/jingbiao")
	public String jingbiao(Model model) {
		List<Bidding> list = biddingService.findAll();
		model.addAttribute("biddinglist", list);
		return "jingbiao";
	}

	@RequestMapping("/deletemyjingbiao")
	public String deletemyjingbiao(int tid) {
		System.out.println("deletemyjingbiao:" + tid);
		tenderService.deleteTenderOne(tid);
		return "redirect:jingbiao.action";
	}

	/**
	 * 通过audit字段查找list
	 */
	@RequestMapping("/auditingbyaudit")
	public String auditingbyaudit(Model model, String audit) {
		List<Tender> list = tenderService.findByAudit(audit);
		model.addAttribute("adornShowList", list);
		return "audit";
	}

	@RequestMapping("/auditingbyliftstate")
	public String auditingbyliftstate(Model model, int liftstate) {
		List<Tender> list = tenderService.findByLiftstate(liftstate);
		model.addAttribute("adornShowList", list);
		return "audit";
	}

	/**
	 * 拒绝竞标控制
	 */
	@RequestMapping("/refuse")
	public String refuse(int tid, String remaker) {
		System.out.println("refuse:" + remaker);
		tenderService.refuse(tid, remaker);
		return "redirect:biddinging.action";
	}
	/**
	 * 竞标通过
	 */
	@RequestMapping("/yespass")
	public String yespass(int tid) {
		biddingService.yesPass(tid);
		return "redirect:biddinging.action";
	}

	/**
	 * 搜索展示
	 */
	@RequestMapping("/searchjb")
	public String searchjb(String searchtext,Model model) {
		List<Bidding> list = new ArrayList<Bidding>();
		list = biddingService.selectLike(searchtext);
		 if(list.size()==0) {
			 String[] str = searchtext.split("");
			 for (int i = 0; i < str.length; i++) {
				 list = biddingService.selectLike(str[i]);
				 if(list.size()>0) break;
				 if(biddingService.selectLike(str[str.length-1]).size()<=0) {
					 list = biddingService.selectLike("");
					 
				 }
			 }
		 }
		 model.addAttribute("biddinglist", list);
		return "jingbiao";
	}

}
