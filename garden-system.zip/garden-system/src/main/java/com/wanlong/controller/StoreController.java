package com.wanlong.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.wanlong.pojos.Store;
import com.wanlong.service.StoreService;

/**
 * @author Leett
 * @date 2020年11月16日 下午8:31:45
 * @category 商铺控制器
 */
@Controller
public class StoreController {
	@Autowired
	StoreService storeService;

	@RequestMapping("/allstore")
	public String allStore(Model model) {
		List<Store> list = storeService.findAll();
		model.addAttribute("storelist", list);
		return "store";
	}
	@RequestMapping("/findadornbystate")
	public String findByState(Model model,String state) {
		List<Store> list = storeService.findByState(state);
		model.addAttribute("storelist", list);
		return "store";
	}
}
