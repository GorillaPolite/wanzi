package com.wanlong.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.wanlong.pojos.Adorn;
import com.wanlong.service.AdornService;

/**
 * @author Leett
 * @date 2020年11月16日 下午8:07:31
 * @category 装修控制器
 * 
 */
@Controller
public class AdornController {
	@Autowired
	AdornService adornService;

	/**
	 * 查找所有
	 */
	@RequestMapping("/adornall")
	public String adornAll(Model model) {
		List<Adorn> list = adornService.findAll();
		model.addAttribute("adornlist", list);
		return "adorn";
	}

	/**
	 * 按类型删除
	 */
	@RequestMapping("/findbystate")
	public String findByState(Model model, String state) {
		List<Adorn> list = adornService.findByState(state);
		model.addAttribute("adornlist", list);
		return "adorn";
	}

}
