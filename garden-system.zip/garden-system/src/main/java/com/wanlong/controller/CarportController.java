package com.wanlong.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wanlong.pojos.Carport;
import com.wanlong.service.CarportService;

/**
 * @author Leett
 * @date 2020年11月16日 下午5:02:13
 * @category 车位控制器
 */
@Controller
public class CarportController {
	@Autowired
	CarportService carportService;

	@RequestMapping("/allcar")
	public String allcar(Model model,@RequestParam(value="num",defaultValue="1")int num) {
		int pageNum1 = (num-1)*5; 
		System.out.println("jinru"+num);
		System.out.println("jinru"+pageNum1);
		List<Carport> list = carportService.findAll(1,pageNum1);
		List<Carport> list1 = carportService.findAll(-1,pageNum1);
		int pageNum =(int) Math.ceil(list1.size()/5);
		model.addAttribute("carportlist", list);
		model.addAttribute("pageNum", pageNum);
		return "carport";
	}
	@RequestMapping("/findcarbyarea")
	public String findCarByArea(Model model,String area) {
		List<Carport> list = carportService.findCarByArea(area);
		model.addAttribute("carportlist", list);
		return "carport";
	}
	@RequestMapping(value="/page1",method=RequestMethod.POST)
	public @ResponseBody List<Carport> page1(int page) {
		int pageNum1 = (page-1)*5; 
		System.out.println("jinru:"+page);
		System.out.println("jinru:"+pageNum1);
		List<Carport> list = carportService.findAll(1,pageNum1);
		return list;
	}
	@RequestMapping("/findcarbystate")
	public String findCarByState(Model model,String state) {
		List<Carport> list = carportService.findCarByState(state);
		model.addAttribute("carportlist", list);
		return "carport";
	}
	@RequestMapping("/updatetime")
	public void updatetime() {
		boolean flag = carportService.updatetime();
		System.out.println("flag:"+flag);
	}
	/**
	 * 购买车个更改状态
	 */
	@RequestMapping("/suresellcar")
	public @ResponseBody boolean suresellcar(int uid,HttpSession session) {
		int owneruid = (int) session.getAttribute("owneruid");
		System.out.println("suresellcar:"+uid);
		Carport carport = new Carport();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");
		Date date = new Date();
		String d = format.format(date);
		String state = "<span style=\"color:red;font-weight: 700\">占用</span>";
		carport.setDate(d);
		carport.setUid(owneruid);
		carport.setCid(uid);
		carport.setState(state);
		boolean flag = carportService.suresellcar(carport);
		return flag;
		
	}
	@RequestMapping(value="/startsellcar",method=RequestMethod.POST)
	public @ResponseBody boolean startsellcar(String time) {
		boolean flag =false;
		List<Carport> list = carportService.findAll(-1, 0);
		 for (Carport c : list) {
			if(c.getDuration().equals(time)) {
				flag = false;
				return flag;
			}else {
				flag = true;
			}
		}
		if(flag) {
			flag =  carportService.sellCar(time);
		}
		return flag;
	}
	@RequestMapping("/sellcar")
	public String sellcar(Model model) {
		List<Carport> list = carportService.findCarByState("未使用");
		int count = list.size();
		List<Carport> list1 = new ArrayList<Carport>();
		list1 = carportService.findCarByArea("A");
		model.addAttribute("A", list1);
		list1 = carportService.findCarByArea("B");
		model.addAttribute("B", list1);
		list1 = carportService.findCarByArea("C");
		model.addAttribute("C", list1);
		list1 = carportService.findCarByArea("D");
		model.addAttribute("D", list1);
		model.addAttribute("count", count);
		return "sellcar";
	}
}
