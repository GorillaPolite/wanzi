package com.wanlong.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wanlong.pojos.Message;
import com.wanlong.pojos.Owner;
import com.wanlong.service.MessageService;
import com.wanlong.service.OwnerService;

/**
 * @category 用户通知控制器
 * @author Tom
 *
 */

@Controller
public class MessageController {

	
	@Autowired
	private MessageService messService;
	@Autowired
	private OwnerService ownerService;
	
	private SimpleDateFormat cx = new SimpleDateFormat("yyyy-MM-dd");
	
	/**
	 * @category 未阅读的通知
	 * @param model
	 * @param request
	 * @return
	 */
	@RequestMapping("/unread.action")
	public String unread(Model model,HttpServletRequest request) {
		System.out.println("我进来了");
		HttpSession session = request.getSession();
		Owner owner=(Owner)session.getAttribute("currentOwnerr");
		List<Message> list1=messService.selectByOid(owner.getOid());
		List<Message> list=new ArrayList<Message>();
		for (int i = 0; i < list1.size(); i++) {
			if(list1.get(i).getStatus().equals("未阅读")) {
				
				list.add(list1.get(i));
			}
		}
		if(list.size()<1) {
			model.addAttribute("nomess", "暂无通知");
		}
		model.addAttribute("type", "未阅读");
		model.addAttribute("readlist", list);
		return "messinfo";
	}
	/**
	 * @category 已阅读的通知
	 * @param model
	 * @param request
	 * @return
	 */
	@RequestMapping("/readed.action")
	public String readed(Model model,HttpServletRequest request) { 
		System.out.println("我进来了");
		HttpSession session = request.getSession();
		Owner owner=(Owner)session.getAttribute("currentOwnerr");
		List<Message> list1=messService.selectByOid(owner.getOid());
		List<Message> list=new ArrayList<Message>();
		for (int i = 0; i < list1.size(); i++) {
			if(list1.get(i).getStatus().equals("已读")) {
				
				list.add(list1.get(i));
			}
		}
		model.addAttribute("type", "已读");
		model.addAttribute("readlist", list);
		model.addAttribute("nomess", " ");
		return "messinfo";
	}
	/**
	 * @category 单个已读操作
	 * @param messid
	 * @param model
	 * @return
	 */
	@RequestMapping("/doread.action")
	public String doread(int messid,Model model) {
		Message mess=new Message();	
		mess.setMessid(messid);
		mess.setStatus("已读");
		messService.updateByPrimaryKeySelective(mess);
		return "redirect:unread.action";
	}
	/**
	 * @category ajax控制器用于动态传递业主通知数量
	 * @param request
	 * @return
	 */
	@RequestMapping("/showMessNum")
	public @ResponseBody List<String> showMessNum(HttpServletRequest request) {
		//System.out.println("json");
		HttpSession session = request.getSession();
		Owner owner=(Owner)session.getAttribute("currentOwnerr");
		//System.out.println(owner.getOname());
		List<Message> list1=messService.selectByOid(owner.getOid());
		List<Message> list=new ArrayList<Message>();
		for (int i = 0; i < list1.size(); i++) {
			if(list1.get(i).getStatus().equals("未阅读")) {
				
				list.add(list1.get(i));
			}
		}
		String a= "我的通知"+list.size();
		String b="未读"+list.size();
		List<String> list2=new ArrayList<>();
		list2.add(a);
		list2.add(b);
		return list2;
	}
	
	/**
	 * @category 通知一键已读控制器
	 * @param request
	 * @param model
	 * @return
	 */
	@RequestMapping("/allread.action")
	public String allread(HttpServletRequest request,Model model) {
		HttpSession session = request.getSession();
		Owner owner=(Owner)session.getAttribute("currentOwnerr");
		messService.updateByOid(owner.getOid());
		model.addAttribute("nomess", "暂无通知");
		model.addAttribute("readlist", null);
		return "messinfo";
	}

	/**
	 * @category 给业主发送催款通知
	 * @param oid
	 * @return
	 */
	@RequestMapping("/cuikuan.action")
	public @ResponseBody int cuikuan(int oid) {
		
		Message mess=new Message();
		mess.setMessinfo("请您及时缴纳相关费用，详情请到我的账单查看");
		mess.setOid(oid);
		mess.setStatus("未阅读");
		Date date=new Date();
		String time=cx.format(date);
		mess.setMesstime(time);
		messService.insert(mess);
		return oid;
		
	}
	
	@RequestMapping("/sendmess")
	public @ResponseBody List<String> sendmess(HttpServletRequest request,String message,Integer oid){
		//System.out.println(oid);
		//System.out.println(message);
		String oname=ownerService.findById(oid).getOname();
		Date date=new Date();
		String timeString=cx.format(date);
		Message mess=new Message();
		mess.setMessinfo(message);
		mess.setOid(oid);
		mess.setStatus("未阅读");
		mess.setMesstime(timeString);
		messService.insert(mess);
		List<String> list=new ArrayList<>();
		list.add(oname);
		return list;		
	}
	
}

