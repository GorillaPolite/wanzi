package com.wanlong.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.wanlong.pojos.Clerk;
import com.wanlong.pojos.Facility;
import com.wanlong.service.FacilityService;

/**
 * @author June
 * @category 设备控制器
 */
@Controller
public class FacilityController {
	@Autowired
	FacilityService facilityService;

	@RequestMapping("/facilityselectall")
	public String FacilitySelectAll(Model model) {
		List<Facility> list = facilityService.find();
		System.out.println(list.get(0).getFacilitypic());
		System.out.println("=====================" + list.size());
		model.addAttribute("FacilitySelectAll", list);
		return "facilitylist";
	}

	// 模糊查询
	@RequestMapping("/facilityselectlike")
	public String FacilitySelectLike(String like, Model model) {
		List<Facility> list = facilityService.findLike(like);
		model.addAttribute("FacilitySelectAll", list);
		return "facilitylist";
	}

	// 进入添加页面
	@RequestMapping("/facilityAdd")
	public String FacilityAdd() {
		return "facilityadd";
	}

	// 添加设备
	@RequestMapping("/facilityAddSave")
	public String FacilityAddSave(Facility facility) {
		boolean flag = facilityService.insert(facility);
		return "redirect:facilityselectall.action";
	}

	// 删除设备
	@RequestMapping("/facilityDelete")
	public String facilityDelete(int[] facilityids) {
		boolean flag = facilityService.delete(facilityids);
		return "redirect:facilityselectall.action";
	}

	// 进入更新职员页面
	@RequestMapping("/facilityupdate")
	public String FacilityUpdate(int facilityid, Model model) {
		System.out.println(facilityid + "我进来了！！！！！！");
		Facility facility = facilityService.find(facilityid);
		model.addAttribute("facility", facility);
		return "updatefacility";
	}

	// 更新页面提交数据返回查找控制器
	@RequestMapping("/facilityupdatesave")
	public String ClerkUpdate(Facility facility) {
		boolean flag = facilityService.update(facility);
		return "redirect:facilityselectall.action";
	}
}
