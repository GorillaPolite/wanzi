package com.wanlong.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.wanlong.pojos.Housenumber;
import com.wanlong.pojos.HousenumberExample;
import com.wanlong.service.HouseNumberService;

/**
 * @author Tom
 * @category 房间处理器
 *
 */
@Controller
public class HouseController {

	@Autowired
	private HouseNumberService hService;
	
	/**
	 * @category 通过传入参数展示相应的房屋信息
	 * @param type
	 * @param model
	 * @return
	 */
	@RequestMapping("/showhouse")
	
	public String showhouse(@RequestParam ("type") String type,Model model) {
		System.out.println(type);
		HousenumberExample example=new HousenumberExample();
		List<Housenumber> list=hService.selectByExample(example);
		List<Housenumber> list1=new ArrayList<Housenumber>();
		if(type.equals("a")) {
			model.addAttribute("list", list);
			model.addAttribute("can", "a");
			return  "house";
		}
		else if(type.equals("x")) {
			for (int i = 0; i < list.size(); i++) {
				if(list.get(i).getStatus().equals("闲置")) {
					list1.add(list.get(i));
				}
			}
			model.addAttribute("can", "x");
			model.addAttribute("list", list1);
			return  "house";
		}
		else if(type.equals("y")) {
			for (int i = 0; i < list.size(); i++) {
				if(list.get(i).getStatus().equals("已出售")) {
					list1.add(list.get(i));
				}
			}
			model.addAttribute("can", "y");
			model.addAttribute("list", list1);
			return  "house";
		}	
		return "mian";
	}
	
	/**
	 * @category 跳转到更新房屋信息页面
	 * @param model
	 * @param homeid
	 * @return
	 */
	@RequestMapping("/updatehouse")
	public String updatehouse(Model model,@RequestParam ("homeid") int homeid) {
		Housenumber house=hService.selectByPrimaryKey(homeid);
		model.addAttribute("house", house);
		return "updatehouse";
		
	}
	/**
	 * @category 跟新房屋信息
	 * @param model
	 * @param house
	 * @return
	 */
	@RequestMapping("/updatehouse1")
	public String updatehouse1(Model model, Housenumber house) {
		String type=house.getStatus();
		if(type.equals("闲置")) {
			type="x";
			
		}else if(type.equals("已出售")) {
			type="y";
		}
		System.out.println(house.getStatus());
		hService.updateByPrimaryKeySelective(house);
		model.addAttribute("house", house);
		return "redirect:showhouse.action?type="+type;
		
	}
	/**
	 * @category 添加新的闲置房屋
	 * @param model
	 * @param house
	 * @return
	 */
	@RequestMapping("/addhouse")
	public String addhouse(Model model,Housenumber house) {
		house.setSaleprice(0);
		hService.insert(house);
		return "redirect:showhouse.action?type=a";
		
	}
	
}
