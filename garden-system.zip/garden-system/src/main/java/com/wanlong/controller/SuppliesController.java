package com.wanlong.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.wanlong.pojos.Supplies;
import com.wanlong.service.SuppliesService;

/**
 * @author June
 * @category 物料控制器
 */
@Controller
public class SuppliesController {
	@Autowired
	SuppliesService suppliesService;
	
	@RequestMapping("/suppliesselectall")
	public String SuppliesSelectAll(Model model) {
		List<Supplies> list1 =suppliesService.find();
		System.out.println("===================="+list1.size());
		model.addAttribute("SuppliesSelectAll", list1);
		return "supplieslist";
	}
	//模糊查询控制器
	@RequestMapping("/suppliesSelectLike")
	public String suppliesSelectLike(String like,Model model) {
		List<Supplies> list2 =suppliesService.findByLike(like);
		model.addAttribute("SuppliesSelectAll", list2);
		return "supplieslist";
	}
	//添加物料控制器
	@RequestMapping("/suppliesadd")
	public String suppliesadd(Supplies supplies) {
		boolean flag=suppliesService.insert(supplies);
		return "suppliesadd";
	}
	//添加物料返回查找页面
	@RequestMapping("/suppliesaddsave")
	public String suppliesaddsave(Model model) {
		List<Supplies> list =suppliesService.find();
		model.addAttribute("SuppliesSelectAll", list);
		return "redirect:suppliesselectall.action";
	}
	//更新物料控制器
	@RequestMapping("/suppliesupdate")
	public String suppliesupdate(int suppliesid,Model model) {
		Supplies supplies=suppliesService.findById(suppliesid);
		model.addAttribute("supplies", supplies);
		return "updatesupplies";
	}
	//更新物料返回查找页面
	@RequestMapping("suppliesupdatesave")
	public String suppliesupdatesave(Model model) {
		List<Supplies> list =suppliesService.find();
		model.addAttribute("SuppliesSelectAll", list);
		return "redirect:suppliesselectall.action";
	}
	//删除物料控制器，返回查找页面
	@RequestMapping("/suppliesdelete")
	public String deletesupplies(int[] suppliesids) {
		boolean flag=suppliesService.delete(suppliesids);		
		return "redirect:suppliesselectall.action";
	}
}
