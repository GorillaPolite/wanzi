package com.wanlong.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.wanlong.pojos.Clean;
import com.wanlong.service.CleanService;

@Controller
public class CleanController {

	@Autowired
	CleanService cleanService;
	/**
	 * 查询所有维修内容
	 */
	@RequestMapping("/cleanact1")
	public String clist(Model model) {
		List<Clean>list=cleanService.selectByExample();
		model.addAttribute("clist", list);
		System.out.println(list.size());
		return "showclean";
	}
	/**
	 * 分类查询维修信息
	 */
	@RequestMapping("/cleanact2")
	public String clist2(Model model,String claccomplish) {
		List<Clean> list=cleanService.findClieanList(claccomplish);
		model.addAttribute("clist", list);
		return "showclean2";
	}
	/**
	 * 保存
	 * 
	 * @return
	 */
	@RequestMapping("/saveclean3")
	public String save(Clean clean, Model model) {
		System.out.println("+++++++++++++jinlai");
		cleanService.updatesave3(clean);
		return "redirect:cleanact1.action";
	}
	/**
	 * 根据id查询所有的维修信息
	 */
	@RequestMapping("/findCleanById")
	public String findCleanById(Model model, @RequestParam(value = "clid", defaultValue = "0") int clid) {
		Clean clean = cleanService.findCleanById(clid);
		model.addAttribute("clist", clean);
		return "showclean";
	}
	/**
	 * 点击更改完成状态
	 */
	@RequestMapping("/pushupdate")
	public String pushupdate(Clean clean) {
		cleanService.updaclaccomplish(clean);
		return "redirect:cleanact1.action";
	}
	
	/**
	 * 用户登记维修信息
	 */
	@RequestMapping("/addcleanq")
	public String signin() {
		return "regist";
	}

	// 客户注册控制器
	@RequestMapping("/signin2")
	public String signinjudge(Clean clean) {
	
		boolean flag = cleanService.insert(clean);
		
		if (flag == true) {

			// 使用重定向，返回登录界面
			return "css";
		} else {
			return "css";
		}
	}
	/**
	   * 保洁部门自己登记
	 * @param maintain
	 * @return
	 */
	@RequestMapping("/addclean")
	public String addmm(Clean clean) {
	
		boolean flag = cleanService.insert(clean);	
		if (flag == true) {
			// 使用重定向，返回登录界面
			return "redirect:cleanact1.action";
		} else {
			return "css";
		}
	}
	/**
	 * 根据结束时间日期查询
	 */
	@RequestMapping("/findCleanBymdate")
	public String findCleanBymdate(Model model,String cltime) {
		List<Clean>list2 = cleanService.findCleanBymdate(cltime);
		model.addAttribute("clist", list2);
		return "showclean";
	}
	/**
	 * 删除一个住户
	 */
	@RequestMapping("/deleteclen")
	public String deleteone(int clid) {
		cleanService.deleteByPrimaryKey(clid);
		return "redirect:cleanact1.action";
	}

	/**
	 * 根据id  完成时间   提交时间 模糊查询
	 * @param model
	 * @param md
	 * @return
	 */
	@RequestMapping("/findclean1")
	public String findclean(Model model,String cleanname) {
		System.out.println("+++++++++++++");
		System.out.println(cleanname);
		List<Clean>list3 = cleanService.findMainClean(cleanname);
		model.addAttribute("clist", list3);
		
		return "showclean";
	}
}
