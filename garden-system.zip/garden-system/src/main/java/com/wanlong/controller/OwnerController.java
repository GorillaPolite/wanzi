package com.wanlong.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wanlong.pojos.Carport;
import com.wanlong.pojos.Maintain;
import com.wanlong.pojos.Message;
import com.wanlong.pojos.MessageExample;
import com.wanlong.pojos.Owner;
import com.wanlong.service.BillService;
import com.wanlong.service.CarportService;
import com.wanlong.service.MessageService;
import com.wanlong.service.OwnerService;
import com.wanlong.service.SessionContentService;
import com.wanlong.util.PageRequest;
import com.wanlong.util.PageResult;

@Controller
public class OwnerController {

	@Autowired
	OwnerService ownerService;
	@Autowired
	private MessageService messService;
	@Autowired
	CarportService carportService;
	@Autowired
	SessionContentService sessionContentService;
	private BillService billService;

	// 登录控制器
	@RequestMapping("/login")
	public String login() {
		return "login";
	}

	// 登录判断控制器
	@RequestMapping("/loginjudge")
	public String loginjudge(@RequestParam("otel") String otel, @RequestParam("opass") String opass, Model model,
			HttpServletRequest request, String captcha) {
		String session1 = request.getSession().getAttribute("simpleCaptcha").toString();
		if (captcha.equals(session1)) {
			Owner owner = ownerService.findOwnerTel(otel, opass);
			HttpSession session = request.getSession();
			if (owner != null && owner.getOtel() != "" && owner.getOtel().equals(otel)
					&& owner.getOpass().equals(opass)) {
				if (otel.equals("vue10010")) {
					System.out.println("vue10010");
					session.setAttribute("tel", owner.getOtel());
					return "customermain";
				} else if(otel.equals("admin")) {
				
					return "main";
				}else {
					session = request.getSession();
					session.setAttribute("currentOwnerr", owner);
					List<Message> list = messService.selectByOid(owner.getOid());
					int messnumber = 0;
					for (int i = 0; i < list.size(); i++) {
						if (list.get(i).getStatus().equals("未阅读")) {
							++messnumber;
						}
					}
					model.addAttribute("messnumber", messnumber);
					// 传送owneruid到用户界面
					session.setAttribute("owneruid", owner.getOid());
					session.setAttribute("tel", owner.getOtel());
					// 将如错误信息发送到作用域，重定向在登录页面
					request.setAttribute("msss", "用户名或者密码错误");
					return "ownermain";
				}

			} else {
				// 将如错误信息发送到作用域，重定向在登录页面
				request.setAttribute("msss", "用户名或者密码错误");
				return "redirect:login.action";
			}
		} else {
			return "login";
		}
	}

	/**
	 * 添加住户信息
	 */

	@RequestMapping("/signin")
	public String signin() {
		return "regist";
	}
	/**
	 * @author Leett
	 */
	@RequestMapping("/ownermain")
	public String ownermain() {
		return "ownermain";
	}
	@RequestMapping("/savepingfen")
	public boolean savepingfen(String ff) {
		boolean f =  sessionContentService.gorgeous(ff);
		return f;
	}
	/**
	 * 添加住户信息
	 */

	@RequestMapping("/ownerbuycar")
	public String ownerbuycar(Model model) {
		Carport carport = new Carport();
		List<Carport> list = carportService.findCarByState("未使用");
		for (Carport carport2 : list) {
			carport.setDuration(carport2.getDuration());
		}
		int count = list.size();
		List<Carport> list1 = new ArrayList<Carport>();
		list1 = carportService.findCarByArea("A");
		model.addAttribute("A", list1);
		list1 = carportService.findCarByArea("B");
		model.addAttribute("B", list1);
		list1 = carportService.findCarByArea("C");
		model.addAttribute("C", list1);
		list1 = carportService.findCarByArea("D");
		model.addAttribute("D", list1);
		model.addAttribute("count", count);
		model.addAttribute("duration", carport.getDuration());
		return "ownerbuycar";
	}

	// 客户注册控制器
	@RequestMapping("/signinjudge")
	public String signinjudge(Owner record) {

		boolean flag = ownerService.insert(record);

		if (flag == true) {

			// 使用重定向，返回登录界面
			return "redirect:findpagess.action?pageSize=5&pageNum=1&str=n";
		} else {
			return "regist";
		}
	}

			@RequestMapping("/checktel")
			public @ResponseBody String checkname(HttpServletRequest request) {
				String otel =request.getParameter("name");
				System.out.println(ownerService.findByTel(otel));
				return ownerService.findByTel(otel);
			}					
			/**
			 * 退出控制器
			 */
			@RequestMapping("/exit")
			public String exit(HttpSession session, HttpServletRequest request, Model model) {
				System.out.println("exit");
				// 获取当前的session
				HttpSession session1 = request.getSession();
				// 销毁session
				session1.invalidate();
				return "redirect:home.action";
			}
			/**
			 * 查询所有的业主信息
			 */
			@RequestMapping("/ownerlist")
			public String ownerlist(Model model) {
				List<Owner> list=ownerService.selectByExample();
				model.addAttribute("list", list);
				System.out.println(list.size());
				return "customer";
			}
			
			/**
			 * 客户修改控制器
			 */ 
			@RequestMapping("/updateuser")
			public String updateuser(Model model, @RequestParam(value = "oid", defaultValue = "0") int oid) {
				Owner owner = ownerService.findById(oid);
				model.addAttribute("owner", owner);
				return "updateuser";
			}
			/**
			 * 更新保存
			 * @return
			 */
			@RequestMapping("/save")
			public String save(Owner owner, Model model) {
				ownerService.updatesave(owner);
				return "redirect:findpagess.action?pageSize=5&pageNum=1&str=n";
			}

			/**
			 * 删除一个住户
			 */
			@RequestMapping("/deleteone")
			public String deleteone(int oid) {
				ownerService.deleteByPrimaryKey(oid);
				return "redirect:findpagess.action?pageSize=5&pageNum=1&str=n";
			}
			/**
			 * 批量删除用户
			 */
			
			@RequestMapping("/deleteAll")
			public String deleteAll(int[] oids){
				boolean flag=ownerService.deleteAll(oids);
				return "redirect:findpagess.action?pageSize=5&pageNum=1&str=n";
			}
			/**
			 *  我的车位
			 */
			
			@RequestMapping("/mycarseat")
			public String mycarseat(Model model,int uid){
				List<Carport> list3 = carportService.findCarByState("未使用");
				int count = list3.size();
				List<Carport> list1 = new ArrayList<Carport>();
				list1 = carportService.findCarByArea("A");
				model.addAttribute("A", list1);
				list1 = carportService.findCarByArea("B");
				model.addAttribute("B", list1);
				list1 = carportService.findCarByArea("C");
				model.addAttribute("C", list1);
				list1 = carportService.findCarByArea("D");
				model.addAttribute("D", list1);
				model.addAttribute("count", count);
				System.out.println("mycarseat:"+uid);
				List<Carport> list = carportService.findMyCarSeat(uid);
				 model.addAttribute("carport1", list);
				 for (Carport c : list) {
					System.out.println(c.getDate());
				}
				return "mycarseat";
			}
			
			
			/**
			 * 展示用户
			 */		
			@RequestMapping("/showoerme")
			public String showownerme(Model model,HttpSession session){
				System.out.println("============");
					int oid1 = (int) session.getAttribute("owneruid");
					System.out.println(oid1);
					if(oid1!=0) {
				Owner onwer=ownerService.findById(oid1);
				model.addAttribute("onwer", onwer);
				return "showoerme";
			}else {
				return "login";
				}
			}
			/**
			 * owner页面首页
			 */		
			@RequestMapping("/mymianmessage")
			public String mymianmessage(){
				return "mymianmessage";
			}
			/**
			   *      个人信息更改
			 */
			@RequestMapping("/updateowenerss")
			public String updateowenerss(Model model, @RequestParam(value = "oid", defaultValue = "0") int oid,HttpSession session) {
				int oid1 = (int) session.getAttribute("owneruid");
				Owner owner=ownerService.findById(oid1);
				System.out.println("+++++++++++++>>>>>>>>");
				System.out.println("onwe.id:  "+owner.getOid());
				model.addAttribute("owner",owner );
				return "updateowner";
			}
			
			/**
			 * 个人修改保存控制器
			 */
			@RequestMapping("/savaowners")
			public String savaowners(Model model,@RequestParam(value = "oid", defaultValue = "0") int oid,HttpSession session,Owner owner) {
				System.out.println("+++++++++++++++++>");
				System.out.println("owner: "+owner.getOpass());
				
				owner.setOid((int)session.getAttribute("owneruid"));
				boolean flag=ownerService.updateowner(owner);
				System.out.println("flag:  "+flag);
				if(flag=true) {
			
					int oid1=(int)session.getAttribute("owneruid");
					System.out.println(oid1);
					Owner owner2=ownerService.findById(oid1);
					model.addAttribute("owner",owner2);
					return "redirect:showoerme.action";
				}
				return "updateowner";
			}
			
			// 分页查询
			@RequestMapping("/findpagess")
			public String findPage(int pageSize, int pageNum, Model model, String str, HttpSession session) {
				System.out.println("进来了");
				System.out.println(pageSize);
				System.out.println(str);
				if (str.equals("z")) {
					++pageNum;
				} else if (str.equals("j")) {
					--pageNum;
				}
				session.setAttribute("pageSize", pageSize);
				PageRequest pageQuery = new PageRequest();
				pageQuery.setPageNum(pageNum);
				pageQuery.setPageSize(pageSize);
				PageResult pageResult = ownerService.findPage(pageQuery);
				model.addAttribute("pageResult", pageResult);
				return "customer";

			}
			/**
			 * 分类查询住户集合
			 */
			@RequestMapping("list2")
			public String ownerlist2(Model model,int towernum) {
				List<Owner> list=ownerService.findownerlist(towernum);
				model.addAttribute("list", list);
				return "list2";
			}
			
			@RequestMapping("/findpages2")
			public String findPage1(int pageSize, Model model, HttpSession session) {
				System.out.println("进来了");
				System.out.println(pageSize);
				PageRequest pageQuery = new PageRequest();
				pageQuery.setPageNum(1);
				pageQuery.setPageSize(pageSize);
				session.setAttribute("pageSize", pageSize);
				PageResult pageResult = ownerService.findPage(pageQuery);
				model.addAttribute("pageResult", pageResult);
				return "customer";

			}

			/**
			 * 根据id  完成时间   提交时间 模糊查询
			 * @param model
			 * @param md
			 * @return
			 */
			@RequestMapping("/findMain2")
			public String findMain(Model model,String mds) {
				System.out.println("+++++++++++++");
				System.out.println(mds);
				List<Owner>list3 = ownerService.findMain(mds);
				model.addAttribute("list", list3);
				
				return "list2";
			}
}