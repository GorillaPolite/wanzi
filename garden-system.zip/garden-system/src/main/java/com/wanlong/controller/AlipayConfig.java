package com.wanlong.controller;

import java.io.FileWriter;
import java.io.IOException;

/* *
 *类名：AlipayConfig
 *功能：基础配置类
 *详细：设置帐户有关信息及返回路径
 *修改日期：2017-04-05
 *说明：
 *以下代码只是为了方便商户测试而提供的样例代码，商户可以根据自己网站的需要，按照技术文档编写,并非一定要使用该代码。
 *该代码仅供学习和研究支付宝接口使用，只是提供一个参考。
 */

public class AlipayConfig {

	// ↓↓↓↓↓↓↓↓↓↓请在这里配置您的基本信息↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓

	// 应用ID,您的APPID，收款账号既是您的APPID对应支付宝账号
	public static String app_id = "2016102600766182";

	// 商户私钥，您的PKCS8格式RSA2私钥
	public static String APP_PRIVATE_KEY = "MIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQCM+"
			+ "SqczOJgTqbCaL9lGCymPRlNwVuLKm4HDo+"
			+ "pqDMnGfKQEzWK1EkFIlCCrtGAkURG2C4A8xcoQ45QzmcLG2LDIFGGt6aTkQghXcmFihoLb9tb"
			+ "/5QOSoQFrB5HCanvXrgyyYZ5cR/5M6AlLCCESfQud/jWRPHrlQ35w6IoOY+bjbds4CCV5lDUtVHEEjZg+fDnvDNZNtal81KitoePV1tDew15ng"
			+ "/rZ4kkgIh/3gwyF5HYSlyD2K4J98by1C1r+cbY6TayA1SfhbnYrPrkddkgcold7RiU4Lv3Zf+"
			+ "l/v6xr4flIxymsFMgKhbUuMLHt/0lu/nhQs2QYvLvOArfnh5nAgMBAAECggEAeuyBpbxZ4NR0QK0Jx2Mu+73nJI/n/Q+AZZLi3nMWN5A+nDbDx0yYZ2umfG1nrQ3+"
			+ "VTAH3TgbBzbxD7EK1PqKQc8ah7f3/lDGoCGhqVnkn/hndG8FcPi06iVNOXBJx7n2MALdyWNFGA1WJVO2/uNlkmd2iZAQyvVr/FAEQ8L9YAsEaQCCGL6yoGY2v8f/b16fsEemeVx0tBWqlw4z5InCEx/KjtI+"
			+ "dI+fK2CkaSZr0JxxN0lJh7wkQImriPuGnzpH1exH8L1eiuYP86m0ZRW67hqmeziuqFnxaf6ILr7d4IkO4puvJ8m01WPq45cBVuT8AZTC7OVjTiJzKLDzrVcZwQKBgQDOWDzL"
			+ "+mlopvV7nVBsugvP5NbgdX5A2a7FLLY37bvQ4c1+mk3YNmqRlrIXOjyyAk9ZGVbVu8FUBEfv0NZc4nXCjl2QP+"
			+ "wIsTUHtNkzx8b5xB6ITWunfGwTAwokpvUam11PqGM3bhe8Y9lLVEjNbRPjk6FYtyolKfMsBuZtFyZ8kQKBgQCu5cH8KZdSiDf8wgfmPFj+"
			+ "QyW69WlyDletmHAhY1BOCQrKym8hksoUBdQtcMQ+yKp+"
			+ "qsf6yOPchfp5BOnBi2bwOt2oO6Ws47aiIWsvKgqJgusqlVocLoCaozQulS1nVnL6bVo0v37YabAKzYaBXV9JbgwqqJgdZ4x37uvlvE5HdwKBgF3uCtbrydoKzoqT5Q1pb4EWcb5BndRVg1pcbSJuhOWkNFAiW7dFpiNaDv3F0+"
			+ "VQaeBsSXwH+QyO2lRPo5UqvWJwPiUxA/g8+p/kck9A7NG7tg5j99KJMAVDh/WBTufqu4JMa8XKxuFKLps85dslgT1CcdsZngTG4Nw00+Xq+OkRAoGAberv826gL7p0lWHMXSJoO8QvnkRGNOxWpj87mYA1JBYCtlhrZ4o9fj/7jWNlsp+"
			+ "ip2DltfMzYZDCTfSMhJr74tbcH7L8+J9UVKj0F/wwCyRAb87Vhwiiwoz3ap9OnbdzI3g+TRBcw94ISYHJmtv32spS0yyKDVDaszVxBD1IZRkCgYBc3kFr+"
			+ "wqs5r89VWGpK0EtTAdKyF4jM84q4DDLPrf/CQ/3sIvxSUlSpEP9EPyrox9Me5OY/7emp2QQAHEVIQqevVe7T5rXO9fmR4zP0vNj+"
			+ "Y4UdeNJIV5lRXs1VokR1DMXhdNz42EBUTgPAY2UauO6DsN4vVhvwWoZ5v/BFnCwCw==";

	// 支付宝公钥,查看地址：https://openhome.alipay.com/platform/keyManage.htm
	// 对应APPID下的支付宝公钥。
	public static String alipay_public_key = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAgTD4iIYtne80o+86JIP5rF9Qs8iSaogm37fSFgWUUUQgSzHj8mm6GsHzve27Ov5UTgTlY1bdIC4UwXB0GtEiRhOXa0su+jZpTlmS/HDQdewBKJn7SrfNuMncVxE+pvHPQIErWsFXJ18vvSxMAYPLDtndo4R3c4pMqiCr/yF+CI9zGS41+7szECG6eb8jikSdMy+X48TkpnDE94MCQxsnyabY14gcz8r0E21IR7lFfkHgNV33Ul/m8qoyKWs+lyNiPk6UjZAbv40f7woWQaWsEgoSC2Z+uzRgmaZfk9SCYCOeC4Joq7dZxKCHo8MWx6zJ5otoVShqBgLA6s85LiQjgQIDAQAB";

	// 服务器异步通知页面路径 需http://格式的完整路径，不能加?id=123这类自定义参数，必须外网可以正常访问
	public static String notify_url = "http://hittemilk.vaiwan.com/garden/Alipay/notifyUrl.action";

	// 页面跳转同步通知页面路径 需http://格式的完整路径，不能加?id=123这类自定义参数，必须外网可以正常访问
	public static String return_url = "http://hittemilk.vaiwan.com/garden/Alipay/returnUrl.action";


	// 签名方式
	public static String sign_type = "RSA2";

	// 字符编码格式
	public static String charset = "utf-8";

	// 支付宝网关
	public static String gatewayUrl = "https://openapi.alipaydev.com/gateway.do";

	// 支付宝网关
	public static String log_path = "C:\\";

	// ↑↑↑↑↑↑↑↑↑↑请在这里配置您的基本信息↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑

	/**
	 * 写日志，方便测试（看网站需求，也可以改成把记录存入数据库）
	 * 
	 * @param sWord
	 *            要写入日志里的文本内容
	 */
	public static void logResult(String sWord) {
		FileWriter writer = null;
		try {
			writer = new FileWriter(log_path + "alipay_log_" + System.currentTimeMillis() + ".txt");
			writer.write(sWord);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (writer != null) {
				try {
					writer.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
