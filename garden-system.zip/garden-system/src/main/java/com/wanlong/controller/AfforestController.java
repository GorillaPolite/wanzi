package com.wanlong.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.wanlong.pojos.Afforest;
import com.wanlong.service.AfforestService;

/**
 * 
 * @author mufeng
 * @category 绿化的控制器
 */
@Controller
public class AfforestController {

	@Autowired
	AfforestService afforestService;
	/**
	 * 查看所有绿化信息
	 */
	@RequestMapping("/afforestact1")
	public String afforestact(Model model) {
		List<Afforest>list=afforestService.selectByExample();
		model.addAttribute("aflist", list);
		return "showafforest";
	}
	/**
	 * 查看所有绿化信息
	 */
	@RequestMapping("/afforestact2")
	public String afforestact2(Model model,String afplush) {
		List<Afforest>list=afforestService.findAfplushList(afplush);
		model.addAttribute("aflist", list);
		return "showafforest2";
	}
	/**
	 * 保存
	 */
	@RequestMapping("/saveafforest")
	public String save(Afforest afforest,Model model) {
		afforestService.updatesave4(afforest);
		return "redirect:afforestact1.action";
	}
	/**
	 * 根据ID查询所有内容
	 */
	@RequestMapping("/findAfforestByid")
	public String find(Model model,int afid) {
		Afforest afforest=new Afforest();
		afforest=afforestService.findAfforestById(afid);
		model.addAttribute("aflist", afforest);
		return "showafforest";
	}
	/**
	 * 点击更改完成状态
	 */
	@RequestMapping("/updapushaf")
	public String updapushaf(Afforest afforest) {
		afforestService.updaaffomplish(afforest);
		return "redirect:afforestact1.action";
	}
	/**
	   *  添加绿化任务
	 * @param maintain
	 * @return
	 */
	@RequestMapping("/addafforest")
	public String addafforest(Afforest afforest) {
	
		boolean flag = afforestService.insert(afforest);	
		if (flag == true) {
			// 使用重定向，返回登录界面
			return "redirect:afforestact1.action";
		} else {
			return "css";
		}
	}
	/**
	 * 删除一个住户
	 */
	@RequestMapping("/deleteaff")
	public String deleteone(int afid) {
		afforestService.deleteByPrimaryKey(afid);
		return "redirect:afforestact1.action";
	}
	/**
	 * 根据id  完成时间   提交时间 模糊查询
	 * @param model
	 * @param md
	 * @return
	 */
	@RequestMapping("/findaffor")
	public String findclean(Model model,String affname) {
		System.out.println("+++++++++++++");
		System.out.println(affname);
		List<Afforest>list3 = afforestService.findMainAfforest(affname);
		model.addAttribute("aflist", list3);
		
		return "showafforest";
	}
}
