package com.wanlong;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 启动服务
 *
 * @author xiao.xl 2024-07-08 10:40
 */
@SpringBootApplication
@MapperScan("com.wanlong.dao")
public class GardenApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(GardenApplication.class, args);
	}

}
